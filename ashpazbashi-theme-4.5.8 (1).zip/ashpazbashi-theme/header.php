<?php
/**
 * هدر سایت — دسکتاپ: جست‌وجو (چپ)، برند (وسط)، خوش‌آمدگویی (راست) و نوار دسته‌بندی‌ها
 * موبایل: نوار بالا + کشوی منو + نوار پایین (سبک دیجی‌کالا)
 *
 * @package Ashpazbashi
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#07060f">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
/* صفحهٔ لودینگ نئونی — با تمام‌شدن بارگذاری، جاوااسکریپت محوش می‌کند */
?>
<div id="ashp-loader" role="status" aria-live="polite">
	<div class="ashp-loader__ring">
		<span class="ashp-loader__logo">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo.png' ); ?>" alt="" width="74" height="74" decoding="async">
		</span>
	</div>
	<p class="ashp-loader__name"><?php bloginfo( 'name' ); ?></p>
	<div class="ashp-loader__bar"><i></i></div>
	<p class="ashp-loader__hint"><?php esc_html_e( 'آشپزباشی در حال آماده‌سازی آشپزخانه…', 'ashpazbashi' ); ?></p>
</div>

<div id="ashp-cursor-dot" aria-hidden="true"></div>
<div id="ashp-cursor-glow" aria-hidden="true"></div>

<a class="ashp-skip" href="#ashp-content"><?php esc_html_e( 'پرش به محتوا', 'ashpazbashi' ); ?></a>

<header id="ashp-header" class="ashp-header">

	<div class="ashp-header__top">
		<div class="ashp-header__inner">

			<?php /* منوی همبرگری — فقط موبایل */ ?>
			<button class="ashp-burger" type="button" aria-expanded="false" aria-controls="ashp-drawer">
				<span class="ashp-burger__bars" aria-hidden="true"><i></i><i></i><i></i></span>
				<span class="screen-reader-text"><?php esc_html_e( 'منو', 'ashpazbashi' ); ?></span>
			</button>

			<?php /* خوش‌آمدگویی — سمت راست */ ?>
			<div class="ashp-user" data-name="<?php echo esc_attr( ashpazbashi_current_name() ); ?>">
				<span class="ashp-user__greet">
					<span class="ashp-user__name" data-ashp-uname><?php echo esc_html( ashpazbashi_current_name() ? ashpazbashi_current_name() : __( 'مهمان', 'ashpazbashi' ) ); ?></span>
					<span class="ashp-user__joo"><?php esc_html_e( 'جون خوش اومدی', 'ashpazbashi' ); ?></span>
					<?php echo ashpazbashi_blush_sticker( 26 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت ?>
				</span>
				<button class="ashp-user__edit" type="button" aria-label="<?php esc_attr_e( 'تغییر نام', 'ashpazbashi' ); ?>"><svg class="ashp-user__editico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4.4 19.6h3.4l9.3-9.3-3.4-3.4-9.3 9.3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M14.4 5.6 18.4 9.6l1.5-1.5a1.2 1.2 0 0 0 0-1.7l-1.5-1.5a1.2 1.2 0 0 0-1.7 0z" fill="currentColor"/></svg></button>
			</div>

			<?php /* برند — وسط */ ?>
			<div class="ashp-brand">
				<?php echo ashpazbashi_logo( 44 ); // phpcs:ignore WordPress.Security.EscapeOutput -- خروجی تابع خودش escape شده است ?>
				<a class="ashp-brand__text" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<span class="ashp-brand__name"><?php echo esc_html( ASHP_SITE_NAME ); ?></span>
				</a>
			</div>

			<?php /* جست‌وجو — سمت چپ */ ?>
			<button class="ashp-searchtoggle" type="button" aria-expanded="false" aria-controls="ashp-searchwrap">
				<svg class="ashp-ico-search" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.6" cy="10.6" r="6.1" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.3 15.3 20.6 20.6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>
				<span class="screen-reader-text"><?php esc_html_e( 'جست‌وجو', 'ashpazbashi' ); ?></span>
			</button>

			<div class="ashp-searchwrap" id="ashp-searchwrap">
				<?php ashpazbashi_search_form(); ?>
			</div>

			<?php /* دسته‌بندی‌ها — ردیف دوم، وسط‌چین */ ?>
			<nav class="ashp-catbar" aria-label="<?php esc_attr_e( 'دسته‌بندی‌ها', 'ashpazbashi' ); ?>">
				<?php ashpazbashi_mega_menu(); ?>
			</nav>

		</div>
	</div>

	<?php /* ── بخش‌های سایت ── */ ?>
	<nav class="ashp-hubs" aria-label="<?php esc_attr_e( 'بخش‌های سایت', 'ashpazbashi' ); ?>" data-ashp-hubs>

		<?php
		/*
		 * فقط موبایل: دکمهٔ فلش سبزِ متحرک.
		 * با زدن روی آن، فهرست بخش‌ها از بالا به پایین باز می‌شود و فلش
		 * به سمت بالا می‌چرخد؛ با زدن دوباره، فهرست جمع می‌شود.
		 * روی دسکتاپ این دکمه پنهان است و فهرست همیشه باز می‌ماند.
		 */
		?>
		<?php /* اگر جاوااسکریپت خاموش باشد، دکمهٔ فلش بی‌فایده است: پنهانش می‌کنیم و فهرست را باز نشان می‌دهیم */ ?>
		<noscript><style>
			.ashp-hubstoggle{display:none!important}
			.ashp-hubs .ashp-hubs__inner{max-height:none!important;opacity:1!important;transform:none!important;pointer-events:auto!important}
			.ashp-hubs .ashp-hub{opacity:1!important;transform:none!important}
		</style></noscript>

		<button class="ashp-hubstoggle" type="button" aria-expanded="false" aria-controls="ashp-hubs-inner" data-ashp-hubstoggle
			data-label-open="<?php echo esc_attr__( 'نمایش بخش‌های سایت', 'ashpazbashi' ); ?>"
			data-label-close="<?php echo esc_attr__( 'بستن بخش‌ها', 'ashpazbashi' ); ?>">
			<span class="ashp-hubstoggle__ring" aria-hidden="true"></span>
			<svg class="ashp-hubstoggle__arrow" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
				<path d="M5.4 8.8 12 15.4l6.6-6.6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
			</svg>
			<span class="screen-reader-text"><?php esc_html_e( 'نمایش بخش‌های سایت', 'ashpazbashi' ); ?></span>
		</button>

		<div class="ashp-hubs__inner" id="ashp-hubs-inner" data-ashp-hubsinner>
			<?php foreach ( ashpazbashi_hub_items() as $ashp_hub ) : ?>
				<a class="ashp-hub<?php echo $ashp_hub['accent'] ? ' ashp-hub--accent' : ''; ?>" href="<?php echo esc_url( $ashp_hub['url'] ); ?>">
					<span class="ashp-hub__ico" aria-hidden="true"><?php echo esc_html( $ashp_hub['emoji'] ); ?></span>
					<span class="ashp-hub__txt"><?php echo esc_html( $ashp_hub['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</nav>
</header>

<?php /* ── کشوی منوی موبایل ── */ ?>
<div class="ashp-drawer" id="ashp-drawer" hidden>
	<div class="ashp-drawer__scrim" data-ashp-drawer-close></div>
	<aside class="ashp-drawer__panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'منو', 'ashpazbashi' ); ?>">

		<div class="ashp-drawer__head">
			<?php echo ashpazbashi_logo( 36 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<strong class="ashp-drawer__brand"><?php echo esc_html( ASHP_SITE_NAME ); ?></strong>
			<button class="ashp-drawer__close" type="button" data-ashp-drawer-close aria-label="<?php esc_attr_e( 'بستن', 'ashpazbashi' ); ?>">✕</button>
		</div>

		<?php /* نام کاربر — پس از ورود نام، همین‌جا نمایش داده می‌شود */ ?>
		<div class="ashp-drawer__user">
			<span class="ashp-user__name" data-ashp-uname><?php echo esc_html( ashpazbashi_current_name() ? ashpazbashi_current_name() : __( 'مهمان', 'ashpazbashi' ) ); ?></span>
			<span class="ashp-drawer__joo"><?php esc_html_e( 'جون خوش اومدی', 'ashpazbashi' ); ?></span>
			<?php echo ashpazbashi_blush_sticker( 24 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<button class="ashp-user__edit" type="button" aria-label="<?php esc_attr_e( 'تغییر نام', 'ashpazbashi' ); ?>"><svg class="ashp-user__editico" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4.4 19.6h3.4l9.3-9.3-3.4-3.4-9.3 9.3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M14.4 5.6 18.4 9.6l1.5-1.5a1.2 1.2 0 0 0 0-1.7l-1.5-1.5a1.2 1.2 0 0 0-1.7 0z" fill="currentColor"/></svg></button>
		</div>

		<div class="ashp-drawer__body">
			<?php foreach ( ashpazbashi_hub_items() as $ashp_hub ) : ?>
				<a class="ashp-drawer__link" href="<?php echo esc_url( $ashp_hub['url'] ); ?>">
					<span aria-hidden="true"><?php echo esc_html( $ashp_hub['emoji'] ); ?></span>
					<?php echo esc_html( $ashp_hub['label'] ); ?>
				</a>
			<?php endforeach; ?>
			<hr class="ashp-drawer__rule">
			<?php ashpazbashi_mega_menu(); ?>
		</div>
	</aside>
</div>

<?php /* ── نوار پایین موبایل (سبک دیجی‌کالا) ── */ ?>
<nav class="ashp-bottomnav" aria-label="<?php esc_attr_e( 'دسترسی سریع', 'ashpazbashi' ); ?>">
	<?php foreach ( ashpazbashi_bottom_items() as $ashp_b ) : ?>
		<a class="ashp-bottomnav__item<?php echo $ashp_b['on'] ? ' is-on' : ''; ?>" href="<?php echo esc_url( $ashp_b['url'] ); ?>">
			<span class="ashp-bottomnav__ico" aria-hidden="true"><?php echo esc_html( $ashp_b['emoji'] ); ?></span>
			<span class="ashp-bottomnav__lbl"><?php echo esc_html( $ashp_b['label'] ); ?></span>
		</a>
	<?php endforeach; ?>
</nav>

<?php /* ── کادر ورود نام (بدون تاریک‌کردن کل صفحه) ── */ ?>
<div class="ashp-namebar" id="ashp-namebar" hidden role="dialog" aria-modal="true" aria-labelledby="ashp-name-label">
	<form class="ashp-namebar__form">
		<label id="ashp-name-label" for="ashp-name-input"><?php esc_html_e( 'اسمت چیه؟', 'ashpazbashi' ); ?></label>
		<input id="ashp-name-input" type="text" maxlength="40" placeholder="<?php esc_attr_e( 'مثلاً: سارا', 'ashpazbashi' ); ?>" required>
		<button type="submit"><?php esc_html_e( 'شروع آشپزی', 'ashpazbashi' ); ?></button>
		<p class="ashp-namebar__hint"><?php esc_html_e( 'بدون ثبت‌نام و رمز عبور — فقط اسمت را بنویس.', 'ashpazbashi' ); ?></p>
	</form>
</div>
<script>
/* کادر نام باید پیش از دیده‌شدن سایت بالا بیاید */
(function () {
	try {
		var n = window.localStorage ? localStorage.getItem('ashp_name') : '';
		if (!n) {
			var el = document.getElementById('ashp-namebar');
			if (el) {
				el.hidden = false;
				document.documentElement.classList.add('ashp-asking-name');
				/* انیمیشن باز شدن: کلاس پس از یک فریم اضافه می‌شود */
				window.requestAnimationFrame(function () {
					window.requestAnimationFrame(function () { el.classList.add('is-open'); });
				});
			}
		}
	} catch (e) {}
})();
</script>

<main id="ashp-content" class="ashp-main">
