<?php
/**
 * بخش‌های اصلی سایت: «غذاها و مواد اولیه» و «نوشیدنی‌ها و دسرها»
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$ashp_hub_key = class_exists( 'ASHP_Router' ) ? ASHP_Router::current_var( ASHP_Router::VAR_HUB ) : 'food';

if ( 'party' === $ashp_hub_key ) {

	$ashp_title = __( 'فود پارتی', 'ashpazbashi' );
	$ashp_desc  = __( 'هر چه برای مهمانی لازم دارید: پیش‌غذا، غذای اصلی، دسر و نوشیدنی — یک‌جا و دسته‌بندی‌شده.', 'ashpazbashi' );
	$ashp_flag  = 'party';
	$ashp_cats  = array( 'iranian-formal', 'iranian-local', 'appetizer', 'fastfood', 'world', 'dessert', 'drink' );
	$ashp_ing_groups = array( 'protein', 'veg', 'grain', 'dairy', 'fat', 'spice', 'sweetener' );
	$ashp_ing_title  = __( 'مواد اولیهٔ پرکاربرد مهمانی', 'ashpazbashi' );

} elseif ( 'kids' === $ashp_hub_key ) {

	$ashp_title = __( 'غذای کودکان', 'ashpazbashi' );
	$ashp_desc  = __( 'غذاهایی که بچه‌ها دوست دارند و برای ۳ تا ۸ سال بی‌خطرند.', 'ashpazbashi' );
	$ashp_flag  = 'kids';
	$ashp_cats  = array( 'iranian-formal', 'appetizer', 'fastfood', 'world', 'drink' );
	$ashp_ing_groups = array( 'dairy', 'fruit', 'grain', 'protein' );
	$ashp_ing_title  = __( 'مواد اولیهٔ پرکاربرد غذای کودکان', 'ashpazbashi' );

} elseif ( 'sweets' === $ashp_hub_key ) {
	$ashp_title = __( 'نوشیدنی‌ها و دسرها', 'ashpazbashi' );
	$ashp_desc  = __( 'کیک و شیرینی، دسر و ژله، بستنی، حلوا و مربا در کنار نوشیدنی‌های گرم و سرد — همه در یک بخش.', 'ashpazbashi' );
	$ashp_cats  = array( 'dessert', 'drink' );
	$ashp_ing_groups = array( 'sweetener', 'dairy', 'fruit', 'other' );
	$ashp_ing_title  = __( 'مواد اولیهٔ پرکاربرد دسر و نوشیدنی', 'ashpazbashi' );
} else {
	$ashp_title = __( 'غذاها و مواد اولیه', 'ashpazbashi' );
	$ashp_desc  = __( 'همهٔ غذاهای ایرانی، محلی و بین‌المللی، همراه با مواد اولیهٔ هر غذا — بگو چه داری تا بگوییم چه بپزی.', 'ashpazbashi' );
	$ashp_cats  = array( 'iranian-formal', 'iranian-local', 'appetizer', 'fastfood', 'world' );
	$ashp_ing_groups = array( 'protein', 'veg', 'grain', 'legume', 'dairy', 'fat', 'spice' );
	$ashp_ing_title  = __( 'مواد اولیهٔ پرکاربرد غذاها', 'ashpazbashi' );
}

if ( ! isset( $ashp_flag ) ) {
	$ashp_flag = '';
}
$ashp_cards = class_exists( 'ASHP_DB' ) ? ASHP_DB::subcategory_cards( $ashp_cats ) : array();
$ashp_flag_rows  = array();
$ashp_flag_total = 0;
if ( class_exists( 'ASHP_DB' ) && '' !== $ashp_flag ) {
	$ashp_flag_res   = ASHP_DB::query_recipes( array( 'flag' => $ashp_flag, 'per_page' => 12 ) );
	$ashp_flag_rows  = isset( $ashp_flag_res['rows'] ) ? $ashp_flag_res['rows'] : array();
	$ashp_flag_total = isset( $ashp_flag_res['total'] ) ? (int) $ashp_flag_res['total'] : 0;
}

$ashp_g_open = isset( $_GET['g'] ) ? sanitize_key( wp_unslash( $_GET['g'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- فقط نمایش
if ( ! isset( $ashp_ing_title ) ) {
	$ashp_ing_title = __( 'مواد اولیهٔ پرکاربرد', 'ashpazbashi' );
}
$ashp_ings  = class_exists( 'ASHP_DB' ) ? ASHP_DB::top_ingredients( $ashp_ing_groups, 42 ) : array();
$ashp_defs  = class_exists( 'ASHP_DB' ) ? ASHP_DB::ingredient_groups_def() : array();
?>
<div class="ashp-wrap">

	<nav class="ashp-breadcrumb" aria-label="<?php esc_attr_e( 'مسیر صفحه', 'ashpazbashi' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'ashpazbashi' ); ?></a>
		<span aria-hidden="true">›</span>
		<span><?php echo esc_html( $ashp_title ); ?></span>
	</nav>

	<header class="ashp-section__head">
		<h1 class="ashp-section__title"><?php echo esc_html( $ashp_title ); ?></h1>
		<p class="ashp-section__sub"><?php echo esc_html( $ashp_desc ); ?></p>
	</header>

	<?php if ( $ashp_cards ) : ?>
		<?php if ( 'party' === $ashp_hub_key || 'kids' === $ashp_hub_key ) : ?>
			<?php
			$ashp_is_party = ( 'party' === $ashp_hub_key );
			$ashp_groups   = $ashp_is_party ? ASHP_DB::party_groups() : ASHP_DB::kid_groups();
			?>
			<?php foreach ( $ashp_groups as $ashp_gk => $ashp_g ) : ?>
				<?php
				/* اگر یک گروه کامل خواسته شده باشد، فقط همان نمایش داده می‌شود */
				if ( '' !== $ashp_g_open && $ashp_g_open !== $ashp_gk ) {
					continue;
				}
				$ashp_g_is_open = ( $ashp_g_open === $ashp_gk );
				$ashp_g_limit   = $ashp_g_is_open ? 60 : 3;
				$ashp_g_rows = $ashp_is_party
					? ASHP_DB::party_group_rows( $ashp_gk, $ashp_g_limit )
					: ASHP_DB::kid_group_rows( $ashp_gk, $ashp_g_limit );
				$ashp_g_n = $ashp_is_party
					? ASHP_DB::party_group_count( $ashp_gk )
					: ASHP_DB::kid_group_count( $ashp_gk );
				/* لینک گروه: بخش‌های دسته‌ای به دسته، گروه‌های کودکان به همین صفحه با ?g= */
				if ( $ashp_is_party && ! empty( $ashp_g['cats'][0] ) ) {
					$ashp_g_url = ASHP_DB::category_url( $ashp_g['cats'][0] );
				} else {
					$ashp_g_url = add_query_arg( 'g', $ashp_gk, home_url( '/kids/' ) );
				}
				?>
				<?php if ( $ashp_g_rows ) : ?>
					<div class="ashp-flagsec" id="<?php echo esc_attr( 'ashp-g-' . $ashp_gk ); ?>">
						<div class="ashp-flagsec__head">
							<h2 class="ashp-section__title">
								<span aria-hidden="true"><?php echo esc_html( $ashp_g['emoji'] ); ?></span>
								<?php echo esc_html( $ashp_g['label'] ); ?>
								<span class="ashp-muted"><?php echo esc_html( number_format_i18n( $ashp_g_n ) ); ?></span>
							</h2>
							<?php if ( $ashp_g_is_open ) : ?>
								<a class="ashp-btn ashp-btn--ghost ashp-btn--sm" href="<?php echo esc_url( $ashp_is_party ? home_url( '/party/' ) : home_url( '/kids/' ) ); ?>">
									<?php esc_html_e( 'بازگشت به همهٔ گروه‌ها', 'ashpazbashi' ); ?>
								</a>
							<?php else : ?>
								<a class="ashp-btn ashp-btn--ghost ashp-btn--sm" href="<?php echo esc_url( $ashp_g_url ); ?>">
									<?php esc_html_e( 'دیدن همه', 'ashpazbashi' ); ?>
								</a>
							<?php endif; ?>
						</div>
						<div class="ashp-grid ashp-grid--cards">
							<?php foreach ( $ashp_g_rows as $ashp_fr ) : ?>
								<?php echo ASHP_Front::recipe_card( $ashp_fr ); // phpcs:ignore WordPress.Security.EscapeOutput -- خودش escape می‌کند ?>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>

		<?php elseif ( $ashp_flag_rows ) : ?>
			<div class="ashp-flagsec">
				<div class="ashp-flagsec__head">
					<h2 class="ashp-section__title"><?php echo esc_html( sprintf(
						/* translators: %s: count */
						__( '%s دستور گزیده برای این بخش', 'ashpazbashi' ),
						number_format_i18n( $ashp_flag_total )
					) ); ?></h2>
				</div>
				<div class="ashp-grid ashp-grid--cards">
					<?php foreach ( $ashp_flag_rows as $ashp_fr ) : ?>
						<?php echo ASHP_Front::recipe_card( $ashp_fr ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>

		<?php foreach ( $ashp_cards as $ashp_card ) : ?>
			<section class="ashp-hubblock">
				<header class="ashp-hubblock__head">
					<h2>
						<span aria-hidden="true"><?php echo esc_html( $ashp_card['emoji'] ); ?></span>
						<a href="<?php echo esc_url( $ashp_card['url'] ); ?>"><?php echo esc_html( $ashp_card['fa'] ); ?></a>
						<span class="ashp-badge"><?php echo esc_html( number_format_i18n( $ashp_card['count'] ) ); ?> <?php esc_html_e( 'دستور', 'ashpazbashi' ); ?></span>
					</h2>
					<?php if ( $ashp_card['desc'] ) : ?>
						<p class="ashp-section__sub"><?php echo esc_html( $ashp_card['desc'] ); ?></p>
					<?php endif; ?>
				</header>

				<?php if ( $ashp_card['subs'] ) : ?>
					<div class="ashp-subcards">
						<?php foreach ( $ashp_card['subs'] as $ashp_sub_item ) : ?>
							<a class="ashp-subcard" href="<?php echo esc_url( $ashp_sub_item['url'] ); ?>">
								<span class="ashp-subcard__label"><?php echo esc_html( $ashp_sub_item['label'] ); ?></span>
								<span class="ashp-subcard__count"><?php echo esc_html( number_format_i18n( $ashp_sub_item['count'] ) ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</section>
		<?php endforeach; ?>
	<?php endif; ?>

	<section class="ashp-section" id="ashp-hub-ingredients">
		<header class="ashp-section__head">
			<h2 class="ashp-section__title"><?php echo esc_html( $ashp_ing_title ); ?></h2>
			<p class="ashp-section__sub"><?php esc_html_e( 'روی هر ماده بزنید تا ببینید چه غذاهایی با آن پخته می‌شود.', 'ashpazbashi' ); ?></p>
		</header>

		<?php if ( $ashp_ings ) : ?>
			<div class="ashp-subcards ashp-subcards--ings">
				<?php foreach ( $ashp_ings as $ashp_ing_item ) : ?>
					<a class="ashp-subcard ashp-subcard--ing" href="<?php echo esc_url( $ashp_ing_item['url'] ); ?>">
						<span class="ashp-subcard__label">
							<?php echo esc_html( isset( $ashp_defs[ $ashp_ing_item['group'] ] ) ? $ashp_defs[ $ashp_ing_item['group'] ]['emoji'] : '🥄' ); ?>
							<?php echo esc_html( $ashp_ing_item['name'] ); ?>
						</span>
						<span class="ashp-subcard__count"><?php echo esc_html( number_format_i18n( $ashp_ing_item['count'] ) ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<p class="ashp-emptynote"><?php esc_html_e( 'برای دیدن مواد اولیه، ابتدا باید داده‌ها از پیشخوان آشپزباشی وارد شوند.', 'ashpazbashi' ); ?></p>
		<?php endif; ?>

		<div class="ashp-recipe__actions">
			<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>">
				<?php esc_html_e( 'آشپزی با موادی که دارم', 'ashpazbashi' ); ?>
			</a>
			<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>">
				<?php esc_html_e( 'دیدن همهٔ دستورها', 'ashpazbashi' ); ?>
			</a>
		</div>
	</section>

</div>
<?php get_footer(); ?>
