<?php
/**
 * لایهٔ سئو، GEO و AEO برای آشپزباشی.
 *
 * چرا این فایل لازم شد:
 * دستورهای پخت این سایت «نوشتهٔ وردپرس» نیستند؛ صفحات مجازی‌اند که افزونهٔ
 * ashpazbashi-core با add_rewrite_rule سرو می‌کند. به همین دلیل نقشهٔ سایت
 * پیش‌فرض وردپرس هیچ‌وقت آن‌ها را نمی‌بیند و توابع سئو هم باید بر پایهٔ روتر
 * نوشته شوند، نه بر پایهٔ is_singular()/is_home().
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * اگر افزونهٔ «AshpazBashi SEO» فعال باشد، توابع را آن افزونه زودتر ثبت
 * کرده است (افزونه‌ها پیش از قالب بارگذاری می‌شوند). در آن صورت این فایل
 * کاملاً کنار می‌کشد تا نه خطای «تکرار تابع» بدهد و نه اسکیمای تکراری
 * بسازد. یعنی نصب هر دو با هم بی‌خطر است.
 */
if ( function_exists( 'ashpseo_document_title' ) ) {
	return;
}

define( 'ASHPSEO_BRAND', 'آشپزباشی' );
define( 'ASHPSEO_HOME_TITLE', 'آشپزباشی | دستور پخت غذا و آشپزی خانگی' );
define( 'ASHPSEO_HOME_DESC', 'دستور پخت غذاهای ایرانی، محلی و بین‌المللی با مواد اولیهٔ دقیق و توضیح مرحله‌به‌مرحله. کافی است بگویید چه موادی دارید تا آشپزباشی غذای مناسب را پیشنهاد دهد.' );
define( 'ASHPSEO_SITE_TAGLINE', 'بگو چه موادی داری، آشپزباشی بهترین غذا را پیشنهاد می‌دهد.' );
define( 'ASHPSEO_MAX_TITLE', 60 );
define( 'ASHPSEO_MAX_DESC', 155 );
define( 'ASHPSEO_MIN_ING_RECIPES', 3 );
define( 'ASHPSEO_SITEMAP_CHUNK', 2000 );

/* =========================================================================
 * ۱) ابزارهای پایه
 * ====================================================================== */

/** کوتاه‌سازی متن با حفظ مرز کلمه. */
function ashpseo_cut( $text, $limit ) {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
	if ( '' === $text ) {
		return '';
	}
	if ( ! function_exists( 'mb_strlen' ) ) {
		return strlen( $text ) > $limit ? substr( $text, 0, $limit ) . '…' : $text;
	}
	if ( mb_strlen( $text, 'UTF-8' ) <= $limit ) {
		return $text;
	}
	$cut  = mb_substr( $text, 0, $limit, 'UTF-8' );
	$last = mb_strrpos( $cut, ' ', 0, 'UTF-8' );
	if ( false !== $last && $last > (int) ( $limit * 0.6 ) ) {
		$cut = mb_substr( $cut, 0, $last, 'UTF-8' );
	}
	return rtrim( $cut, '،,.;؛ ' ) . '…';
}

/** طول رشته با پشتیبانی یونیکد. */
function ashpseo_len( $text ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $text, 'UTF-8' ) : strlen( (string) $text );
}

/** ساخت عنوان با پسوند برند، فقط اگر در محدودهٔ مجاز جا شود. */
function ashpseo_title_with_brand( $core, $prefix = '' ) {
	$core = trim( wp_strip_all_tags( (string) $core ) );
	if ( '' === $core ) {
		return '';
	}
	if ( false !== strpos( $core, ASHPSEO_BRAND ) ) {
		return ashpseo_cut( $core, ASHPSEO_MAX_TITLE );
	}
	$full = $prefix . $core . ' | ' . ASHPSEO_BRAND;
	if ( ashpseo_len( $full ) <= ASHPSEO_MAX_TITLE ) {
		return $full;
	}
	$no_prefix = $core . ' | ' . ASHPSEO_BRAND;
	if ( ashpseo_len( $no_prefix ) <= ASHPSEO_MAX_TITLE ) {
		return $no_prefix;
	}
	return ashpseo_cut( $prefix . $core, ASHPSEO_MAX_TITLE );
}

/** آیا افزونهٔ موتور فعال است؟ */
function ashpseo_engine() {
	return ( class_exists( 'ASHP_DB' ) && class_exists( 'ASHP_Router' ) );
}

/* =========================================================================
 * ۱.۵) تصاویر دستورهای پخت
 *
 * اولویت انتخاب تصویر:
 *   ۱. ستون image_url در دیتابیس (عکس واقعی خودتان) — همیشه اول
 *   ۲. عکس اختصاصی همان غذا از بستهٔ تصاویر (۳۳ غذای معروف)
 *   ۳. عکس زیردسته (پلو، خورش، کباب، کیک، سالاد، آش)
 *   ۴. عکس دستهٔ اصلی (ایرانی، دسر، نوشیدنی، …)
 *
 * تصاویر در wp-content/uploads/ashpazbashi-images/ قرار می‌گیرند و
 * map.json همان پوشه، فهرست آن‌ها را نگه می‌دارد. اگر پوشه نباشد،
 * هیچ خطایی رخ نمی‌دهد و سایت مثل قبل کار می‌کند.
 * ====================================================================== */

define( 'ASHPSEO_IMG_DIRNAME', 'ashpazbashi-images' );

function ashpseo_images_dir() {
	$up = wp_get_upload_dir();
	return trailingslashit( $up['basedir'] ) . ASHPSEO_IMG_DIRNAME . '/';
}

function ashpseo_images_base() {
	$up = wp_get_upload_dir();
	return trailingslashit( $up['baseurl'] ) . ASHPSEO_IMG_DIRNAME . '/';
}

function ashpseo_contains( $haystack, $needle ) {
	if ( '' === $needle ) {
		return false;
	}
	if ( function_exists( 'mb_strpos' ) ) {
		return false !== mb_strpos( $haystack, $needle, 0, 'UTF-8' );
	}
	return false !== strpos( $haystack, $needle );
}

/** فهرست تصاویر، با یک بار خواندن در هر درخواست. */
function ashpseo_image_map() {
	static $map = null;
	if ( null !== $map ) {
		return $map;
	}

	$map  = array();
	$file = ashpseo_images_dir() . 'map.json';

	if ( file_exists( $file ) && is_readable( $file ) ) {
		$raw = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$dec = json_decode( (string) $raw, true );
		if ( is_array( $dec ) ) {
			$map = $dec;
		}
	}

	/*
	 * کلیدواژه‌های بلندتر اول بررسی می‌شوند تا «کباب کوبیده» جلوی
	 * «کباب» را نگیرد و تطبیق دقیق‌تر برنده شود.
	 */
	if ( ! empty( $map['dishes'] ) && is_array( $map['dishes'] ) ) {
		$pairs = array();
		foreach ( $map['dishes'] as $entry ) {
			if ( empty( $entry['file'] ) || empty( $entry['match'] ) ) {
				continue;
			}
			foreach ( (array) $entry['match'] as $kw ) {
				$kw = (string) $kw;
				if ( '' !== $kw ) {
					$pairs[] = array(
						'kw'   => $kw,
						'file' => (string) $entry['file'],
						'len'  => ashpseo_len( $kw ),
					);
				}
			}
		}
		usort(
			$pairs,
			function ( $a, $b ) {
				if ( $a['len'] === $b['len'] ) {
					return 0;
				}
				return ( $a['len'] > $b['len'] ) ? -1 : 1;
			}
		);
		$map['_pairs'] = $pairs;
	}

	return $map;
}

/**
 * آدرس تصویر مناسب برای یک دستور پخت.
 *
 * @param array|string $recipe رکورد دستور پخت یا نام آن.
 * @return string آدرس کامل تصویر، یا رشتهٔ خالی.
 */
function ashpseo_recipe_image( $recipe ) {
	$row  = is_array( $recipe ) ? $recipe : array( 'name' => (string) $recipe );
	$base = ashpseo_images_base();
	$map  = ashpseo_image_map();

	// ۱) عکس واقعی ثبت‌شده در دیتابیس
	if ( ! empty( $row['image_url'] ) ) {
		$url = esc_url_raw( $row['image_url'] );
		if ( $url ) {
			return $url;
		}
	}

	if ( empty( $map ) ) {
		return '';
	}

	// ۲) عکس اختصاصی همان غذا
	$name = isset( $row['name'] ) ? (string) $row['name'] : '';
	if ( '' !== $name && ! empty( $map['_pairs'] ) ) {
		foreach ( $map['_pairs'] as $pair ) {
			if ( ashpseo_contains( $name, $pair['kw'] ) ) {
				return $base . 'dishes/' . $pair['file'];
			}
		}
	}

	// ۳) عکس زیردسته
	$sub = isset( $row['subcategory'] ) ? (string) $row['subcategory'] : '';
	if ( '' !== $sub && ! empty( $map['subcategories'][ $sub ] ) ) {
		return $base . 'categories/' . $map['subcategories'][ $sub ];
	}

	// ۴) عکس دستهٔ اصلی
	$cat = isset( $row['category'] ) ? (string) $row['category'] : '';
	if ( '' !== $cat && ! empty( $map['categories'][ $cat ] ) ) {
		return $base . 'categories/' . $map['categories'][ $cat ];
	}

	return '';
}

/** تصویر مناسب برای صفحات فهرست (دسته و زیردسته). */
function ashpseo_list_image() {
	if ( ! ashpseo_engine() ) {
		return '';
	}

	$map = ashpseo_image_map();
	if ( empty( $map ) ) {
		return '';
	}
	$base = ashpseo_images_base();

	$sub = (string) ASHP_Router::current_var( ASHP_Router::VAR_SUB );
	if ( '' !== $sub && ! empty( $map['subcategories'][ $sub ] ) ) {
		return $base . 'categories/' . $map['subcategories'][ $sub ];
	}

	$ctx = ASHP_DB::current_list_context();
	$cat = isset( $ctx['locked_cat'] ) ? (string) $ctx['locked_cat'] : '';
	if ( '' !== $cat && ! empty( $map['categories'][ $cat ] ) ) {
		return $base . 'categories/' . $map['categories'][ $cat ];
	}

	return '';
}

/** نوع صفحهٔ جاری بر پایهٔ روتر، نه وردپرس. */
/**
 * تشخیص دستور پخت از روی نشانی اینترنتی.
 *
 * چرا لازم شد: در لحظه‌ای که وردپرس عنوان صفحه را می‌سازد (wp_head)، متغیر
 * مسیر روتر («ashpq_recipe») هنوز مقداردهی نشده است. نتیجه این بود که
 * is_recipe_page() غلط برمی‌گشت و عنوان صفحهٔ دستور پخت به نوشتهٔ پیش‌فرض
 * وردپرس («سلام دنیا!») می‌افتاد.
 *
 * این تابع مستقل از روتر، خودِ نشانی را می‌خواند و اسلاگ را از دیتابیس
 * بیرون می‌کشد؛ پس در هر زمان‌بندی‌ای کار می‌کند.
 */
function ashpseo_recipe_from_url() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$cache = null;

	if ( ! ashpseo_engine() || ! method_exists( 'ASHP_DB', 'get_by_slug' ) ) {
		return $cache;
	}

	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( '' === $uri ) {
		return $cache;
	}

	$path = (string) parse_url( $uri, PHP_URL_PATH );
	$path = trim( urldecode( $path ), '/' );

	// اگر سایت در زیرپوشه نصب شده باشد، پیشوند را برمی‌داریم.
	$home = trim( (string) parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( '' !== $home && 0 === strpos( $path, $home ) ) {
		$path = ltrim( substr( $path, strlen( $home ) ), '/' );
	}

	if ( preg_match( '#^recipes/(.+)$#u', $path, $m ) ) {
		$slug = trim( $m[1] );
		if ( '' !== $slug ) {
			$row = ASHP_DB::get_by_slug( $slug );
			if ( $row ) {
				$cache = $row;
			}
		}
	}

	return $cache;
}

function ashpseo_kind() {
	if ( ashpseo_engine() ) {
		if ( ASHP_Router::is_recipe_page() ) {
			return 'recipe';
		}
		// روتر در این لحظه آماده نیست؟ خودمان از نشانی تشخیص می‌دهیم.
		if ( ashpseo_recipe_from_url() ) {
			return 'recipe';
		}
		if ( ASHP_Router::is_ingredient_page() ) {
			return 'ingredient';
		}
		if ( ASHP_Router::is_picker_page() ) {
			return 'picker';
		}
		if ( ASHP_Router::is_hub_page() ) {
			return 'hub';
		}
		if ( ASHP_Router::is_list_page() ) {
			return 'list';
		}
	}
	if ( is_front_page() ) {
		return 'home';
	}
	if ( is_search() ) {
		return 'search';
	}
	if ( is_404() ) {
		return '404';
	}
	if ( function_exists( 'is_page' ) && is_page() ) {
		return 'page';
	}
	if ( function_exists( 'is_singular' ) && is_singular() ) {
		return 'singular';
	}
	return 'other';
}

/* =========================================================================
 * ۲) اصلاح پرچم‌های کوئری — ریشهٔ باگ توضیحات متای تکراری
 *
 * ASHP_Router::prevent_404() پرچم is_home را پاک می‌کند اما is_front_page را
 * نه. نتیجه: روی همهٔ صفحات مجازی، is_front_page() مقدار true می‌گیرد و
 * ashpazbashi_meta_description() همیشه شعار سایت را برمی‌گرداند.
 * این هوک بعد از handle_404() و پیش از رندر قالب پارچم‌ها را درست می‌کند.
 * ====================================================================== */

function ashpseo_fix_query_flags() {
	if ( ! ashpseo_engine() || ! ASHP_Router::is_ashp_page() ) {
		return;
	}

	global $wp_query;
	if ( ! ( $wp_query instanceof WP_Query ) ) {
		return;
	}

	$wp_query->is_404        = false;
	$wp_query->is_home       = false;
	$wp_query->is_front_page = false;
	$wp_query->is_archive    = false;
	$wp_query->is_category   = false;
	$wp_query->is_page       = false;

	$single = ( ASHP_Router::is_recipe_page() || ASHP_Router::is_ingredient_page() );
	$wp_query->is_singular = $single;
	$wp_query->is_single   = $single;
}
add_action( 'wp', 'ashpseo_fix_query_flags', 1 );

/* =========================================================================
 * ۳) عنوان صفحه
 * ====================================================================== */

function ashpseo_document_title( $parts ) {
	$kind  = ashpseo_kind();
	$title = '';

	switch ( $kind ) {
		case 'home':
			$title = ASHPSEO_HOME_TITLE;
			break;

		case 'recipe':
			$r = ASHP_DB::current_recipe();
			if ( ! $r ) {
				$r = ashpseo_recipe_from_url();
			}
			if ( $r ) {
				$title = ashpseo_title_with_brand( $r['name'], 'طرز تهیه ' );
			}
			break;

		case 'ingredient':
			$i = ASHP_DB::current_ingredient();
			if ( $i ) {
				$title = ashpseo_title_with_brand( sprintf( 'غذاهایی که با %s می‌توان پخت', $i['name'] ) );
			}
			break;

		case 'picker':
			$title = ashpseo_title_with_brand( 'آشپزی با مواد موجود در خانه', '' );
			break;

		case 'hub':
			$title = ashpseo_title_with_brand( ASHP_Router::hub_title() );
			break;

		case 'list':
			$ctx   = ASHP_DB::current_list_context();
			$title = ashpseo_title_with_brand( isset( $ctx['title'] ) ? $ctx['title'] : '' );
			if ( isset( $ctx['page'] ) && $ctx['page'] > 1 ) {
				$title .= ' — صفحهٔ ' . (int) $ctx['page'];
			}
			break;

		case 'page':
		case 'singular':
			$title = ashpseo_title_with_brand( get_the_title() );
			break;
	}

	if ( '' !== $title ) {
		$parts['title'] = $title;
	}

	/*
	 * رفع «سلام دنیا!» در عنوان مرورگر.
	 *
	 * وردپرس روی مسیرهای مجازی آشپزباشی، is_front_page را true می‌بیند و
	 * single_post_title() را صدا می‌زند که عنوان نخستین نوشتهٔ پیش‌فرض
	 * («سلام دنیا!») را برمی‌گرداند. سپس نام سایت هم به انتهای عنوان
	 * اضافه می‌شود. این دو خط، هر دو منبع آلودگی را قطع می‌کنند.
	 */
	$parts['site']    = '';
	$parts['tagline'] = '';
	$parts['page']    = '';

	return $parts;
}
add_filter( 'document_title_parts', 'ashpseo_document_title', 9999 );

/**
 * پاکسازی نهایی عنوان مرورگر.
 *
 * مسیرهای مجازی آشپزباشی «برگهٔ واقعی وردپرس» نیستند. در این حالت وردپرس
 * is_front_page را true می‌بیند و single_post_title() را صدا می‌زند که
 * عنوان نخستین نوشتهٔ پیش‌فرض («سلام دنیا!») را برمی‌گرداند؛ شعار سایت هم
 * به انتهای عنوان چسبانده می‌شود. نتیجه چیزی مثل «سلام دنیا! آشپزباشی»
 * می‌شود.
 *
 * این فیلتر روی «رشتهٔ نهایی» کار می‌کند، پس مستقل از این‌که وردپرس عنوان
 * را چگونه سرهم کرده باشد، آلودگی را پاک می‌کند.
 */
function ashpseo_clean_final_title( $title ) {
	$title = (string) $title;
	if ( '' === trim( $title ) ) {
		return $title;
	}

	$junk = array(
		'سلام دنیا!',
		'سلام دنیا',
		'Hello world!',
		'Hello World',
		'Just another WordPress site',
	);

	if ( defined( 'ASHP_TAGLINE' ) && ASHP_TAGLINE ) {
		$junk[] = (string) ASHP_TAGLINE;
	}

	// شعار ثبت‌شده در تنظیمات، به‌شرط آن‌که خود نام برند را پاک نکند.
	$blog_desc = (string) get_option( 'blogdescription', '' );
	if ( '' !== trim( $blog_desc ) && false === strpos( $blog_desc, ASHPSEO_BRAND ) ) {
		$junk[] = $blog_desc;
	}

	foreach ( $junk as $j ) {
		$j = trim( (string) $j );
		if ( '' !== $j && false !== strpos( $title, $j ) ) {
			$title = str_replace( $j, '', $title );
		}
	}

	// جداکننده‌های تکراری و سرگردان
	$title = preg_replace( '/\s*[\|\-–—]\s*(?:\s*[\|\-–—]\s*)+/u', ' | ', $title );
	$title = preg_replace( '/\s{2,}/u', ' ', (string) $title );
	$title = trim( (string) $title, " \t\n\r\0\x0B|\-–—" );

	if ( '' === $title ) {
		$title = ASHPSEO_HOME_TITLE;
	} elseif ( false === strpos( $title, ASHPSEO_BRAND ) ) {
		$title .= ' | ' . ASHPSEO_BRAND;
	}

	return $title;
}
add_filter( 'document_title', 'ashpseo_clean_final_title', 9999 );


/** در نبود پشتیبانی عنوان، متن تگ را دستی بساز. */
function ashpseo_wp_title_fallback() {
	if ( current_theme_supports( 'title-tag' ) ) {
		return;
	}
	$parts = ashpseo_document_title( array( 'title' => '', 'tagline' => '' ) );
	$t     = trim( (string) $parts['title'] );
	if ( '' !== $t ) {
		echo '<title>' . esc_html( $t ) . '</title>' . "\n";
	}
}
add_action( 'wp_head', 'ashpseo_wp_title_fallback', 1 );

/* =========================================================================
 * ۴) توضیحات متا — یکتا برای هر صفحه
 * ====================================================================== */

function ashpseo_description() {
	$kind = ashpseo_kind();

	if ( 'recipe' === $kind ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			return ashpseo_cut( ashpseo_recipe_description( $r ), ASHPSEO_MAX_DESC );
		}
	}

	if ( 'ingredient' === $kind ) {
		$i = ASHP_DB::current_ingredient();
		if ( $i ) {
			$n = isset( $i['recipes_count'] ) ? (int) $i['recipes_count'] : 0;
			if ( $n > 0 ) {
				return ashpseo_cut(
					sprintf(
						'%s دستور پخت که با %s می‌توانید بپزید — از غذاهای ایرانی و محلی تا دسر و پیش‌غذا، همراه با مواد اولیهٔ دقیق و مراحل گام‌به‌گام.',
						number_format_i18n( $n ),
						$i['name']
					),
					ASHPSEO_MAX_DESC
				);
			}
			return ashpseo_cut(
				sprintf( 'همهٔ دستورهای پختی که با %s تهیه می‌شوند، با مواد اولیهٔ دقیق و آموزش مرحله‌به‌مرحله در آشپزباشی.', $i['name'] ),
				ASHPSEO_MAX_DESC
			);
		}
	}

	if ( 'picker' === $kind ) {
		return ashpseo_cut(
			'موادی که در خانه دارید را انتخاب کنید تا آشپزباشی فهرست غذاهایی را نشان دهد که با همان مواد قابل پخت هستند. بدون خرید اضافه.',
			ASHPSEO_MAX_DESC
		);
	}

	if ( 'hub' === $kind ) {
		$hub = get_query_var( ASHP_Router::VAR_HUB );
		if ( '' === $hub && isset( $_GET[ ASHP_Router::VAR_HUB ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$hub = sanitize_key( wp_unslash( $_GET[ ASHP_Router::VAR_HUB ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		$map = array(
			'food'   => 'همهٔ غذاها و مواد اولیهٔ آشپزباشی یک‌جا: دستورهای ایرانی، محلی، فرنگی، پیش‌غذا و فست‌فود با آموزش مرحله‌به‌مرحله.',
			'party'  => 'ایده و دستور پخت برای فود پارتی و پذیرایی: پیش‌غذا، انگشتی و غذاهای مناسب مهمانی، با مواد اولیهٔ دقیق.',
			'kids'   => 'دستور پخت غذای کودکان؛ ساده، مقوی و مورد علاقهٔ بچه‌ها برای وعده‌های اصلی و میان‌وعده.',
			'sweets' => 'دستور پخت دسر، شیرینی، کیک و نوشیدنی خانگی با مواد اولیهٔ ساده و توضیح گام‌به‌گام.',
			'drinks' => 'دستور تهیهٔ انواع نوشیدنی خانگی، شربت، اسموتی و دمنوش با آموزش مرحله‌به‌مرحله.',
		);
		if ( isset( $map[ $hub ] ) ) {
			return ashpseo_cut( $map[ $hub ], ASHPSEO_MAX_DESC );
		}
		return ashpseo_cut( ASHPSEO_HOME_DESC, ASHPSEO_MAX_DESC );
	}

	if ( 'list' === $kind ) {
		$ctx  = ASHP_DB::current_list_context();
		$base = isset( $ctx['desc'] ) && '' !== $ctx['desc'] ? $ctx['desc'] : '';

		$total = isset( $ctx['total'] ) ? (int) $ctx['total'] : 0;
		$name  = isset( $ctx['title'] ) ? (string) $ctx['title'] : '';
		$cat   = isset( $ctx['locked_cat'] ) ? (string) $ctx['locked_cat'] : '';

		if ( $total > 0 ) {
			$count_txt = sprintf( '%s دستور پخت', number_format_i18n( $total ) );

			if ( '' === $cat ) {
				// فهرست کل: /recipes/
				return ashpseo_cut(
					sprintf(
						'مجموعهٔ کامل %s آشپزباشی — از غذاهای ایرانی و محلی تا پیش‌غذا، فست‌فود، دسر و نوشیدنی، همراه با مواد اولیهٔ دقیق و آموزش مرحله‌به‌مرحله.',
						$count_txt
					),
					ASHPSEO_MAX_DESC
				);
			}

			if ( '' !== $base ) {
				return ashpseo_cut( $count_txt . ' در ' . $name . ' — ' . $base, ASHPSEO_MAX_DESC );
			}

			return ashpseo_cut(
				sprintf(
					'%s در %s — همراه با مواد اولیهٔ دقیق، زمان پخت و آموزش مرحله‌به‌مرحله در آشپزباشی.',
					$count_txt,
					$name
				),
				ASHPSEO_MAX_DESC
			);
		}

		if ( '' !== $base ) {
			return ashpseo_cut( $base, ASHPSEO_MAX_DESC );
		}
		return ashpseo_cut( 'فهرست کامل دستورهای پخت آشپزباشی با مواد اولیهٔ دقیق و مراحل گام‌به‌گام.', ASHPSEO_MAX_DESC );
	}

	if ( 'home' === $kind ) {
		return ASHPSEO_HOME_DESC;
	}

	if ( 'page' === $kind || 'singular' === $kind ) {
		$post_id = get_queried_object_id();
		$custom  = $post_id ? get_post_meta( $post_id, '_ashpseo_desc', true ) : '';
		if ( $custom ) {
			return ashpseo_cut( $custom, ASHPSEO_MAX_DESC );
		}
		$excerpt = get_the_excerpt( $post_id );
		if ( $excerpt ) {
			$excerpt = ashpseo_cut( $excerpt, ASHPSEO_MAX_DESC );
			if ( ashpseo_len( $excerpt ) > 50 ) {
				return $excerpt;
			}
		}
		$content = ashpseo_cut( get_post_field( 'post_content', $post_id ), ASHPSEO_MAX_DESC );
		if ( ashpseo_len( $content ) > 50 ) {
			return $content;
		}
	}

	return '';
}

/** توضیح یکتای یک دستور پخت، ساخته‌شده از دادهٔ واقعی همان رکورد. */
function ashpseo_recipe_description( $r ) {
	$bits = array( 'طرز تهیه ' . $r['name'] );

	/*
	 * توجه: اگر subcategory خالی باشد، subcategory_label مقدار null برمی‌گرداند
	 * و در PHP مقایسهٔ '' !== null مقدار true می‌دهد. پس باید صریحاً به رشته
	 * تبدیل شود، وگرنه متن توضیحات خراب می‌شود.
	 */
	$sub_raw = isset( $r['subcategory'] ) ? (string) $r['subcategory'] : '';
	$sub     = trim( (string) ASHP_DB::subcategory_label( $r['category'], $sub_raw ) );
	$cat     = trim( (string) ASHP_DB::category_label( $r['category'] ) );
	$kind    = ( '' !== $sub && $sub !== $cat ) ? $sub : $cat;
	if ( '' === $kind ) {
		$kind = 'غذای خانگی';
	}

	$prep = isset( $r['prep_time_min'] ) ? (float) $r['prep_time_min'] : 0;
	$cook = isset( $r['cook_time_min'] ) ? (float) $r['cook_time_min'] : 0;
	$mins = (int) round( $prep + $cook );

	$second = 'دستور کامل ' . $kind;
	if ( $mins > 0 ) {
		$second .= sprintf( ' در %s دقیقه', number_format_i18n( $mins ) );
	}
	if ( ! empty( $r['servings'] ) ) {
		$second .= sprintf( ' برای %s نفر', number_format_i18n( (int) $r['servings'] ) );
	}
	$second .= '؛ مواد اولیهٔ دقیق و مراحل گام‌به‌گام.';

	return $bits[0] . ' — ' . $second;
}

/* =========================================================================
 * ۵) تگ canonical
 * ====================================================================== */

function ashpseo_canonical() {
	$kind = ashpseo_kind();
	$url  = '';

	if ( 'recipe' === $kind ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			$url = ASHP_DB::recipe_url( $r );
		}
	} elseif ( 'ingredient' === $kind ) {
		$i = ASHP_DB::current_ingredient();
		if ( $i ) {
			$url = ASHP_DB::ingredient_url( $i['slug'] );
		}
	} elseif ( 'picker' === $kind ) {
		$url = home_url( '/ingredients/' );
	} elseif ( 'hub' === $kind ) {
		$hub = get_query_var( ASHP_Router::VAR_HUB );
		if ( '' === $hub && isset( $_GET[ ASHP_Router::VAR_HUB ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$hub = sanitize_key( wp_unslash( $_GET[ ASHP_Router::VAR_HUB ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		$url = $hub ? ASHP_Router::hub_url( $hub ) : home_url( '/' );
	} elseif ( 'list' === $kind ) {
		$ctx = ASHP_DB::current_list_context();
		$url = isset( $ctx['base_url'] ) ? $ctx['base_url'] : home_url( '/recipes/' );

		/*
		 * صفحه‌بندی و فیلترها canonical جدا ندارند؛ همه به صفحهٔ اصلی فهرست
		 * اشاره می‌کنند تا محتوای تکراری ساخته نشود.
		 */
	} elseif ( 'home' === $kind ) {
		$url = home_url( '/' );
	} elseif ( 'page' === $kind || 'singular' === $kind ) {
		$url = get_permalink( get_queried_object_id() );
	}

	return $url ? $url : '';
}

/* =========================================================================
 * ۶) اسکیمای سازمان، وب‌سایت و مسیر راهنما (GEO)
 * ====================================================================== */

function ashpseo_breadcrumbs() {
	$items = array( array( 'name' => ASHPSEO_BRAND, 'url' => home_url( '/' ) ) );
	$kind  = ashpseo_kind();

	if ( 'home' === $kind ) {
		return $items;
	}

	if ( 'recipe' === $kind ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			$items[] = array(
				'name' => ASHP_DB::category_label( $r['category'] ),
				'url'  => ASHP_DB::category_url( $r['category'] ),
			);
			if ( ! empty( $r['subcategory'] ) ) {
				$items[] = array(
					'name' => ASHP_DB::subcategory_label( $r['category'], $r['subcategory'] ),
					'url'  => ASHP_DB::subcategory_url( $r['category'], $r['subcategory'] ),
				);
			}
			$items[] = array( 'name' => $r['name'], 'url' => ASHP_DB::recipe_url( $r ) );
		}
		return $items;
	}

	if ( 'ingredient' === $kind ) {
		$items[] = array( 'name' => 'مواد اولیه', 'url' => home_url( '/ingredients/' ) );
		$i       = ASHP_DB::current_ingredient();
		if ( $i ) {
			$items[] = array( 'name' => $i['name'], 'url' => ASHP_DB::ingredient_url( $i['slug'] ) );
		}
		return $items;
	}

	if ( 'list' === $kind ) {
		$ctx = ASHP_DB::current_list_context();
		if ( ! empty( $ctx['parent_label'] ) && ! empty( $ctx['parent_url'] ) ) {
			$items[] = array( 'name' => $ctx['parent_label'], 'url' => $ctx['parent_url'] );
		}
		if ( ! empty( $ctx['title'] ) ) {
			$items[] = array( 'name' => $ctx['title'], 'url' => '' );
		}
		return $items;
	}

	if ( 'hub' === $kind ) {
		$items[] = array( 'name' => ASHP_Router::hub_title(), 'url' => ashpseo_canonical() );
		return $items;
	}

	if ( 'page' === $kind || 'singular' === $kind ) {
		$items[] = array( 'name' => get_the_title(), 'url' => get_permalink( get_queried_object_id() ) );
	}

	return $items;
}

function ashpseo_graph_schema() {
	$home = home_url( '/' );

	$organization = array(
		'@type'         => 'Organization',
		'@id'           => $home . '#organization',
		'name'          => ASHPSEO_BRAND,
		'alternateName' => array( 'آشپز باشی', 'AshpazBashie' ),
		'url'           => $home,
		'description'   => 'آشپزباشی مرجع دستور پخت غذاهای ایرانی و بین‌المللی با مواد اولیهٔ دقیق و آموزش مرحله‌به‌مرحله.',
		'logo'          => array(
			'@type' => 'ImageObject',
			'url'   => get_template_directory_uri() . '/assets/img/logo.png',
			'width' => 512,
			'height'=> 512,
		),
	);

	$socials = array();
	foreach ( array( 'instagram', 'telegram', 'aparat', 'youtube', 'twitter', 'facebook' ) as $key ) {
		$val = get_option( 'ashpseo_social_' . $key, '' );
		if ( $val ) {
			$socials[] = esc_url_raw( $val );
		}
	}
	if ( $socials ) {
		$organization['sameAs'] = array_values( array_unique( $socials ) );
	}

	$website = array(
		'@type'           => 'WebSite',
		'@id'             => $home . '#website',
		'url'             => $home,
		'name'            => ASHPSEO_BRAND,
		'inLanguage'      => 'fa-IR',
		'publisher'       => array( '@id' => $home . '#organization' ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array(
				'@type'       => 'EntryPoint',
				'urlTemplate' => $home . '?s={search_term_string}',
			),
			'query-input' => 'required name=search_term_string',
		),
	);

	$graph = array( $organization, $website );

	$crumbs = ashpseo_breadcrumbs();
	if ( count( $crumbs ) > 1 ) {
		$elements = array();
		$pos      = 1;
		foreach ( $crumbs as $crumb ) {
			$item = array(
				'@type'    => 'ListItem',
				'position' => $pos,
				'name'     => $crumb['name'],
			);
			if ( ! empty( $crumb['url'] ) ) {
				$item['item'] = $crumb['url'];
			}
			$elements[] = $item;
			$pos++;
		}
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'@id'             => ashpseo_canonical() . '#breadcrumb',
			'itemListElement' => $elements,
		);
	}

	return array(
		'@context' => 'https://schema.org',
		'@graph'   => $graph,
	);
}

function ashpseo_print_graph_schema() {
	$kind = ashpseo_kind();
	if ( '404' === $kind || 'search' === $kind ) {
		return;
	}
	$json = wp_json_encode( ashpseo_graph_schema(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( $json ) {
		echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- JSON امن
	}
}
add_action( 'wp_head', 'ashpseo_print_graph_schema', 8 );

/* =========================================================================
 * ۷) تکمیل دادهٔ ساختاریافتهٔ دستور پخت
 * ====================================================================== */

/**
 * دادهٔ اسکیمای Recipe را با فیلدهای جاافتاده کامل می‌کند.
 *
 * مهم: فیلد image در Google برای نمایش کارت دستور پخت «اجباری» است.
 * مقدار آن از ستون image_url دیتابیس خوانده می‌شود که در نسخهٔ فعلی
 * برای هیچ دستوری پر نشده؛ به‌محض پر شدن، خودکار وارد اسکیما می‌شود.
 */
function ashpseo_schema_data( $recipe ) {
	if ( ! class_exists( 'ASHP_Front' ) ) {
		return array();
	}

	$data = ASHP_Front::schema_data( $recipe );
	if ( empty( $data ) || ! is_array( $data ) ) {
		return $data;
	}

	/*
	 * فیلد image برای Google «اجباری» است. اگر عکس واقعی در دیتابیس نباشد،
	 * عکس اختصاصی غذا یا عکس دسته استفاده می‌شود تا صفحه واجد شرایط
	 * نمایش کارت دستور پخت شود.
	 */
	$img = ashpseo_recipe_image( $recipe );
	if ( $img ) {
		$data['image'] = array( $img );
	}

	if ( empty( $data['description'] ) ) {
		$data['description'] = ashpseo_recipe_description( $recipe );
	}

	if ( empty( $data['keywords'] ) ) {
		$kw      = array( (string) $recipe['name'] );
		$sub_raw = isset( $recipe['subcategory'] ) ? (string) $recipe['subcategory'] : '';
		$sub     = trim( (string) ASHP_DB::subcategory_label( $recipe['category'], $sub_raw ) );
		if ( '' !== $sub ) {
			$kw[] = $sub;
		}
		$kw[] = trim( (string) ASHP_DB::category_label( $recipe['category'] ) );
		if ( ! empty( $recipe['cuisine'] ) ) {
			$kw[] = (string) $recipe['cuisine'];
		}
		$data['keywords'] = implode( '، ', array_unique( array_filter( $kw ) ) );
	}

	if ( empty( $data['mainEntityOfPage'] ) ) {
		$data['mainEntityOfPage'] = array(
			'@type' => 'WebPage',
			'@id'   => ASHP_DB::recipe_url( $recipe ),
		);
	}

	/*
	 * میانگین امتیاز کاربران.
	 * فقط از نظرهای تأییدشده ساخته می‌شود. اگر امتیازی وجود نداشته باشد،
	 * این بخش اضافه نمی‌شود — چون آوردن امتیاز جعلی در اسکیما تخلف است.
	 */
	if ( class_exists( 'ASHP_Comments' ) && ! empty( $recipe['id'] ) ) {
		$ashp_stats = ASHP_Comments::stats( (int) $recipe['id'] );
		if ( $ashp_stats['count'] > 0 && $ashp_stats['average'] > 0 ) {
			$data['aggregateRating'] = array(
				'@type'       => 'AggregateRating',
				'ratingValue' => (string) $ashp_stats['average'],
				'ratingCount' => (int) $ashp_stats['count'],
				'bestRating'  => '5',
				'worstRating' => '1',
			);
		}
	}

	return $data;
}

/* =========================================================================
 * ۸) نقشهٔ سایت — دستورهای پخت نوشتهٔ وردپرس نیستند، پس نقشهٔ پیش‌فرض
 *    هیچ‌وقت آن‌ها را نمی‌بیند. این بخش نقشهٔ اختصاصی می‌سازد.
 * ====================================================================== */

/**
 * آماده‌سازی آدرس برای درج در XML نقشه.
 *
 * اسلاگ‌های فارسی باید درصدگذاری شوند و & باید به &amp; تبدیل شود،
 * وگرنه فایل نقشه از نظر استاندارد sitemap نامعتبر است.
 */
function ashpseo_xml_url( $url ) {
	$parts = wp_parse_url( $url );
	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return htmlspecialchars( (string) $url, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}

	$out = $parts['scheme'] . '://' . $parts['host'];
	if ( ! empty( $parts['port'] ) ) {
		$out .= ':' . (int) $parts['port'];
	}

	$path = isset( $parts['path'] ) ? (string) $parts['path'] : '/';
	$segs = explode( '/', $path );
	$segs = array_map(
		function ( $seg ) {
			return rawurlencode( rawurldecode( $seg ) );
		},
		$segs
	);
	$out .= implode( '/', $segs );

	if ( ! empty( $parts['query'] ) ) {
		$out .= '?' . $parts['query'];
	}

	return htmlspecialchars( $out, ENT_QUOTES | ENT_XML1, 'UTF-8' );
}

/** بخش‌های نقشه: کلید => [تعداد کل] */
function ashpseo_sitemap_sections() {
	global $wpdb;

	$out = array();

	$recipes_tbl = $wpdb->prefix . 'ashp_recipes';
	// نام واقعی جدول از تابع خود افزونه خوانده می‌شود تا با تغییر پیشوند نشکند.
	if ( function_exists( 'ashp_core_table' ) ) {
		$recipes_tbl = ashp_core_table( 'recipes' );
	}
	$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes_tbl WHERE is_active = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
	$out['recipes'] = max( 0, $count );

	$ings_tbl = function_exists( 'ashp_core_table' ) ? ashp_core_table( 'ingredients' ) : $wpdb->prefix . 'ashp_ingredients';
	$count_i  = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->prepare( "SELECT COUNT(*) FROM $ings_tbl WHERE recipes_count >= %d", ASHPSEO_MIN_ING_RECIPES )
	);
	$out['ingredients'] = max( 0, $count_i );

	$out['tax'] = 1;

	return $out;
}

/** خروجی XML بخشی از نقشه. */
function ashpseo_sitemap_output( $section, $chunk ) {
	global $wpdb;

	$offset = ( max( 1, (int) $chunk ) - 1 ) * ASHPSEO_SITEMAP_CHUNK;
	$urls   = array();

	if ( 'recipes' === $section ) {
		$tbl = function_exists( 'ashp_core_table' ) ? ashp_core_table( 'recipes' ) : $wpdb->prefix . 'ashp_recipes';
		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare(
				"SELECT slug FROM $tbl WHERE is_active = 1 ORDER BY id ASC LIMIT %d OFFSET %d",
				ASHPSEO_SITEMAP_CHUNK,
				$offset
			)
		);
		foreach ( (array) $rows as $slug ) {
			$slug = trim( (string) $slug );
			if ( '' !== $slug ) {
				$urls[] = ASHP_DB::recipe_url( $slug );
			}
		}
	} elseif ( 'ingredients' === $section ) {
		$tbl  = function_exists( 'ashp_core_table' ) ? ashp_core_table( 'ingredients' ) : $wpdb->prefix . 'ashp_ingredients';
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare(
				"SELECT slug FROM $tbl WHERE recipes_count >= %d ORDER BY recipes_count DESC, id ASC LIMIT %d OFFSET %d",
				ASHPSEO_MIN_ING_RECIPES,
				ASHPSEO_SITEMAP_CHUNK,
				$offset
			),
			ARRAY_A
		);
		foreach ( (array) $rows as $row ) {
			$slug = isset( $row['slug'] ) ? trim( (string) $row['slug'] ) : '';
			if ( '' !== $slug ) {
				$urls[] = ASHP_DB::ingredient_url( $slug );
			}
		}
	} elseif ( 'tax' === $section ) {
		$urls[] = home_url( '/' );
		$urls[] = home_url( '/recipes/' );
		$urls[] = home_url( '/ingredients/' );

		foreach ( array( 'food', 'sweets', 'party', 'kids' ) as $hub ) {
			$urls[] = ASHP_Router::hub_url( $hub );
		}

		foreach ( ASHP_DB::taxonomy() as $cat => $info ) {
			$urls[] = ASHP_DB::category_url( $cat );
			foreach ( array_keys( $info['subs'] ) as $sub ) {
				$urls[] = ASHP_DB::subcategory_url( $cat, $sub );
			}
		}

		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'fields'         => 'ids',
			)
		);
		foreach ( $pages as $pid ) {
			if ( 'page-error504.php' === get_page_template_slug( $pid ) ) {
				continue;
			}
			$urls[] = get_permalink( $pid );
		}
	}

	$urls = array_values( array_unique( array_filter( $urls ) ) );

	nocache_headers();
	header( 'Content-Type: application/xml; charset=UTF-8' );

	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ( $urls as $u ) {
		echo "\t<url><loc>" . ashpseo_xml_url( $u ) . "</loc></url>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- خودش XML-escape می‌کند
	}
	echo '</urlset>' . "\n";
}

/** خروجی فهرست نقشه‌ها. */
function ashpseo_sitemap_index() {
	$sections = ashpseo_sitemap_sections();
	$base     = home_url( '/' );

	nocache_headers();
	header( 'Content-Type: application/xml; charset=UTF-8' );

	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

	foreach ( array( 'recipes', 'ingredients' ) as $key ) {
		$total  = isset( $sections[ $key ] ) ? (int) $sections[ $key ] : 0;
		$chunks = (int) ceil( $total / ASHPSEO_SITEMAP_CHUNK );
		for ( $i = 1; $i <= $chunks; $i++ ) {
			$loc = $base . 'sitemap-' . $key . '-' . $i . '.xml';
			echo "\t<sitemap><loc>" . esc_url( $loc ) . "</loc></sitemap>\n";
		}
	}

	echo "\t<sitemap><loc>" . esc_url( $base . 'sitemap-tax-1.xml' ) . "</loc></sitemap>\n";
	echo '</sitemapindex>' . "\n";
}

/**
 * سرو نقشهٔ سایت.
 *
 * عمداً از قواعد بازنویسی استفاده نمی‌کنیم تا بعد از جایگزینی فایل‌های قالب
 * نیازی به «ذخیرهٔ پیوندهای یکتا» نباشد و بدون هیچ تنظیمی کار کند.
 */
function ashpseo_serve_sitemap() {
	if ( is_admin() || ! isset( $_SERVER['REQUEST_URI'] ) ) {
		return;
	}

	// بدون افزونهٔ موتور، داده‌ای برای فهرست کردن وجود ندارد.
	if ( ! ashpseo_engine() ) {
		return;
	}

	$home_path = trim( (string) parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	$req_path  = trim( (string) parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

	if ( '' !== $home_path && 0 === strpos( $req_path, $home_path ) ) {
		$req_path = ltrim( substr( $req_path, strlen( $home_path ) ), '/' );
	}

	/*
	 * روی این سرور، /sitemap.xml به نقشهٔ پیش‌فرض وردپرس ارجاع داده می‌شود.
	 * نقشهٔ پیش‌فرض هم دستورهای پخت را نمی‌بیند (چون نوشتهٔ وردپرس نیستند)،
	 * پس هر سه مسیر را خودمان سرو می‌کنیم.
	 */
	if ( in_array( $req_path, array( 'sitemap.xml', 'sitemap_index.xml', 'wp-sitemap.xml' ), true ) ) {
		status_header( 200 );
		ashpseo_sitemap_index();
		exit;
	}

	if ( preg_match( '#^sitemap-(recipes|ingredients|tax)-(\d+)\.xml$#', $req_path, $m ) ) {
		status_header( 200 );
		ashpseo_sitemap_output( $m[1], (int) $m[2] );
		exit;
	}
}
add_action( 'template_redirect', 'ashpseo_serve_sitemap', 1 );

/**
 * افزودن نقشهٔ سایت به robots.txt.
 *
 * خط پیش‌فرض وردپرس (wp-sitemap.xml) حذف می‌شود، چون فقط ۱ نوشته و
 * ۷ برگه را فهرست می‌کند و ۴٬۶۳۱ دستور پخت را نمی‌بیند.
 */
function ashpseo_robots_txt( $output, $public ) {
	if ( ! $public ) {
		return $output;
	}

	$lines = preg_split( '/\r\n|\r|\n/', (string) $output );
	$lines = array_filter(
		$lines,
		function ( $l ) {
			return ( 0 !== stripos( trim( $l ), 'sitemap:' ) );
		}
	);

	$lines[] = '';
	$lines[] = 'Sitemap: ' . home_url( '/sitemap.xml' );

	return implode( "\n", $lines ) . "\n";
}
add_filter( 'robots_txt', 'ashpseo_robots_txt', 20, 2 );

/* =========================================================================
 * ۹) کنترل ایندکس — جلوگیری از انبوه صفحات بی‌ارزش
 * ====================================================================== */

function ashpseo_robots_meta( $robots ) {
	$kind = ashpseo_kind();

	// صفحات ابزاری و نتیجهٔ جست‌وجو نباید ایندکس شوند.
	if ( in_array( $kind, array( 'picker', 'search', '404' ), true ) ) {
		$robots['noindex']  = true;
		$robots['follow']   = true;
		unset( $robots['index'] );
		return $robots;
	}

	if ( 'list' === $kind ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$has_filter = isset( $_GET['q'] ) || isset( $_GET['sort'] ) || ( isset( $_GET['cat'] ) && '' !== $_GET['cat'] );
		$page_no    = isset( $_GET['ashp_page'] ) ? (int) $_GET['ashp_page'] : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$noindex = ( $has_filter || $page_no > 1 );

		/*
		 * دسته‌ها/زیردسته‌های «نازک»: بعضی زیردسته‌ها فقط ۱ تا ۳ دستور دارند
		 * (مثلاً iranian-local/khorak با ۲ دستور در برابر iranian-formal/khorak
		 * با ۲۳۰ دستور). این صفحه‌ها محتوای نزدیک به تکراری می‌سازند و رتبه هم
		 * نمی‌گیرند؛ پس ایندکس نمی‌شوند ولی لینک‌هایشان دنبال می‌شود.
		 *
		 * آستانه با فیلتر ashpseo_min_recipes_to_index قابل تغییر است.
		 */
		if ( ! $noindex && ashpseo_engine() ) {
			$min    = (int) apply_filters( 'ashpseo_min_recipes_to_index', 3 );
			$ctx    = ASHP_DB::current_list_context();
			$locked = isset( $ctx['locked_cat'] ) ? (string) $ctx['locked_cat'] : '';

			if ( '' !== $locked && isset( $ctx['total'] ) && (int) $ctx['total'] < $min ) {
				$noindex = true;
			}
		}

		if ( $noindex ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['index'] );
		}
	}

	return $robots;
}
add_filter( 'wp_robots', 'ashpseo_robots_meta' );

/** صفحه‌های بی‌محتوا را از ایندکس بیرون بگذار. */
function ashpseo_noindex_pages( $robots ) {
	if ( ! is_page() ) {
		return $robots;
	}
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		return $robots;
	}
	$noindex = apply_filters(
		'ashpseo_noindex_page_slugs',
		array( 'sample-page', 'برگه-نمونه', 'privacy-policy' )
	);
	if ( in_array( $post->post_name, $noindex, true ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['index'] );
	}
	return $robots;
}
add_filter( 'wp_robots', 'ashpseo_noindex_pages' );

/* =========================================================================
 * ۱۰) جعبهٔ ویرایش عنوان/توضیحات برای برگه‌ها و نوشته‌های واقعی وردپرس
 * ====================================================================== */

add_action( 'add_meta_boxes', function () {
	foreach ( array( 'post', 'page' ) as $type ) {
		add_meta_box(
			'ashpseo_metabox',
			'سئو (آشپزباشی)',
			'ashpseo_render_metabox',
			$type,
			'normal',
			'default'
		);
	}
} );

function ashpseo_render_metabox( $post ) {
	wp_nonce_field( 'ashpseo_save_meta', 'ashpseo_nonce' );
	$desc = get_post_meta( $post->ID, '_ashpseo_desc', true );
	printf(
		'<p><label for="ashpseo_desc"><strong>توضیحات متا</strong> — حداکثر ۱۵۵ کاراکتر. اگر خالی بماند از متن همین برگه ساخته می‌شود.</label>' .
		'<textarea id="ashpseo_desc" name="ashpseo_desc" class="widefat" rows="3" maxlength="200">%s</textarea></p>' .
		'<p style="color:#666">برای برگه‌های اصلی مثل «درباره ما» و «تماس با ما» پر کردن این فیلد توصیه می‌شود.</p>',
		esc_textarea( $desc )
	);
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['ashpseo_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ashpseo_nonce'] ) ), 'ashpseo_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$desc = isset( $_POST['ashpseo_desc'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ashpseo_desc'] ) ) : '';
	if ( '' !== $desc ) {
		update_post_meta( $post_id, '_ashpseo_desc', $desc );
	} else {
		delete_post_meta( $post_id, '_ashpseo_desc' );
	}
} );

/* =========================================================================
 * ۱۱) خروجی canonical و شبکه‌های اجتماعی
 * ====================================================================== */

function ashpseo_head_output() {
	$kind = ashpseo_kind();
	if ( in_array( $kind, array( '404', 'search' ), true ) ) {
		return;
	}

	$url = ashpseo_canonical();
	if ( $url ) {
		printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
		printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
	}

	$desc = ashpseo_description();
	if ( $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
		printf( '<meta name="twitter:description" content="%s">' . "\n", esc_attr( $desc ) );
	}

	$title = wp_get_document_title();
	if ( $title ) {
		printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	}

	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( ASHPSEO_BRAND ) );

	$og_type = in_array( $kind, array( 'recipe', 'page', 'singular' ), true ) ? 'article' : 'website';
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $og_type ) );

	printf( '<meta property="og:locale" content="%s">' . "\n", 'fa_IR' );
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

	/*
	 * تصویر شبکه‌های اجتماعی: تا وقتی عکس غذا اضافه نشده، فقط لوگو موجود است.
	 * بعد از افزودن عکس، به‌طور خودکار از image_url همان دستور استفاده می‌شود.
	 */
	$img = get_template_directory_uri() . '/assets/img/logo.png';
	if ( 'recipe' === $kind ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			$recipe_img = ashpseo_recipe_image( $r );
			if ( $recipe_img ) {
				$img = $recipe_img;
			}
		}
	} elseif ( 'list' === $kind ) {
		$list_img = ashpseo_list_image();
		if ( $list_img ) {
			$img = $list_img;
		}
	} elseif ( ( 'page' === $kind || 'singular' === $kind ) && has_post_thumbnail() ) {
		$thumb = get_the_post_thumbnail_url( null, 'full' );
		if ( $thumb ) {
			$img = $thumb;
		}
	}
	printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $img ) );
}
add_action( 'wp_head', 'ashpseo_head_output', 5 );
