<?php
/**
 * صفحهٔ «آشپزی با مواد موجود» — انتخاب مواد اولیه و دیدن غذاهای قابل پخت
 *
 * این قالب توسط افزونهٔ «آشپزباشی — موتور» و از طریق ASHP_DB بارگذاری می‌شود.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$ashp_groups = ASHP_DB::ingredient_groups();
$ashp_picked = ASHP_DB::picked_from_request();
?>
<div class="ashp-wrap">

	<header class="ashp-section__head">
		<h1 class="ashp-section__title"><?php esc_html_e( 'آشپزی با مواد موجود', 'ashpazbashi' ); ?></h1>
		<p class="ashp-section__sub"><?php esc_html_e( 'هر عدد کنار هر مادهٔ اولیه، تعداد دستورهایی است که با انتخاب آن ماده به شما نمایش داده می‌شود.', 'ashpazbashi' ); ?></p>
		<p class="ashp-section__sub"><?php esc_html_e( 'حداقل ۳ ماده انتخاب کنید تا دقیق‌ترین پیشنهادها را ببینید.', 'ashpazbashi' ); ?></p>
		<p class="ashp-section__sub"><?php esc_html_e( 'موادی که در خانه داری انتخاب کن؛ آشپزباشی غذاهایی را نشان می‌دهد که بتوانی همین حالا بپزی.', 'ashpazbashi' ); ?></p>
	</header>

	<form class="ashp-picker" id="ashp-picker" method="get" action="<?php echo esc_url( home_url( '/recipes/' ) ); ?>">

		<div class="ashp-picker__bar">
			<span class="ashp-picker__count" id="ashp-picked-count">۰</span>
			<span><?php esc_html_e( 'ماده انتخاب شده', 'ashpazbashi' ); ?></span>
			<span class="ashp-picker__hint" id="ashp-picker-hint"><?php esc_html_e( 'حداقل ۳ مادهٔ اصلی انتخاب کن تا غذاها نمایش داده شوند.', 'ashpazbashi' ); ?></span>
			<button class="ashp-btn ashp-btn--primary" type="submit" id="ashp-picker-submit"><?php esc_html_e( 'غذاها را نشانم بده', 'ashpazbashi' ); ?></button>
			<button class="ashp-btn ashp-btn--ghost" type="button" id="ashp-picker-clear"><?php esc_html_e( 'پاک کردن', 'ashpazbashi' ); ?></button>
		</div>

		<label class="screen-reader-text" for="ashp-ingsearch"><?php esc_html_e( 'جست‌وجوی مادهٔ اولیه', 'ashpazbashi' ); ?></label>
		<input id="ashp-ingsearch" class="ashp-ingsearch" type="search" placeholder="<?php esc_attr_e( 'نام مادهٔ اولیه را بنویس تا سریع پیدا شود…', 'ashpazbashi' ); ?>">

		<?php foreach ( $ashp_groups as $group ) : ?>
			<?php if ( empty( $group['items'] ) ) { continue; } ?>
			<section class="ashp-picker__group" data-ashp-group>
				<h3><span aria-hidden="true"><?php echo esc_html( $group['emoji'] ); ?></span> <?php echo esc_html( $group['label'] ); ?></h3>
				<div class="ashp-chips">
					<?php foreach ( $group['items'] as $item ) : ?>
						<?php $ashp_on = in_array( $item['slug'], $ashp_picked, true ); ?>
						<button type="button"
							class="ashp-chip"
							data-ashp-ing="<?php echo esc_attr( $item['slug'] ); ?>"
							data-ashp-name="<?php echo esc_attr( $item['name'] ); ?>"
							aria-pressed="<?php echo $ashp_on ? 'true' : 'false'; ?>">
							<span class="ashp-chip__txt"><?php echo esc_html( $item['name'] ); ?></span>
							<span class="ashp-chip__ico" aria-hidden="true"><?php echo esc_html( ashpazbashi_ingredient_sticker( $item['name'], $group['emoji'] ) ); ?></span>
							<span class="ashp-chip__n"><?php echo esc_html( number_format_i18n( $item['n'] ) ); ?></span>
						</button>
						<?php if ( $ashp_on ) : ?>
							<input type="hidden" name="ing[]" value="<?php echo esc_attr( $item['slug'] ); ?>" data-ashp-hidden>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endforeach; ?>

	</form>

	<section class="ashp-section" id="ashp-picker-results" aria-live="polite">
		<header class="ashp-section__head">
			<h2 class="ashp-section__title"><?php esc_html_e( 'پیشنهاد آشپزباشی', 'ashpazbashi' ); ?></h2>
			<p class="ashp-section__sub" id="ashp-picker-status"><?php esc_html_e( 'هر چه مواد بیشتری انتخاب کنی، پیشنهادها دقیق‌تر می‌شود.', 'ashpazbashi' ); ?></p>
		</header>
		<div class="ashp-grid ashp-grid--cards" id="ashp-picker-grid"></div>
	</section>

	<noscript>
		<p class="ashp-emptynote"><?php esc_html_e( 'برای دیدن پیشنهادها کافی است مواد را انتخاب کنی و دکمهٔ «غذاها را نشانم بده» را بزنی؛ این کار بدون جاوااسکریپت هم انجام می‌شود.', 'ashpazbashi' ); ?></p>
	</noscript>

</div>
<?php get_footer(); ?>
