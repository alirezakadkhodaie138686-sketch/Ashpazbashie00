<?php
/**
 * تک‌نوشته
 *
 * @package Ashpazbashi
 */
get_header();
?>
<div class="ashp-wrap ashp-wrap--single">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'ashp-article' ); ?>>
			<header class="ashp-article__head">
				<h1 class="ashp-article__title"><?php the_title(); ?></h1>
				<p class="ashp-article__meta">
					<span><?php echo esc_html( get_the_date() ); ?></span>
					<span><?php echo esc_html( get_the_author() ); ?></span>
					<?php if ( has_category() ) : ?><span><?php the_category( '، ' ); ?></span><?php endif; ?>
				</p>
			</header>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="ashp-article__thumb"><?php the_post_thumbnail( 'large' ); ?></figure>
			<?php endif; ?>
			<div class="ashp-content"><?php the_content(); ?></div>
			<footer class="ashp-article__foot">
				<?php the_tags( '<div class="ashp-tags">', ' ', '</div>' ); ?>
			</footer>
		</article>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>
	<?php endwhile; ?>
</div>
<?php get_footer(); ?>
