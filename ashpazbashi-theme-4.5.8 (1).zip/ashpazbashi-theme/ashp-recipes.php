<?php
/**
 * فهرست دستورها — برای «همهٔ دستورها»، دسته‌ها و زیردسته‌ها
 *
 * این قالب توسط افزونهٔ «آشپزباشی — موتور» و از طریق ASHP_DB بارگذاری می‌شود.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$ashp_ctx = ASHP_DB::current_list_context();
if ( ! is_array( $ashp_ctx ) ) {
	$ashp_ctx = array();
}
$ashp_title = isset( $ashp_ctx['title'] ) ? $ashp_ctx['title'] : __( 'همهٔ دستورها', 'ashpazbashi' );
$ashp_desc  = isset( $ashp_ctx['desc'] ) ? $ashp_ctx['desc'] : '';
$ashp_rows  = isset( $ashp_ctx['rows'] ) ? $ashp_ctx['rows'] : array();
$ashp_total = isset( $ashp_ctx['total'] ) ? (int) $ashp_ctx['total'] : 0;
$ashp_page  = isset( $ashp_ctx['page'] ) ? (int) $ashp_ctx['page'] : 1;
$ashp_pages = isset( $ashp_ctx['per_page'] ) && $ashp_ctx['per_page'] > 0 ? (int) ceil( $ashp_total / $ashp_ctx['per_page'] ) : 1;
$ashp_args  = isset( $ashp_ctx['args'] ) ? $ashp_ctx['args'] : array();
?>
<div class="ashp-wrap">

	<nav class="ashp-breadcrumb" aria-label="<?php esc_attr_e( 'مسیر صفحه', 'ashpazbashi' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'ashpazbashi' ); ?></a>
		<span aria-hidden="true">›</span>
		<a href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'دستورها', 'ashpazbashi' ); ?></a>
		<?php if ( ! empty( $ashp_ctx['parent_label'] ) ) : ?>
			<span aria-hidden="true">›</span>
			<?php if ( ! empty( $ashp_ctx['parent_url'] ) ) : ?>
				<a href="<?php echo esc_url( $ashp_ctx['parent_url'] ); ?>"><?php echo esc_html( $ashp_ctx['parent_label'] ); ?></a>
			<?php else : ?>
				<span><?php echo esc_html( $ashp_ctx['parent_label'] ); ?></span>
			<?php endif; ?>
		<?php endif; ?>
	</nav>

	<header class="ashp-section__head">
		<h1 class="ashp-section__title"><?php echo esc_html( $ashp_title ); ?></h1>
		<?php if ( $ashp_desc ) : ?>
			<p class="ashp-section__sub"><?php echo esc_html( $ashp_desc ); ?></p>
		<?php endif; ?>
		<p class="ashp-picker__hint">
			<?php
			printf(
				/* translators: %s: number of recipes */
				esc_html__( '%s دستور پخت در این بخش', 'ashpazbashi' ),
				esc_html( number_format_i18n( $ashp_total ) )
			);
			?>
		</p>
	</header>

	<?php
	$ashp_subcards = ( class_exists( 'ASHP_DB' ) && ! empty( $ashp_ctx['category'] ) )
		? ASHP_DB::subcategory_cards( array( $ashp_ctx['category'] ) )
		: array();
	if ( ! empty( $ashp_subcards[0]['subs'] ) ) :
		?>
		<nav class="ashp-subchips" aria-label="<?php esc_attr_e( 'زیردسته‌ها', 'ashpazbashi' ); ?>">
			<a class="ashp-chip<?php echo empty( $ashp_ctx['subcategory'] ) ? ' is-on' : ''; ?>"
			   href="<?php echo esc_url( ASHP_DB::category_url( $ashp_ctx['category'] ) ); ?>">
				<?php esc_html_e( 'همه', 'ashpazbashi' ); ?>
			</a>
			<?php foreach ( $ashp_subcards[0]['subs'] as $ashp_sub ) : ?>
				<a class="ashp-chip<?php echo ( $ashp_ctx['subcategory'] === $ashp_sub['slug'] ) ? ' is-on' : ''; ?>"
				   href="<?php echo esc_url( $ashp_sub['url'] ); ?>">
					<?php echo esc_html( $ashp_sub['label'] ); ?>
					<span class="ashp-chip__n"><?php echo esc_html( number_format_i18n( $ashp_sub['count'] ) ); ?></span>
				</a>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>
	<form class="ashp-filters" method="get" action="<?php echo esc_url( isset( $ashp_ctx['base_url'] ) ? $ashp_ctx['base_url'] : home_url( '/recipes/' ) ); ?>">
		<label class="screen-reader-text" for="ashp-filter-q"><?php esc_html_e( 'جست‌وجو در دستورها', 'ashpazbashi' ); ?></label>
		<input id="ashp-filter-q" class="ashp-ingsearch" type="search" name="q" value="<?php echo esc_attr( isset( $ashp_args['q'] ) ? $ashp_args['q'] : '' ); ?>" placeholder="<?php esc_attr_e( 'نام غذا یا مادهٔ اولیه…', 'ashpazbashi' ); ?>">

		<?php if ( empty( $ashp_ctx['locked_cat'] ) && class_exists( 'ASHP_DB' ) ) : ?>
			<label class="screen-reader-text" for="ashp-filter-cat"><?php esc_html_e( 'دسته', 'ashpazbashi' ); ?></label>
			<select id="ashp-filter-cat" name="cat" class="ashp-ingsearch">
				<option value=""><?php esc_html_e( 'همهٔ دسته‌ها', 'ashpazbashi' ); ?></option>
				<?php foreach ( ASHP_DB::categories() as $slug => $label ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( isset( $ashp_args['cat'] ) ? $ashp_args['cat'] : '', $slug ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>

		<label class="screen-reader-text" for="ashp-filter-sort"><?php esc_html_e( 'ترتیب', 'ashpazbashi' ); ?></label>
		<select id="ashp-filter-sort" name="sort" class="ashp-ingsearch">
			<option value="" <?php selected( isset( $ashp_args['sort'] ) ? $ashp_args['sort'] : '', '' ); ?>><?php esc_html_e( 'پیشنهاد آشپزباشی', 'ashpazbashi' ); ?></option>
			<option value="fast" <?php selected( isset( $ashp_args['sort'] ) ? $ashp_args['sort'] : '', 'fast' ); ?>><?php esc_html_e( 'سریع‌ترین', 'ashpazbashi' ); ?></option>
			<option value="easy" <?php selected( isset( $ashp_args['sort'] ) ? $ashp_args['sort'] : '', 'easy' ); ?>><?php esc_html_e( 'ساده‌ترین', 'ashpazbashi' ); ?></option>
			<option value="few" <?php selected( isset( $ashp_args['sort'] ) ? $ashp_args['sort'] : '', 'few' ); ?>><?php esc_html_e( 'کم‌ترین مواد اولیه', 'ashpazbashi' ); ?></option>
		</select>

		<button class="ashp-btn ashp-btn--primary" type="submit"><?php esc_html_e( 'فیلتر کن', 'ashpazbashi' ); ?></button>
	</form>

	<?php if ( $ashp_rows ) : ?>

		<div class="ashp-grid ashp-grid--cards">
			<?php foreach ( $ashp_rows as $r ) { echo ASHP_Front::recipe_card( $r ); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>

		<?php if ( $ashp_pages > 1 ) : ?>
			<nav class="ashp-pagination" aria-label="<?php esc_attr_e( 'صفحه‌بندی', 'ashpazbashi' ); ?>">
				<?php
				echo wp_kses_post( paginate_links( array(
					'base'      => add_query_arg( 'ashp_page', '%#%' ),
					'format'    => '',
					'current'   => max( 1, $ashp_page ),
					'total'     => $ashp_pages,
					'mid_size'  => 2,
					'prev_text' => '‹',
					'next_text' => '›',
				) ) );
				?>
			</nav>
		<?php endif; ?>

	<?php else : ?>

		<div class="ashp-empty ashp-empty--big">
			<h2><?php esc_html_e( 'نتیجه‌ای پیدا نشد', 'ashpazbashi' ); ?></h2>
			<p><?php esc_html_e( 'نام غذا یا مادهٔ اولیهٔ دیگری را امتحان کن، یا از صفحهٔ انتخاب مواد اولیه استفاده کن.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'انتخاب مواد اولیه', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'همهٔ دستورها', 'ashpazbashi' ); ?></a>
			</div>
		</div>

	<?php endif; ?>

</div>
<?php get_footer(); ?>
