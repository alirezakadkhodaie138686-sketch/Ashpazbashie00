<?php
/**
 * نتایج جست‌وجو — جست‌وجو در دستورها و مواد اولیه + نوشته‌های وردپرس
 *
 * @package Ashpazbashi
 */

get_header();

$ashp_q = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$ashp_has = class_exists( 'ASHP_DB' );
$ashp_res = ( $ashp_has && '' !== $ashp_q ) ? ASHP_DB::search_recipes( $ashp_q, 60 ) : array();
?>
<div class="ashp-wrap">

	<header class="ashp-section__head">
		<h1 class="ashp-section__title">
			<?php
			if ( '' !== $ashp_q ) {
				printf(
					/* translators: %s: search phrase */
					esc_html__( 'نتایج جست‌وجو برای «%s»', 'ashpazbashi' ),
					esc_html( $ashp_q )
				);
			} else {
				esc_html_e( 'جست‌وجوی آشپزباشی', 'ashpazbashi' );
			}
			?>
		</h1>
		<?php if ( $ashp_res ) : ?>
			<p class="ashp-section__sub">
				<?php
				printf(
					/* translators: %s: number of recipes */
					esc_html__( '%s دستور پخت پیدا شد.', 'ashpazbashi' ),
					esc_html( number_format_i18n( count( $ashp_res ) ) )
				);
				?>
			</p>
		<?php endif; ?>
	</header>

	<?php if ( '' === $ashp_q ) : ?>

		<div class="ashp-empty ashp-empty--big">
			<h2><?php esc_html_e( 'چه غذایی می‌خواهی بپزی؟', 'ashpazbashi' ); ?></h2>
			<p><?php esc_html_e( 'نام غذا یا مادهٔ اولیه را در کادر جست‌وجوی بالای صفحه بنویس، یا از صفحهٔ انتخاب مواد اولیه استفاده کن.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'انتخاب مواد اولیه', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'همهٔ دستورها', 'ashpazbashi' ); ?></a>
			</div>
		</div>

	<?php elseif ( $ashp_res ) : ?>

		<div class="ashp-grid ashp-grid--cards">
			<?php foreach ( $ashp_res as $r ) { echo ASHP_Front::recipe_card( $r ); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>

	<?php elseif ( have_posts() ) : ?>

		<div class="ashp-grid ashp-grid--3">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article class="ashp-card">
					<h4 class="ashp-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					<p class="ashp-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
				</article>
				<?php
			endwhile;
			?>
		</div>

	<?php else : ?>

		<div class="ashp-empty ashp-empty--big">
			<h2><?php esc_html_e( 'نتیجه‌ای پیدا نشد', 'ashpazbashi' ); ?></h2>
			<p><?php esc_html_e( 'نام غذا یا مادهٔ اولیه را با کلمهٔ دیگری امتحان کن.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'انتخاب مواد اولیه', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'همهٔ دستورها', 'ashpazbashi' ); ?></a>
			</div>
		</div>

	<?php endif; ?>

</div>
<?php get_footer(); ?>
