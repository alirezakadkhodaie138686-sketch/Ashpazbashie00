<?php
/**
 * صفحهٔ یک دستور پخت
 *
 * این قالب توسط افزونهٔ «آشپزباشی — موتور» و از طریق ASHP_DB بارگذاری می‌شود.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$ashp_rec = ASHP_DB::current_recipe();
if ( ! is_array( $ashp_rec ) ) {
	$ashp_rec = null;
}
$ashp_ings = $ashp_rec ? ASHP_DB::recipe_ingredients( $ashp_rec['id'] ) : array();
?>
<div class="ashp-wrap">
	<?php if ( ! $ashp_rec ) : ?>

		<div class="ashp-empty ashp-empty--big">
			<span class="ashp-empty__code">۴۰۴</span>
			<h1 class="ashp-page__title"><?php esc_html_e( 'این دستور پخت پیدا نشد', 'ashpazbashi' ); ?></h1>
			<p><?php esc_html_e( 'شاید نام دستور تغییر کرده باشد. از فهرست دستورها یا صفحهٔ انتخاب مواد اولیه استفاده کن.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/recipes/' ) ); ?>"><?php esc_html_e( 'همهٔ دستورها', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'آشپزی با مواد موجود', 'ashpazbashi' ); ?></a>
			</div>
		</div>

	<?php else : ?>

		<article class="ashp-recipe">

			<nav class="ashp-breadcrumb" aria-label="<?php esc_attr_e( 'مسیر صفحه', 'ashpazbashi' ); ?>">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'ashpazbashi' ); ?></a>
				<span aria-hidden="true">›</span>
				<a href="<?php echo esc_url( ASHP_DB::category_url( $ashp_rec['category'] ) ); ?>"><?php echo esc_html( ASHP_DB::category_label( $ashp_rec['category'] ) ); ?></a>
				<?php if ( ! empty( $ashp_rec['subcategory'] ) ) : ?>
					<span aria-hidden="true">›</span>
					<a href="<?php echo esc_url( ASHP_DB::subcategory_url( $ashp_rec['category'], $ashp_rec['subcategory'] ) ); ?>"><?php echo esc_html( ASHP_DB::subcategory_label( $ashp_rec['category'], $ashp_rec['subcategory'] ) ); ?></a>
				<?php endif; ?>
			</nav>

			<header class="ashp-recipe__head">
				<div class="ashp-recipe__sticker" aria-hidden="true">
					<?php echo ashpazbashi_dish_icon( 92 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت ?>
				</div>
				<h1 class="ashp-recipe__title"><?php echo esc_html( $ashp_rec['name'] ); ?></h1>
				<div class="ashp-recipe__meta">
					<?php echo ASHP_Front::recipe_badges( $ashp_rec ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			</header>

			<div class="ashp-recipe__cols">

				<section class="ashp-recipe__card" aria-labelledby="ashp-ing-title">
					<h2 id="ashp-ing-title"><?php esc_html_e( 'مواد اولیه', 'ashpazbashi' ); ?></h2>
					<?php if ( $ashp_ings ) : ?>
						<ul class="ashp-inglist">
							<?php foreach ( $ashp_ings as $ing ) : ?>
								<li class="<?php echo $ing['is_main'] ? 'is-main' : ''; ?>">
									<span class="ashp-inglist__icon" aria-hidden="true"><?php echo ASHP_Front::ingredient_sticker( $ing, 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG امن ?></span>
									<span class="ashp-inglist__name">
										<a href="<?php echo esc_url( ASHP_DB::ingredient_url( $ing['slug'] ) ); ?>"><?php echo esc_html( $ing['name'] ); ?></a>
									</span>
									<span class="ashp-inglist__amount"><?php echo esc_html( ASHP_Front::amount_label( $ing ) ); ?></span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="ashp-emptynote"><?php esc_html_e( 'برای این دستور، فهرست مواد اولیه ثبت نشده است.', 'ashpazbashi' ); ?></p>
					<?php endif; ?>

					<?php if ( ! empty( $ashp_rec['servings'] ) ) : ?>
						<p class="ashp-picker__hint"><?php echo esc_html( ASHP_Front::servings_label( $ashp_rec['servings'] ) ); ?></p>
					<?php endif; ?>

					<?php echo ASHP_Front::halal_block( $ashp_rec ); // phpcs:ignore WordPress.Security.EscapeOutput -- خودش escape می‌کند ?>

					<div class="ashp-recipe__actions">
						<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>">
							<?php esc_html_e( 'غذاهای دیگری با این مواد ببین', 'ashpazbashi' ); ?>
						</a>
					</div>
				</section>

				<section class="ashp-recipe__card" aria-labelledby="ashp-steps-title">
					<h2 id="ashp-steps-title"><?php esc_html_e( 'مراحل پخت', 'ashpazbashi' ); ?></h2>
					<?php
					$ashp_steps = ASHP_Front::steps( $ashp_rec );
					/*
					 * همهٔ دستورها طرز تهیهٔ کامل دارند؛ پس دروازهٔ «اعتماد به مراحل»
					 * و پیام‌های «بدون متن مراحل» دیگر لازم نیستند.
					 */
					if ( $ashp_steps ) :
						?>
						<ol class="ashp-steps">
							<?php foreach ( $ashp_steps as $step ) : ?>
								<li><span class="ashp-steps__text"><?php echo esc_html( $step ); ?></span></li>
							<?php endforeach; ?>
						</ol>
					<?php endif; ?>
				</section>

			</div>

			<?php
			$ashp_related = ASHP_DB::related_recipes( $ashp_rec, 4 );
			if ( $ashp_related ) :
				?>
				<section class="ashp-section">
					<header class="ashp-section__head">
						<h2 class="ashp-section__title"><?php esc_html_e( 'غذاهای مشابه', 'ashpazbashi' ); ?></h2>
					</header>
					<div class="ashp-grid ashp-grid--cards">
						<?php foreach ( $ashp_related as $r ) { echo ASHP_Front::recipe_card( $r ); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</div>
				</section>
			<?php endif; ?>

			<?php
			/*
			 * نظرها و امتیاز کاربران.
			 * نظر تازه در وضعیت «در انتظار» ذخیره می‌شود و تا تأیید مدیر
			 * روی سایت نمایش داده نمی‌شود.
			 */
			if ( class_exists( 'ASHP_Comments' ) ) {
				ASHP_Comments::render( $ashp_rec );
			}
			?>

		</article>

	<?php endif; ?>
</div>
<?php get_footer(); ?>
