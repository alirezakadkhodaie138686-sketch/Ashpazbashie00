/* ==================================================================
   نشانگر نئونی — فقط نقطهٔ کوچک، فقط دسکتاپ

   • گوشی / تبلت (لمسی): به‌کلی اجرا نمی‌شود تا باتری و CPU مصرف نشود.
   • دسکتاپ: فقط نقطهٔ درخشان کوچک؛ هالهٔ بزرگ (سایهٔ نورانی) حذف شده است.
   ================================================================== */
(function () {
	'use strict';

	var dot = document.getElementById('ashp-cursor-dot');
	if (!dot) {
		return;
	}

	/* دستگاه لمسی یا درخواستِ کاهش حرکت: هیچ کاری انجام نمی‌شود. */
	if (window.matchMedia('(hover: none)').matches || window.matchMedia('(pointer: coarse)').matches) {
		return;
	}
	if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		return;
	}

	var body = document.body;
	var OFF = -9999;
	var px = OFF;
	var py = OFF;
	var pressScale = 1;
	var idleTimer = null;
	var IDLE_MS = 2200;
	var running = false;

	function loop() {
		if (!running) {
			return;
		}
		dot.style.transform = 'translate3d(' + (px - 5) + 'px,' + (py - 5) + 'px,0) scale(' + pressScale + ')';
		requestAnimationFrame(loop);
	}

	function start() {
		if (running) {
			return;
		}
		running = true;
		requestAnimationFrame(loop);
	}

	function stop() {
		running = false;
	}

	function show() {
		body.classList.add('ashp-cursor-on');
		body.classList.remove('ashp-cursor-idle');
		start();
	}

	function armIdle(ms) {
		clearTimeout(idleTimer);
		idleTimer = setTimeout(function () {
			body.classList.add('ashp-cursor-idle');
			window.setTimeout(stop, 420);
		}, ms);
	}

	document.addEventListener('mousemove', function (e) {
		px = e.clientX;
		py = e.clientY;
		show();
		armIdle(IDLE_MS);
	}, { passive: true });

	document.addEventListener('mouseleave', function () {
		body.classList.remove('ashp-cursor-on');
	});

	/* روی عناصر تعاملی، نقطه بزرگ‌تر و صورتی می‌شود */
	var hoverSel = 'a, button, input, select, textarea, label, .ashp-chip, .ashp-catcard, .ashp-card, .ashp-rcard, [role="button"]';

	document.addEventListener('mouseover', function (e) {
		if (e.target.closest && e.target.closest(hoverSel)) {
			body.classList.add('ashp-cursor-hover');
		}
	});

	document.addEventListener('mouseout', function (e) {
		if (e.target.closest && e.target.closest(hoverSel)) {
			body.classList.remove('ashp-cursor-hover');
		}
	});

	document.addEventListener('mousedown', function () { pressScale = 0.7; });
	document.addEventListener('mouseup', function () { pressScale = 1; });
	window.addEventListener('blur', function () { pressScale = 1; });
})();
