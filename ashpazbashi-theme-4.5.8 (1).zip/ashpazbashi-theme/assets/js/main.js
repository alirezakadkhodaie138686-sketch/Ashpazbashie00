/* ==================================================================
   اسکریپت اصلی قالب آشپزباشی
   — ورود نام (بدون ثبت‌نام) و ذخیره در مرورگر
   — منوی کشویی موبایل + مگا منو
   — شمارندهٔ آمار
   — دکمهٔ بازگشت به بالا
   ================================================================== */
(function () {
	'use strict';

	var CFG = window.ASHP || {};
	var I18N = CFG.i18n || {};
	var NAME_KEY = 'ashp_name';
	var GUEST = 'مهمان';

	function $(sel, ctx) { return (ctx || document).querySelector(sel); }
	function $$(sel, ctx) {
		return Array.prototype.slice.call((ctx || document).querySelectorAll(sel));
	}
	function reduceMotion() {
		return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	}

	/* ---------------- ۱) نام کاربر ---------------- */

	function getName() {
		try { return window.localStorage.getItem(NAME_KEY) || CFG.name || ''; }
		catch (e) { return CFG.name || ''; }
	}

	function setName(v) {
		try { window.localStorage.setItem(NAME_KEY, v); } catch (e) { /* حالت خصوصی */ }
		try {
			document.cookie = NAME_KEY + '=' + encodeURIComponent(v) +
				';path=/;max-age=31536000;samesite=lax';
		} catch (e) { /* نادیده */ }

		/* ذخیره سمت سرور تا در همان مرورگر همیشه نمایش داده شود */
		if (CFG.ajax) {
			var fd = new FormData();
			fd.append('action', 'ashp_save_name');
			fd.append('nonce', CFG.nonce || '');
			fd.append('name', v);
			fetch(CFG.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
				.catch(function () { /* ذخیرهٔ محلی انجام شده است */ });
		}
	}

	function paintName(v) {
		$$('.ashp-user__name, [data-ashp-uname], .ashp-footer__username, .ashp-hero__hi strong').forEach(function (el) {
			el.textContent = v || GUEST;
		});
		$$('.ashp-user').forEach(function (el) { el.setAttribute('data-name', v || ''); });
	}

	var namebar = $('#ashp-namebar');
	var nameInput = $('#ashp-name-input');
	var lastFocused = null;

	function openNamebar() {
		if (!namebar) return;
		lastFocused = document.activeElement;
		namebar.hidden = false;
		document.documentElement.classList.add('ashp-asking-name');
		/* یک فریم صبر می‌کنیم تا انتقال CSS واقعاً اجرا شود */
		window.requestAnimationFrame(function () {
			window.requestAnimationFrame(function () { namebar.classList.add('is-open'); });
		});
		if (nameInput) {
			if (!nameInput.value) nameInput.value = getName();
			/* بعد از نمایش، فوکوس بده */
			window.setTimeout(function () { nameInput.focus(); }, 60);
		}
	}

	function closeNamebar() {
		if (!namebar) return;
		namebar.classList.remove('is-open');
		document.body.classList.remove('ashp-name-required');
		document.documentElement.classList.remove('ashp-asking-name');
		/* تا پایان انیمیشن بسته‌شدن، عنصر در DOM می‌ماند */
		window.setTimeout(function () {
			if (!namebar.classList.contains('is-open')) namebar.hidden = true;
		}, 300);
		if (lastFocused && lastFocused.focus) lastFocused.focus();
	}

	if (namebar) {
		var stored = getName();
		if (stored) {
			paintName(stored);
		} else {
			/* اولین بازدید: اسم می‌پرسیم (بدون ثبت‌نام) */
			document.body.classList.add('ashp-name-required');
			openNamebar();
		}

		namebar.addEventListener('submit', function (e) {
			e.preventDefault();
			var v = ((nameInput && nameInput.value) || '').trim();
			if (!v) { if (nameInput) nameInput.focus(); return; }
			setName(v);
			paintName(v);
			closeNamebar();
			document.body.classList.add('ashp-has-name');
		});

		/* بستن با کلید Escape — فقط اگر کاربر از قبل نام دارد */
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !namebar.hidden && getName()) closeNamebar();
		});

		/* نگه داشتن فوکوس داخل پنجرهٔ نام */
		namebar.addEventListener('keydown', function (e) {
			if (e.key !== 'Tab') return;
			var f = $$('input, button, [href], select, textarea', namebar)
				.filter(function (el) { return !el.disabled && el.offsetParent !== null; });
			if (!f.length) return;
			var first = f[0];
			var last = f[f.length - 1];
			if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
			else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
		});
	}

	$$('.ashp-user__edit').forEach(function (b) {
		b.addEventListener('click', openNamebar);
	});

	/* ---------------- ۲) منوی موبایل ---------------- */

	var burger = $('.ashp-burger');
	var panel = $('#ashp-primary-menu');
	if (burger && panel) {
		burger.addEventListener('click', function () {
			var open = panel.classList.toggle('is-open');
			burger.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
	}

	/* در موبایل زیرمنوها با کلیک باز می‌شوند */
	$$('.ashp-menu .menu-item-has-children > a').forEach(function (a) {
		a.addEventListener('click', function (e) {
			if (window.innerWidth > 860) return;
			var li = a.parentElement;
			if (!li.classList.contains('is-open')) {
				e.preventDefault();
				li.classList.add('is-open');
			}
		});
	});

	/* ---------------- ۳) مگا منو ---------------- */

	$$('.ashp-mega__trigger').forEach(function (btn) {
		btn.addEventListener('click', function (e) {
			e.preventDefault();
			var item = this.closest('.ashp-mega__item');
			if (!item) return;
			var open = item.classList.toggle('is-open');
			this.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
	});

	document.addEventListener('click', function (e) {
		if (e.target.closest && e.target.closest('.ashp-mega__item')) return;
		$$('.ashp-mega__item.is-open').forEach(function (i) {
			i.classList.remove('is-open');
			var b = i.querySelector('.ashp-mega__trigger');
			if (b) b.setAttribute('aria-expanded', 'false');
		});
	});

	/* ---------------- ۴) شمارندهٔ آمار ---------------- */

	function counter(el) {
		var target = parseInt((el.textContent || '0').replace(/[^0-9]/g, ''), 10) || 0;
		if (reduceMotion() || target === 0) {
			el.textContent = target.toLocaleString('fa-IR');
			return;
		}
		var start = performance.now();
		var dur = 3000;
		function tick(now) {
			var p = Math.min(1, (now - start) / dur);
			var eased = 1 - Math.pow(1 - p, 3);
			el.textContent = Math.floor(target * eased).toLocaleString('fa-IR');
			if (p < 1) requestAnimationFrame(tick);
		}
		el.textContent = '۰';
		requestAnimationFrame(tick);
	}

	document.addEventListener('DOMContentLoaded', function () {
		$$('.ashp-stats b').forEach(counter);
	});

	/* ---------------- ۵) بازگشت به بالا ---------------- */

	var top = $('.ashp-top');
	if (top) {
		window.addEventListener('scroll', function () {
			top.classList.toggle('is-on', window.scrollY > 420);
		}, { passive: true });
		top.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: reduceMotion() ? 'auto' : 'smooth' });
		});
	}

	/* ---------------- ۶) پیشنهاد زندهٔ جست‌وجو ---------------- */

	$$('.ashp-search').forEach(function (form) {
		var input = $('.ashp-search__input', form);
		if (!input || !CFG.ajax || !CFG.plugin) return;

		var box = document.createElement('div');
		box.className = 'ashp-suggest';
		box.hidden = true;
		form.appendChild(box);

		var timer = null;
		var lastQ = '';

		function row(label, url, meta) {
			var a = document.createElement('a');
			a.href = url;
			var name = document.createElement('span');
			name.textContent = label;
			a.appendChild(name);
			if (meta) {
				var m = document.createElement('span');
				m.className = 'ashp-suggest__n';
				m.textContent = meta;
				a.appendChild(m);
			}
			return a;
		}

		function close() {
			box.hidden = true;
			box.innerHTML = '';
		}

		input.addEventListener('input', function () {
			var q = input.value.trim();
			window.clearTimeout(timer);
			if (q.length < 2) { close(); return; }

			timer = window.setTimeout(function () {
				if (q === lastQ) return;
				lastQ = q;

				var fd = new FormData();
				fd.append('action', 'ashp_search');
				fd.append('nonce', CFG.nonce || '');
				fd.append('q', q);

				fetch(CFG.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (data) {
						if (!data || !data.success) { close(); return; }
						box.innerHTML = '';
						var list = data.data || {};
						var n = 0;

						(list.recipes || []).forEach(function (it) {
							box.appendChild(row(it.name, it.url, ''));
							n++;
						});
						(list.ingredients || []).forEach(function (it) {
							box.appendChild(row('🧂 ' + it.name, it.url, fa(it.n) + ' غذا'));
							n++;
						});

						if (!n) { close(); return; }
						box.hidden = false;
					})
					.catch(close);
			}, 250);
		});

		input.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') close();
		});

		document.addEventListener('click', function (e) {
			if (!form.contains(e.target)) close();
		});
	});

	function fa(n) {
		try { return Number(n).toLocaleString('fa-IR'); } catch (e) { return String(n); }
	}

	/* ---------------- ۷) کشوی منو و کلید جست‌وجو (موبایل) ---------------- */

	var drawer = document.getElementById('ashp-drawer');
	var drawerTimer = null;

	/* باز و بسته شدن با انیمیشن: کلاس is-open کار می‌کند و hidden بعد از پایان انیمیشن */
	function openDrawer(open) {
		if (!drawer) return;
		clearTimeout(drawerTimer);
		if (open) {
			drawer.hidden = false;
			void drawer.offsetWidth; /* بازخوانی اجباری تا گذار اجرا شود */
			drawer.classList.add('is-open');
			document.documentElement.classList.add('ashp-drawer-open');
		} else {
			drawer.classList.remove('is-open');
			document.documentElement.classList.remove('ashp-drawer-open');
			drawerTimer = setTimeout(function () {
				if (!drawer.classList.contains('is-open')) drawer.hidden = true;
			}, 440);
		}
		if (burger) burger.setAttribute('aria-expanded', open ? 'true' : 'false');
	}

	function drawerIsOpen() {
		return !!(drawer && drawer.classList.contains('is-open'));
	}

	if (drawer && burger) {
		burger.addEventListener('click', function () {
			openDrawer(!drawerIsOpen());
		});
		$$('[data-ashp-drawer-close]', drawer).forEach(function (el) {
			el.addEventListener('click', function () { openDrawer(false); });
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && drawerIsOpen()) openDrawer(false);
		});
	}

	var stog = $('.ashp-searchtoggle');
	var hinner = $('.ashp-header__inner');
	if (stog && hinner) {
		stog.addEventListener('click', function () {
			var on = hinner.classList.toggle('is-search');
			stog.setAttribute('aria-expanded', on ? 'true' : 'false');
			if (on) {
				var inp = $('.ashp-search__input', hinner);
				if (inp) setTimeout(function () { inp.focus(); }, 80);
			}
		});
	}
	/* ---------------- ۸) منوی کشویی سفارشی هم‌سبک سایت ---------------- */

	function ashpCloseSelects(except) {
		$$('.ashp-sel.is-open').forEach(function (w) {
			if (w === except) return;
			w.classList.remove('is-open');
			var b = $('.ashp-sel__btn', w);
			if (b) b.setAttribute('aria-expanded', 'false');
		});
	}

	function ashpInitSelects() {
		$$('select.ashp-ingsearch, select.ashp-sel-src').forEach(function (sel) {
			if (sel.getAttribute('data-ashp-sel') === '1') return;
			sel.setAttribute('data-ashp-sel', '1');

			var wrap = document.createElement('div');
			wrap.className = 'ashp-sel';
			sel.parentNode.insertBefore(wrap, sel);
			wrap.appendChild(sel);
			sel.classList.add('ashp-sel__native');

			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'ashp-sel__btn';
			btn.setAttribute('aria-haspopup', 'listbox');
			btn.setAttribute('aria-expanded', 'false');
			btn.innerHTML = '<span class="ashp-sel__label"></span><span class="ashp-sel__caret" aria-hidden="true"></span>';

			var list = document.createElement('ul');
			list.className = 'ashp-sel__list';
			list.setAttribute('role', 'listbox');

			Array.prototype.forEach.call(sel.options, function (o) {
				var li = document.createElement('li');
				li.className = 'ashp-sel__opt';
				li.setAttribute('role', 'option');
				li.setAttribute('data-val', o.value);
				li.textContent = o.textContent;
				if (o.selected) {
					li.classList.add('is-on');
					li.setAttribute('aria-selected', 'true');
				}
				list.appendChild(li);
			});

			wrap.appendChild(btn);
			wrap.appendChild(list);

			var label = $('.ashp-sel__label', btn);
			var setLabel = function () {
				var o = sel.options[sel.selectedIndex];
				if (label) label.textContent = o ? o.textContent : '';
			};
			setLabel();

			btn.addEventListener('click', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var open = !wrap.classList.contains('is-open');
				ashpCloseSelects(wrap);
				wrap.classList.toggle('is-open', open);
				btn.setAttribute('aria-expanded', open ? 'true' : 'false');
			});

			list.addEventListener('click', function (e) {
				var li = e.target && e.target.closest ? e.target.closest('.ashp-sel__opt') : null;
				if (!li) return;
				e.preventDefault();
				sel.value = li.getAttribute('data-val');
				$$('.ashp-sel__opt', list).forEach(function (x) {
					var on = x === li;
					x.classList.toggle('is-on', on);
					if (on) { x.setAttribute('aria-selected', 'true'); } else { x.removeAttribute('aria-selected'); }
				});
				setLabel();
				wrap.classList.remove('is-open');
				btn.setAttribute('aria-expanded', 'false');
				sel.dispatchEvent(new Event('change', { bubbles: true }));
			});

			wrap.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') {
					wrap.classList.remove('is-open');
					btn.setAttribute('aria-expanded', 'false');
					btn.focus();
				}
			});
		});

		document.addEventListener('click', function () { ashpCloseSelects(null); });
	}

	ashpInitSelects();

	/* ---------------- ۱۱) چرخهٔ غذاها: هر بار یک غذا می‌افتد پایین ---------------- */

	var FOOD_KEY = 'ashp_food_rot';

	/* تنظیمات پنل مدیریت (افزونه) — اگر نباشد، پیش‌فرض‌ها */
	var FS = (CFG && CFG.foodsettings) || null;
	function fsNum(k, d) { return (FS && typeof FS[k] === 'number' && FS[k]) ? FS[k] : d; }
	function fsOn(k) { return !FS || FS[k] !== 0; }
	function fsEnabled(name) { return !FS || !FS.list || FS.list.indexOf(name) > -1; }

	function foodVariant(i) {
		/* ۲۰ انیمیشن برای هر دسته */
		var v = {};
		v.spin = [-16, 12, 20, -9, 26, -20, 6, -13, 17, -24][i % 10];
		v.drift = [-34, -17, 0, 17, 34][Math.floor(i / 5) % 5];
		v.squash = [1.09, 0.94, 1.04, 0.9][i % 4];
		v.from = -112 - (i % 5) * 14;
		v.dust = 5 + (i % 6);
		v.dustColor = ['#d6c7b0', '#e3d3b6', '#c9d3c2', '#cbb9a6'][i % 4];
		v.spread = 0.8 + (i % 4) * 0.22;
		v.speed = 1000 + (i % 5) * 140;
		v.drip = (i % 4) !== 3;
		return v;
	}

	function foodNext() {
		var n = 0;
		try { n = parseInt(window.localStorage.getItem(FOOD_KEY) || '0', 10) || 0; } catch (e) {}
		try { window.localStorage.setItem(FOOD_KEY, String(n + 1)); } catch (e) {}
		var keys = [];
		for (var k in ASHP_FOODS) {
			if (!ASHP_FOODS.hasOwnProperty(k)) continue;
			var on = [];
			for (var q = 0; q < ASHP_FOODS[k].items.length; q++) {
				if (fsEnabled(ASHP_FOODS[k].items[q].n)) on.push(ASHP_FOODS[k].items[q]);
			}
			if (!on.length) continue;                             /* دستهٔ بدون غذای فعال حذف */
			ASHP_FOODS[k].__on = on;
			keys.push(k);
		}
		if (!keys.length) return null;

		/*
		 * در صفحهٔ یک دستهٔ خاص، فقط غذاهای همان دسته می‌افتند؛ مثلاً در
		 * دستهٔ فست‌فود فقط پیتزا و ساندویچ، نه چلوکباب. در بقیهٔ صفحه‌ها
		 * (از جمله صفحهٔ اصلی) همان چرخهٔ دسته‌ها کار می‌کند.
		 */
		var fsCfg = (typeof CFG !== 'undefined' && CFG) ? CFG : (window.ASHP || {});
		var only = (FS && FS.cat) ? String(FS.cat) : (fsCfg.cat ? String(fsCfg.cat) : '');
		var catKey;
		if (only && ASHP_FOODS[only] && ASHP_FOODS[only].__on && ASHP_FOODS[only].__on.length) {
			catKey = only;
		} else {
			catKey = keys[n % keys.length];                       /* چرخهٔ دسته‌ها */
		}
		var cat = ASHP_FOODS[catKey];
		var items = cat.__on || cat.items;
		var food = items[Math.floor(n / keys.length) % items.length];
		var limit = Math.max(1, Math.min(60, fsNum('percat', 20))); /* چند انیمیشن در هر دسته */
		return { round: n, catKey: catKey, cat: cat, food: food, v: foodVariant((n * 3 + 1) % limit) };
	}

	var foodEl = null, foodInner = null, foodLayers = null, foodReady = false;

	function foodStage() {
		/*
		 * در موبایل این صحنه ساخته نمی‌شود: هم طبق درخواست کارفرما جای آن
		 * کارت‌های کوچک می‌آید، هم رندر SVG و انیمیشن‌هایش گوشی را کند می‌کند.
		 */
		if (A3D_REDUCED || !A3D_DESKTOP || foodEl || !fsOn('master')) return;
		var pick = foodNext();
		if (!pick) return;
		var stage = document.createElement('div');
		stage.className = 'ashp-foodstage';
		stage.setAttribute('aria-hidden', 'true');
		stage.setAttribute('data-food', pick.food.n);
		stage.setAttribute('data-cat', pick.catKey);
		stage.setAttribute('data-variant', String(pick.round % 20));
		var inner = document.createElement('div');
		inner.className = 'ashp-foodstage__inner';

		var v = pick.v, parts = pick.food.p;
		/* کادر دید هر غذا جداگانه و تنگ است تا نقاشی کل صحنه را پر کند */
		var vb = pick.food.vb || '0 0 220 196';
		var svg = '<svg class="ashp-foodstage__art" viewBox="' + vb + '" preserveAspectRatio="xMidYMid meet" width="100%" height="100%" role="img" aria-label="' + pick.food.n + '">';
		for (var i = 0; i < parts.length; i++) {
			svg += '<g class="ashp-foodstage__l" data-i="' + i + '">' + parts[i] + '</g>';
		}
		if (pick.food.d && v.drip) {
			/* سس روی غذا سرریز می‌کند و قطره‌ها درست زیر خط زمینِ همان غذا می‌چکند */
			var vbp = vb.split(' ');
			var ground = (parseFloat(vbp[1]) || 0) + (parseFloat(vbp[3]) || 196);
			var cy1 = (ground + 10).toFixed(1), cy2 = (ground + 17).toFixed(1);
			svg += '<g class="ashp-foodstage__l" data-i="' + parts.length + '">' +
				'<path d="M78 118c0 16 5 26 10 26s10-10 10-26z" fill="' + pick.food.d + '"/>' +
				'<path d="M132 116c0 18 5 30 11 30s11-12 11-30z" fill="' + pick.food.d + '"/>' +
				'<circle class="ashp-foodstage__drop" cx="84" cy="' + cy1 + '" r="5" fill="' + pick.food.d + '"/>' +
				'<circle class="ashp-foodstage__drop d2" cx="146" cy="' + cy2 + '" r="4" fill="' + pick.food.d + '"/>' +
				'</g>';
		}
		svg += '</svg>';
		inner.innerHTML = svg;
		stage.appendChild(inner);
		stage.appendChild(foodDust(pick.v));

		inner.style.setProperty('--fd-from', v.from + 'vh');
		inner.style.setProperty('--fd-spin', v.spin + 'deg');
		inner.style.setProperty('--fd-drift', v.drift + 'px');
		inner.style.setProperty('--fd-squash', v.squash);
		inner.style.animationDuration = v.speed + 'ms';

		/* اندازه و جابه‌جایی از پنل مدیریت
		   --fs-k ضریب اندازه و --fs-dy جابه‌جایی عمودی است؛ چون متغیر CSS
		   هستند، اندازه‌های ریسپانسیو موبایل/تبلت دست‌نخورده می‌مانند. */
		var sc = Math.max(40, Math.min(200, fsNum('size', 100))) / 100;
		stage.style.setProperty('--fs-k', String(sc));
		stage.style.setProperty('--fs-dy', fsNum('offset', 0) + 'px');
		/* خط زمینِ همین غذا (کسری از بلندی کادر) تا گرد و خاک درست بنشیند */
		stage.style.setProperty('--fs-g', String(pick.food.g != null ? pick.food.g : 0.12));

		/* جای درج (از پنل قابل تغییر است) */
		var ap = (FS && FS.anchor) || 'roadmap';
		var mainEl = document.querySelector('.ashp-main');
		var anchor = null;
		if ('top' === ap) { anchor = mainEl ? mainEl.firstElementChild : null; }
		else if ('hero' === ap) { var h = document.querySelector('.ashp-hero'); anchor = h ? h.nextElementSibling : null; }
		else if ('bottom' === ap) { anchor = document.querySelector('.ashp-footer'); }
		if (!anchor) { anchor = document.querySelector('.ashp-roadmap') || mainEl || document.body; }
		if (anchor && anchor.parentNode) { anchor.parentNode.insertBefore(stage, anchor); }
		else { document.body.appendChild(stage); }

		foodEl = stage;
		foodInner = inner;
		foodLayers = $$('.ashp-foodstage__l', inner);

		inner.classList.add('is-flying');
		setTimeout(function () {
			inner.classList.remove('is-flying');
			inner.classList.add('is-landed');
			foodReady = true;
			foodDustRun();
			foodPeel(window.pageYOffset || document.documentElement.scrollTop || 0);
		}, v.speed);
	}

	function foodDust(v) {
		var w = document.createElement('span');
		w.className = 'ashp-foodstage__dustwrap';
		return w;
	}

	function foodDustRun() {
		if (!foodEl) return;
		var w = $('.ashp-foodstage__dustwrap', foodEl);
		if (!w) return;
		var v = foodVariant(parseInt(foodEl.getAttribute('data-variant') || '0', 10));
		for (var i = 0; i < v.dust; i++) {
			var d = document.createElement('span');
			d.className = 'ashp-foodstage__dust';
			d.style.insetInlineStart = (10 + i * (80 / v.dust)) + '%';
			d.style.animationDelay = (i * 80) + 'ms';
			var sz = (18 + (i % 3) * 12) * v.spread;
			d.style.width = sz + 'px';
			d.style.height = sz * 0.55 + 'px';
			d.style.background = 'radial-gradient(ellipse,' + v.dustColor + 'aa,' + v.dustColor + '00 70%)';
			w.appendChild(d);
		}
		setTimeout(function () { w.innerHTML = ''; }, 4700);   /* بعد از ۴ ثانیه محو و پاک */
	}

	function foodPeel(y) {
		if (!foodReady || !foodLayers || !foodLayers.length) return;
		var p = Math.max(0, Math.min(1, y / 780));
		for (var i = 0; i < foodLayers.length; i++) {
			var start = i * 0.1;
			var t = Math.max(0, Math.min(1, (p - start) / 0.26));
			var e = t * t * (3 - 2 * t);
			var dir = (i % 2) ? 1 : -1;
			foodLayers[i].style.transform = 'translate(' + (dir * 84 * e).toFixed(1) + 'px,' +
				(-30 * e).toFixed(1) + 'px) rotate(' + (dir * 34 * e).toFixed(1) + 'deg)';
			foodLayers[i].style.opacity = (1 - e).toFixed(3);
		}
		foodEl.style.opacity = (1 - Math.max(0, (p - 0.72) / 0.28)).toFixed(3);
	}

var ASHP_FOODS = {
iranian:{label:'غذای ایرانی',items:[{n:`چلوکباب`,vb:'22.0 58.4 176.0 158.3',g:0.2083,d:null,p:[`<ellipse cx="110" cy="164" rx="88" ry="19" fill="#cbd5e0"/><ellipse cx="110" cy="160" rx="80" ry="15" fill="#e6edf5"/>`,`<path d="M48 146c0-24 28-40 62-40s62 16 62 40c0 10-28 17-62 17s-62-7-62-17z" fill="#f8f6ee"/><path d="M88 122c14-6 32-8 48-5" stroke="#f0c14b" stroke-width="10" fill="none" stroke-linecap="round" opacity=".8"/>`,`<g transform="rotate(-13 110 116)"><rect x="56" y="104" width="108" height="14" rx="7" fill="#7a4b28"/><rect x="56" y="122" width="108" height="14" rx="7" fill="#653a1d"/><path d="M70 111h22M108 111h22M70 129h22M108 129h22" stroke="#3a1f0d" stroke-width="2.6" opacity=".55"/></g>`,`<circle cx="164" cy="142" r="13" fill="#e2496e"/><circle cx="160" cy="138" r="4" fill="#ff8fa6" opacity=".7"/><rect x="92" y="104" width="30" height="11" rx="5" fill="#ffe18f"/>`]},{n:`قورمه‌سبزی`,vb:'40.0 77.1 140.0 125.9',g:0.2081,d:'#5f9138',p:[`<path d="M40 120h140c0 34-31 56-70 56s-70-22-70-56z" fill="#1f3350"/><ellipse cx="110" cy="120" rx="70" ry="16" fill="#2c4368"/>`,`<ellipse cx="110" cy="120" rx="62" ry="13" fill="#4e7a2e"/><ellipse cx="110" cy="118" rx="54" ry="10" fill="#5f9138"/>`,`<ellipse cx="84" cy="118" rx="11" ry="7" fill="#3a2a18"/><ellipse cx="112" cy="124" rx="10" ry="6" fill="#3a2a18"/><ellipse cx="136" cy="116" rx="9" ry="6" fill="#3a2a18"/>`,`<path d="M116 106c10-3 20 0 22 6s-8 9-18 8-12-11-4-14z" fill="#6b4224"/><circle cx="146" cy="122" r="7" fill="#2b2416"/>`]},{n:`آش رشته`,vb:'34.0 71.2 152.0 136.7',g:0.2129,d:'#fdfdf5',p:[`<path d="M34 118h152c0 38-34 60-76 60s-76-22-76-60z" fill="#25334a"/><ellipse cx="110" cy="118" rx="76" ry="17" fill="#33465f"/>`,`<ellipse cx="110" cy="118" rx="68" ry="14" fill="#e8dcc0"/>`,`<path d="M64 116c14-6 30 4 46-2s32 4 44-2" stroke="#5f9138" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M60 124c16-5 34 3 50-2s34 3 48-3" stroke="#7bbf4a" stroke-width="4" fill="none" stroke-linecap="round"/>`,`<path d="M72 110c14-8 34-2 50-6" stroke="#fdfdf5" stroke-width="6" fill="none" stroke-linecap="round" opacity=".95"/><circle cx="96" cy="104" r="2.4" fill="#3f8b25"/><circle cx="126" cy="106" r="2.4" fill="#3f8b25"/>`]}]},
fastfood:{label:'فست‌فود',items:[{n:`همبرگر`,vb:'32.0 38.9 156.0 140.3',g:0.0313,d:'#c81f3e',p:[`<path d="M36 150v8c0 9 33 16 74 16s74-7 74-16v-8z" fill="#a86a24"/><ellipse cx="110" cy="150" rx="74" ry="16" fill="#eec277"/><ellipse cx="110" cy="148" rx="68" ry="13" fill="#f0c98a" opacity=".55"/>`,`<path d="M32 134v6c0 10 35 17 78 17s78-7 78-17v-6z" fill="#2c1408"/><ellipse cx="110" cy="134" rx="78" ry="17" fill="#6b4224"/><ellipse cx="88" cy="130" rx="26" ry="5" fill="#8a5730" opacity=".55"/>`,`<path d="M42 116h136v10c0 5-4 9-9 9H51c-5 0-9-4-9-9z" fill="#ffdd63"/><path d="M56 130c0 9 3 15 7 15s7-6 7-15z" fill="#f5b52c"/><path d="M104 132c0 11 4 18 8 18s8-7 8-18z" fill="#f5b52c"/>`,`<ellipse cx="110" cy="110" rx="77" ry="15" fill="#e2496e"/>`,`<path d="M36 100c6-12 15-4 23-10s14 6 25-1 16 6 26-1 15 6 25 1 17-2 22 10c-5 12-32 17-61 17s-55-5-60-17z" fill="#7bbf4a"/>`,`<path d="M36 100c0-33 33-56 74-56s74 23 74 56c0 6-33 10-74 10s-74-4-74-10z" fill="#e3a54e"/><g fill="#fdf0cf"><ellipse cx="80" cy="66" rx="7" ry="3.4"/><ellipse cx="118" cy="58" rx="7" ry="3.4"/><ellipse cx="146" cy="70" rx="7" ry="3.4"/><ellipse cx="66" cy="84" rx="7" ry="3.4"/><ellipse cx="152" cy="86" rx="7" ry="3.4"/></g>`,`<path d="M64 116c0 18 5 30 11 30s11-12 11-30z" fill="#c81f3e"/><path d="M140 114c0 22 6 36 12 36s12-14 12-36z" fill="#c81f3e"/>`]},{n:`پیتزا`,vb:'22.0 36.9 176.0 158.3',g:0.0656,d:null,p:[`<ellipse cx="110" cy="156" rx="88" ry="22" fill="#c98a3f"/><ellipse cx="110" cy="151" rx="82" ry="19" fill="#e3a863"/>`,`<circle cx="110" cy="116" r="68" fill="#e8a94a"/><circle cx="110" cy="116" r="60" fill="#ffd86b"/>`,`<circle cx="88" cy="100" r="13" fill="#c8324a"/><circle cx="132" cy="98" r="13" fill="#c8324a"/><circle cx="110" cy="126" r="13" fill="#c8324a"/><circle cx="76" cy="132" r="11" fill="#c8324a"/><circle cx="146" cy="130" r="11" fill="#c8324a"/>`,`<path d="M74 112c14-8 30-6 44-12" stroke="#fdfdf5" stroke-width="5" fill="none" stroke-linecap="round" opacity=".85"/><circle cx="96" cy="92" r="4" fill="#3f8b25"/><circle cx="128" cy="118" r="4" fill="#3f8b25"/>`]},{n:`سیب‌زمینی سرخ‌کرده`,vb:'55.7 37.2 150.7 135.5',g:0.0,d:null,p:[`<path d="M62 100h96l-11 66H73z" fill="#c8324a"/><path d="M62 100h96l-3 18H65z" fill="#e2496e"/>`,`<g fill="#f2c14e"><rect x="74" y="46" width="11" height="66" rx="5" transform="rotate(-8 80 80)"/><rect x="92" y="38" width="11" height="74" rx="5"/><rect x="110" y="44" width="11" height="68" rx="5" transform="rotate(6 116 78)"/><rect x="128" y="52" width="11" height="60" rx="5" transform="rotate(12 134 82)"/></g>`,`<path d="M164 150c0 12 8 22 18 22s18-10 18-22z" fill="#e2496e"/><ellipse cx="182" cy="150" rx="18" ry="7" fill="#ff5d7e"/>`]},{n:`ساندویچ`,vb:'26.0 44.5 168.0 151.1',g:0.0913,d:'#f5b52c',p:[`<ellipse cx="110" cy="162" rx="84" ry="19" fill="#cbd5e0"/><ellipse cx="110" cy="158" rx="76" ry="15" fill="#e6edf5"/>`,`<path d="M44 138h132a10 10 0 0 1 10 10v8H34v-8a10 10 0 0 1 10-10z" fill="#dfa85f"/><path d="M50 148h120" stroke="#c98a3f" stroke-width="2.4" opacity=".6"/>`,`<path d="M40 126h140v13H40z" fill="#ffdd63"/><path d="M56 139c0 8 3 14 7 14s7-6 7-14z" fill="#f5b52c"/><path d="M152 139c0 8 3 14 7 14s7-6 7-14z" fill="#f5b52c"/>`,`<ellipse cx="84" cy="121" rx="17" ry="9" fill="#e2496e"/><ellipse cx="136" cy="121" rx="17" ry="9" fill="#e2496e"/>`,`<path d="M38 117c6-11 16-3 24-9s14 7 24 0 16 7 26 0 14 7 22 2 14-3 20 8c-6 12-32 16-60 16s-52-4-56-17z" fill="#7bbf4a"/>`,`<path d="M40 106a10 10 0 0 1 10-10h120a10 10 0 0 1 10 10v10H40z" fill="#e3a54e"/><g fill="#fdf0cf"><ellipse cx="78" cy="105" rx="6" ry="3.2"/><ellipse cx="110" cy="102" rx="6" ry="3.2"/><ellipse cx="142" cy="105" rx="6" ry="3.2"/></g><rect x="106" y="68" width="8" height="40" rx="4" fill="#c98a3f"/><circle cx="110" cy="66" r="7" fill="#e2496e"/>`]}]},
dessert:{label:'دسر',items:[{n:`بستنی`,vb:'36.2 40.2 149.6 134.5',g:0.0,d:'#6b4224',p:[`<path d="M84 108h52l-26 66z" fill="#e3a863"/><path d="M90 108h40l-5 12H95z" fill="#c98a3f"/><path d="M92 126h36M96 140h28" stroke="#c98a3f" stroke-width="2" opacity=".7"/>`,`<circle cx="110" cy="96" r="31" fill="#f4839b"/>`,`<circle cx="92" cy="74" r="24" fill="#6b4224"/><circle cx="130" cy="74" r="24" fill="#8a5730"/>`,`<circle cx="110" cy="50" r="9" fill="#c8324a"/><path d="M78 88c10 8 22 10 34 6" stroke="#c8324a" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>`]},{n:`کیک`,vb:'28.0 59.8 164.0 147.5',g:0.1864,d:'#c8324a',p:[`<ellipse cx="110" cy="162" rx="82" ry="17" fill="#e9edf2"/><ellipse cx="110" cy="158" rx="74" ry="14" fill="#f6f8fb"/>`,`<path d="M66 152h88l-44-52z" fill="#f6dcae"/>`,`<path d="M80 130h60l-30-36z" fill="#8a4b2a"/><path d="M86 118h48l-24-28z" fill="#fff3e0"/>`,`<circle cx="110" cy="96" r="8" fill="#c8324a"/><path d="M74 148c4-10 12-14 22-16" stroke="#e2496e" stroke-width="5" fill="none" stroke-linecap="round" opacity=".85"/>`]}]},
drink:{label:'نوشیدنی',items:[{n:`نوشابه`,vb:'42.3 42.9 135.5 121.8',g:0.0,d:null,p:[`<path d="M74 78h72l-10 86H84z" fill="#7fc7dd" opacity=".35"/><path d="M80 96h60l-8 62H88z" fill="#4a2618"/>`,`<rect x="86" y="102" width="22" height="22" rx="5" fill="#ffffff" opacity=".4"/><rect x="112" y="116" width="20" height="20" rx="5" fill="#ffffff" opacity=".35"/>`,`<rect x="126" y="44" width="10" height="76" rx="5" fill="#e2496e" transform="rotate(9 131 82)"/>`,`<circle cx="102" cy="92" r="3" fill="#fff" opacity=".6"/><circle cx="120" cy="104" r="2.4" fill="#fff" opacity=".5"/><circle cx="94" cy="112" r="2" fill="#fff" opacity=".5"/>`]},{n:`چای`,vb:'46.3 63.2 127.3 114.5',g:0.0,d:null,p:[`<ellipse cx="110" cy="164" rx="62" ry="13" fill="#dfe5ec"/><ellipse cx="110" cy="161" rx="54" ry="10" fill="#f6f8fb"/>`,`<path d="M80 92h60l-8 62H88z" fill="#a8691f"/><ellipse cx="110" cy="92" rx="30" ry="7" fill="#c98a3f"/><ellipse cx="110" cy="92" rx="23" ry="5" fill="#5a3a12"/>`,`<rect x="96" y="150" width="26" height="14" rx="4" fill="#fbf6e8"/>`,`<path d="M98 70c-5 6 5 10 0 16M118 64c-5 6 5 10 0 16" stroke="#cbd6e0" stroke-width="3" fill="none" stroke-linecap="round" opacity=".6"/>`]}]},
appetizer:{label:'پیش‌غذا و سالاد',items:[{n:`سالاد`,vb:'38.0 69.3 144.0 129.5',g:0.1853,d:'#fdfdf5',p:[`<path d="M38 118h144c0 34-32 56-72 56s-72-22-72-56z" fill="#e9edf2"/><ellipse cx="110" cy="118" rx="72" ry="16" fill="#cfe0d4"/>`,`<ellipse cx="86" cy="114" rx="20" ry="12" fill="#4e9b2e"/><ellipse cx="132" cy="110" rx="22" ry="13" fill="#5f9138"/><ellipse cx="110" cy="122" rx="20" ry="11" fill="#7bbf4a"/>`,`<circle cx="74" cy="118" r="9" fill="#e2496e"/><circle cx="146" cy="118" r="9" fill="#e2496e"/><circle cx="110" cy="104" r="8" fill="#f2d94e"/>`,`<path d="M82 104c14-6 32-4 46-10" stroke="#fdfdf5" stroke-width="5" fill="none" stroke-linecap="round" opacity=".9"/>`]},{n:`ماست و خیار`,vb:'50.0 72.0 120.0 107.9',g:0.1957,d:'#fdfdf5',p:[`<path d="M50 112h120c0 28-27 46-60 46s-60-18-60-46z" fill="#cfe8f2"/><ellipse cx="110" cy="112" rx="60" ry="14" fill="#eaf4f9"/>`,`<ellipse cx="110" cy="112" rx="54" ry="11" fill="#fdfdf7"/>`,`<circle cx="88" cy="112" r="6" fill="#7bbf4a"/><circle cx="116" cy="106" r="6" fill="#7bbf4a"/><circle cx="134" cy="116" r="5" fill="#7bbf4a"/>`,`<path d="M96 96c8-4 20-2 26 2" stroke="#3f8b25" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="106" cy="100" r="2.2" fill="#3f8b25"/><circle cx="128" cy="98" r="2.2" fill="#3f8b25"/>`]}]},
seafood:{label:'غذای دریایی',items:[{n:`ماهی`,vb:'22.0 62.9 176.0 158.3',g:0.2678,d:'#f2d94e',p:[`<ellipse cx="110" cy="158" rx="88" ry="20" fill="#dfe5ec"/><ellipse cx="110" cy="154" rx="80" ry="16" fill="#f6f8fb"/>`,`<path d="M52 132c22-22 74-26 108-6-34 22-86 26-108 6z" fill="#c9a06a"/><path d="M156 120l26-14v34z" fill="#b5895a"/>`,`<path d="M74 126c16-8 40-10 62-6M78 134c16-8 40-10 60-6" stroke="#8a6a3f" stroke-width="3" fill="none" stroke-linecap="round" opacity=".7"/>`,`<circle cx="70" cy="148" r="11" fill="#f2d94e"/><circle cx="66" cy="144" r="3" fill="#fdf0c9"/>`]},{n:`میگو سوخاری`,vb:'24.0 59.4 172.0 154.7',g:0.2347,d:null,p:[`<ellipse cx="110" cy="158" rx="86" ry="19" fill="#dfe5ec"/><ellipse cx="110" cy="155" rx="78" ry="15" fill="#f6f8fb"/>`,`<g transform="rotate(-12 92 126)"><path d="M74 142c-14-8-13-27 2-35 13-7 29-2 32 10 2 11-9 19-20 22z" fill="#e8b04b"/><path d="M108 114l18-11-3 24z" fill="#d99a35"/></g>`,`<g transform="rotate(10 128 130)"><path d="M112 146c-14-8-13-27 2-35 13-7 29-2 32 10 2 11-9 19-20 22z" fill="#f2c14e"/><path d="M88 118l18-11-3 24z" fill="#e0a840"/></g>`,`<path d="M96 148c10-6 24-6 34 0" stroke="#fdfdf5" stroke-width="5" fill="none" stroke-linecap="round" opacity=".9"/><circle cx="150" cy="152" r="8" fill="#7bbf4a"/>`]}]},
kids:{label:'غذای کودکان',items:[{n:`پنکیک`,vb:'26.0 56.5 168.0 151.1',g:0.1773,d:'#b5641c',p:[`<ellipse cx="110" cy="162" rx="84" ry="18" fill="#e9edf2"/><ellipse cx="110" cy="158" rx="76" ry="15" fill="#f6f8fb"/>`,`<ellipse cx="110" cy="146" rx="58" ry="17" fill="#dda559"/>`,`<ellipse cx="110" cy="122" rx="54" ry="16" fill="#eeb678"/><ellipse cx="110" cy="100" rx="50" ry="15" fill="#f2c891"/>`,`<rect x="88" y="84" width="38" height="13" rx="6" fill="#ffe18f"/><path d="M62 106c10 12 22 16 50 16s40-6 46-14" stroke="#b5641c" stroke-width="7" fill="none" stroke-linecap="round"/>`]},{n:`ناگت`,vb:'40.0 78.3 125.0 112.4',g:0.1419,d:'#c8324a',p:[`<path d="M56 118h108l-13 56H69z" fill="#c8324a"/><path d="M56 118h108l-4 17H60z" fill="#e2496e"/>`,`<ellipse cx="84" cy="112" rx="19" ry="13" fill="#f2c14e"/><ellipse cx="118" cy="108" rx="19" ry="13" fill="#f2c14e"/><ellipse cx="148" cy="114" rx="17" ry="12" fill="#f2c14e"/>`,`<ellipse cx="78" cy="106" rx="8" ry="4" fill="#ffe4a8" opacity=".7"/><ellipse cx="112" cy="102" rx="8" ry="4" fill="#ffe4a8" opacity=".7"/>`,`<path d="M40 146c0 12 9 22 20 22s20-10 20-22z" fill="#e2496e"/><ellipse cx="60" cy="146" rx="20" ry="7" fill="#ff5d7e"/>`]}]}
};

	/* ---------------- ۱۲) بخش‌های سایت: منوی کشویی موبایل ---------------- */

	/*
	 * روی موبایل و تبلت فهرست بخش‌ها جمع است و فقط یک دکمهٔ فلش دیده
	 * می‌شود. با زدن روی فلش، فهرست باز می‌شود و فلش به سمت بالا می‌چرخد.
	 * اگر JS اجرا نشود، هیچ کلاسی اضافه نمی‌شود و فهرست مثل قبل باز می‌ماند.
	 */
	(function hubsMenu() {
		var nav = document.querySelector('[data-ashp-hubs]');
		var btn = document.querySelector('[data-ashp-hubstoggle]');
		var inner = document.querySelector('[data-ashp-hubsinner]');
		if (!nav || !btn || !inner) return;

		var MOBILE = '(max-width:1024px)';
		var isMobile = function () {
			try { return window.matchMedia(MOBILE).matches; }
			catch (e) { return window.innerWidth <= 1024; }
		};
		var open = false;
		var timer = null;

		/*
		 * بلندی سقف = ارتفاع محتوا + جای پدینگ بالا و پایین + کمی حاشیهٔ اطمینان.
		 * این «+ ۲۴» مهم است: وقتی جمع است پدینگ صفر می‌شود و scrollHeight آن را
		 * نمی‌شمارد؛ اگر سقف را دقیقاً همان بگیریم، پدینگ هنگام باز شدن محتوا را
		 * از سقف بیرون می‌زند و منو یک تکان به پایین می‌خورد.
		 */
		var SLACK = 24;

		function cap() {
			return inner.scrollHeight + SLACK;
		}

		/* فقط سقف را تازه می‌کنیم؛ هیچ‌وقت باز نمی‌گذاریمش تا پرش پیش نیاید */
		function measure() {
			if (!open || !isMobile()) return;
			nav.style.setProperty('--ashp-hubs-h', cap() + 'px');
		}

		function apply(state) {
			open = !!state;
			window.clearTimeout(timer);
			nav.classList.toggle('is-open', open);
			btn.setAttribute('aria-expanded', open ? 'true' : 'false');
			btn.setAttribute('aria-label', open
				? (btn.getAttribute('data-label-close') || 'بستن بخش‌ها')
				: (btn.getAttribute('data-label-open') || 'نمایش بخش‌های سایت'));

			/* بلندی واقعی فهرست + حاشیهٔ اطمینان (توضیح در بالای همین بخش) */
			nav.style.setProperty('--ashp-hubs-h', (open ? cap() : Math.max(cap(), 1)) + 'px');

			/* خواندن یک ویژگی، مرورگر را مجبور می‌کند همین حالا حساب کند */
			void inner.offsetHeight;

			/* اگر متن موقع باز شدن شکست، سقف را پس از پایان انیمیشن دوباره حساب می‌کنیم */
			if (open) {
				timer = window.setTimeout(function () {
					if (open) nav.style.setProperty('--ashp-hubs-h', cap() + 'px');
				}, 520);
			} else {
				nav.style.setProperty('--ashp-hubs-h', '0px');
			}
		}

		/*
		 * موبایل: فهرست جمع است و دکمه کار می‌کند.
		 * دسکتاپ: دکمه پنهان است و فهرست همیشه باز می‌ماند.
		 */
		function syncMode() {
			if (isMobile()) {
				apply(open);
			} else {
				nav.classList.remove('is-open');
				nav.style.removeProperty('--ashp-hubs-h');
				btn.setAttribute('aria-expanded', 'true');
				open = false;
			}
		}

		btn.addEventListener('click', function () { apply(!open); });

		/* با تغییر اندازه یا چرخش گوشی، بلندی دوباره حساب می‌شود */
		window.addEventListener('resize', measure, { passive: true });
		window.addEventListener('orientationchange', function () { window.setTimeout(measure, 260); });

		syncMode();
		window.setTimeout(syncMode, 300);
	})();

	/* ---------------- ۱۳) راهنما تا اولین اسکرول ---------------- */

	/*
	 * تا کاربر اسکرول نکرده، بخش «آشپزباشی چگونه کار می‌کند؟» دیده نمی‌شود.
	 * ارتفاعش سر جایش می‌ماند تا صفحه نپرد؛ فقط کور می‌شود.
	 */
	(function scrollGate() {
		var root = document.documentElement;
		var done = false;
		var y = function () {
			return window.pageYOffset || root.scrollTop || 0;
		};

		var poll = null;
		var onEvent = null;

		function release() {
			if (done) return;
			done = true;
			root.classList.remove('ashp-gate');
			if (poll) { window.clearInterval(poll); poll = null; }
			if (onEvent) {
				window.removeEventListener('scroll', onEvent, true);
				document.removeEventListener('scroll', onEvent, true);
				window.removeEventListener('wheel', onEvent, { passive: true });
				window.removeEventListener('touchmove', onEvent, { passive: true });
				window.removeEventListener('keydown', onEvent, true);
				window.removeEventListener('pointerdown', onEvent, true);
			}
		}

		function check() { if (y() > 8) release(); }

		/* اگر کاربر وسط صفحه باز کرده باشد، چیزی پنهان نمی‌کنیم */
		if (y() > 8) return;
		root.classList.add('ashp-gate');

		/*
		 * اسکرول با هر روشی که انجام شود (چرخ ماوس، لمس، کلید، نوار اسکرول یا
		 * پرش به لنگر)، باید قفل را باز کند؛ پس هم رویدادها را می‌شنویم و هم
		 * هر ۲۵۰ میلی‌ثانیه جای صفحه را نگاه می‌کنیم. بعد از باز شدن، همه چیز
		 * پاک می‌شود و دیگر هزینه‌ای ندارد.
		 */
		onEvent = check;
		window.addEventListener('scroll', onEvent, true);
		document.addEventListener('scroll', onEvent, true);
		window.addEventListener('wheel', onEvent, { passive: true });
		window.addEventListener('touchmove', onEvent, { passive: true });
		window.addEventListener('keydown', onEvent, true);
		window.addEventListener('pointerdown', onEvent, true);
		poll = window.setInterval(check, 250);

		/* اگر صفحه اسکرول ندارد، قفل کردن معنا ندارد */
		window.addEventListener('load', function () {
			if (document.documentElement.scrollHeight <= window.innerHeight + 40) release();
		});
	})();

	/* ---------------- ۱۰) موتور اسکرول (رفت و برگشتی) ---------------- */

	var A3D_REDUCED = false;
	try { A3D_REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
	var A3D_NATIVE = !!(window.CSS && CSS.supports && CSS.supports('animation-timeline: view()'));
	var A3D_DESKTOP = !!(window.matchMedia && window.matchMedia('(min-width:1025px)').matches);
	var a3dActive = [];

	/* برچسب‌گذاری خودکار همهٔ بخش‌ها و کارت‌های سایت */
	function a3dTag() {
		var map = [
			['.ashp-roadmap', 'deep'],
			['.ashp-section', 'section'],
			['.ashp-band', 'section'],
			['.ashp-page__head', 'section'],
			['.ashp-catcard', 'card'],
			['.ashp-rcard', 'card'],
			['.ashp-ingcard', 'card'],
			['.ashp-hub', 'card'],
			['.ashp-recipe__card', 'card'],
			['.ashp-footer__col', 'card'],
			['.ashp-steps li', 'side'],
			['.ashp-inglist li', 'side'],
			['.ashp-roadmap article', 'card'],
			['.ashp-stat', 'stat']
		];
		map.forEach(function (pair) {
			$$(pair[0]).forEach(function (el) {
				if (el.hasAttribute('data-ashp-3d')) return;
				/* هدر در موبایل کاملاً ثابت می‌ماند */
				if (!A3D_DESKTOP && el.closest && el.closest('.ashp-header')) return;
				el.setAttribute('data-ashp-3d', pair[1]);
			});
		});
		var hero = document.querySelector('.ashp-hero');
		if (hero && hero.children) {
			Array.prototype.forEach.call(hero.children, function (el, i) {
				if (!el.hasAttribute('data-ashp-par')) el.setAttribute('data-ashp-par', String(i));
			});
		}
	}

	/* --- فالبک برای مرورگرهایی که animation-timeline: view() ندارند --- */
	function a3dApply(el, p) {
		var kind = el.getAttribute('data-ashp-3d') || 'section';
		var amp = kind === 'card' ? 0.9 : (kind === 'deep' ? 1.35 : (kind === 'stat' ? 0.75 : 1.1));
		var q = Math.max(0, Math.min(1, p / 0.4));
		var e = 1 - Math.pow(1 - q, 3);
		var inv = 1 - e;
		var side = kind === 'side';
		var x = side ? (26 * amp * inv) : 0;
		var y = (-52 * amp * inv);
		var sc = 1 - 0.04 * amp * inv;
		el.style.transform = 'translate3d(' + x.toFixed(2) + 'px,' + y.toFixed(2) +
			'px,0) scale(' + sc.toFixed(4) + ')';
		el.style.opacity = e <= 0.002 ? '0' : e.toFixed(3);
	}

	function a3dProgress(el) {
		var r = el.getBoundingClientRect();
		var vh = window.innerHeight || document.documentElement.clientHeight;
		return Math.max(0, Math.min(1, (vh - r.top) / ((vh + r.height) || 1)));
	}

	function a3dParallax() {
		var hero = document.querySelector('.ashp-hero');
		if (!hero) return;
		var r = hero.getBoundingClientRect();
		var vh = window.innerHeight || document.documentElement.clientHeight;
		if (r.bottom < -100 || r.top > vh + 100) return;
		var sc = Math.max(0, Math.min(1, (vh - r.top) / ((vh + r.height) || 1)));
		$$('[data-ashp-par]', hero).forEach(function (el) {
			var d = parseFloat(el.getAttribute('data-ashp-par')) || 0;
			el.style.transform = 'translate3d(0,' + (sc * (10 + d * 9)).toFixed(2) + 'px,' +
				(-sc * (26 + d * 18)).toFixed(2) + 'px)';
		});
	}

	var a3dTick = false;
	function a3dRun() {
		a3dTick = false;
		if (A3D_REDUCED) return;
		for (var i = 0; i < a3dActive.length; i++) {
			a3dApply(a3dActive[i], a3dProgress(a3dActive[i]));
		}
		a3dParallax();
		foodPeel(window.pageYOffset || document.documentElement.scrollTop || 0);
	}
	function a3dOnScroll() {
		if (a3dTick) return;
		a3dTick = true;
		requestAnimationFrame(a3dRun);
	}


	/* محافظ: اگر بر اثر نبود اسکرول یا خطا، محتوای بالای صفحه نامرئی بماند،
	   افکت اسکرولی خاموش می‌شود تا سایت هرگز خالی دیده نشود. */
	function a3dGuard() {
		var check = function () {
			var vh = window.innerHeight || document.documentElement.clientHeight;
			var els = $$('[data-ashp-3d]');
			for (var i = 0; i < els.length; i++) {
				var el = els[i];
				var r = el.getBoundingClientRect();
				if (r.bottom <= 0 || r.top >= vh * 0.5) continue; /* فقط نیمهٔ بالای صفحه */
				var op = parseFloat(window.getComputedStyle(el).opacity);
				if (op < 0.06) {
					document.documentElement.classList.remove('ashp-3d-on');
					return;
				}
			}
		};
		setTimeout(check, 1400);
		setTimeout(check, 3200);
	}

	function a3dInit() {
		if (A3D_REDUCED) return;
		/* موبایل/تبلت: موتور انیمیشن اسکرول کاملاً خاموش می‌ماند تا اسکرول روان بماند */
		if (!A3D_DESKTOP) return;
		a3dTag();
		if (A3D_NATIVE) {
			/* فقط وقتی صفحه واقعاً اسکرول دارد؛ وگرنه تایم‌لاین غیرفعال می‌شود */
			if (document.documentElement.scrollHeight > window.innerHeight + 60) {
				document.documentElement.classList.add('ashp-3d-on');
				a3dGuard();
			}
		} else if ('IntersectionObserver' in window) {
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (en) {
					var el = en.target;
					var idx = a3dActive.indexOf(el);
					if (en.isIntersecting) {
						if (idx < 0) a3dActive.push(el);
					} else {
						if (idx > -1) a3dActive.splice(idx, 1);
						a3dApply(el, (en.boundingClientRect.top > 0) ? 0 : 1);
					}
				});
				a3dOnScroll();
			}, { rootMargin: '180px 0px 180px 0px' });
			$$('[data-ashp-3d]').forEach(function (el) { io.observe(el); });
		} else {
			a3dActive = $$('[data-ashp-3d]');
		}
		a3dRun();
		window.addEventListener('scroll', a3dOnScroll, { passive: true });
		window.addEventListener('resize', a3dOnScroll, { passive: true });
		foodStage();
	}

	/* ---------- ۱۰) صفحهٔ لودینگ ---------- */
	(function loader() {
		var el = document.getElementById('ashp-loader');
		if (!el) return;

		var done = false;
		function hide() {
			if (done) return;
			done = true;
			el.classList.add('is-done');
			window.setTimeout(function () {
				if (el.parentNode) el.parentNode.removeChild(el);
			}, 600);
		}

		if (document.readyState === 'complete') {
			window.setTimeout(hide, 220);
		} else {
			window.addEventListener('load', function () { window.setTimeout(hide, 220); });
		}
		/* اگر منابع کند بودند، بیش از ۱.۸ ثانیه معطل نمی‌مانیم */
		window.setTimeout(hide, 1800);
	})();

	/* ---------- ۱۱) ریزش غذاهای کوچک (فقط موبایل) ---------- */
	(function foodRain() {
		var wrap = document.querySelector('.ashp-mini--fall');
		if (!wrap) return;
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
		if (!window.matchMedia('(max-width: 1024px)').matches) return;

		var cards = wrap.querySelectorAll('.ashp-minicard');
		if (!cards.length) return;

		var played = false;
		function rnd(min, max) { return min + Math.random() * (max - min); }

		function play() {
			if (played) return;
			played = true;
			cards.forEach(function (c, i) {
				/* جای پرتاب، میزان چرخش، مدت سقوط و حالت ایستادن: رندوم */
				c.style.setProperty('--dx', rnd(-70, 70).toFixed(1) + 'px');
				c.style.setProperty('--rot', rnd(-34, 34).toFixed(1) + 'deg');
				c.style.setProperty('--end-rot', rnd(-7, 7).toFixed(1) + 'deg');
				c.style.setProperty('--dur', Math.round(rnd(760, 1380)) + 'ms');
				c.style.setProperty('--delay', Math.round(rnd(0, 820) + i * 12) + 'ms');
			});
		}

		if ('IntersectionObserver' in window) {
			var io = new IntersectionObserver(function (en) {
				if (en[0].isIntersecting) { play(); io.disconnect(); }
			}, { rootMargin: '0px 0px -12% 0px' });
			io.observe(wrap);
		} else {
			play();
		}
	})();

	/* ---------- ۱۲) ریزش وکتور غذای سه‌بعدی (فقط موبایل، فقط صفحهٔ اصلی) ----------
	   با هر رفرش، یک وکتور غذای تصادفی از بالای صفحه می‌افتد، کاربر آن را
	   می‌بیند، و پس از فرود روی «زمینِ» بالای فوتر می‌ایستد. جای پرتاب،
	   مسیر، چرخش، سرعت و حالت ایستادن همه رندوم‌اند. */
	(function foodRain() {
		var ground = document.querySelector('.ashp-rain');
		if (!ground) return;
		if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
		if (!window.matchMedia('(max-width: 1024px)').matches) return;
		if (typeof ASHP_FOODS === 'undefined' || !ASHP_FOODS) return;

		var pool = [], k, i, items;
		for (k in ASHP_FOODS) {
			if (!ASHP_FOODS.hasOwnProperty(k)) continue;
			items = ASHP_FOODS[k].items || [];
			for (i = 0; i < items.length; i++) pool.push(items[i]);
		}
		if (!pool.length) return;

		var food  = pool[Math.floor(Math.random() * pool.length)];
		var vb    = food.vb || '0 0 220 196';
		var parts = food.p || [];
		var svg   = '<svg viewBox="' + vb + '" preserveAspectRatio="xMidYMid meet" role="img" aria-label="' +
			String(food.n || '') + '">';
		for (i = 0; i < parts.length; i++) svg += '<g>' + parts[i] + '</g>';
		svg += '</svg>';

		function rnd(a, b) { return a + Math.random() * (b - a); }

		var x0    = rnd(4, 74);                                   /* درصد عرض */
		var x1    = Math.max(2, Math.min(84, x0 + rnd(-28, 28))); /* مسیر مورب */
		var spin  = (Math.random() < 0.5 ? -1 : 1) * rnd(200, 780);
		var dur   = Math.round(rnd(3000, 5400));
		var delay = Math.round(rnd(250, 1300));

		var fly = document.createElement('div');
		fly.className = 'ashp-rain__fly';
		fly.setAttribute('aria-hidden', 'true');
		fly.innerHTML = svg;
		fly.style.setProperty('--x0', x0.toFixed(1) + 'vw');
		fly.style.setProperty('--x1', x1.toFixed(1) + 'vw');
		fly.style.setProperty('--spin', spin.toFixed(0) + 'deg');
		fly.style.setProperty('--dur', dur + 'ms');
		fly.style.setProperty('--delay', delay + 'ms');
		document.body.appendChild(fly);

		fly.addEventListener('animationend', function () {
			var rest = document.createElement('div');
			rest.className = 'ashp-rain__rest';
			rest.setAttribute('aria-hidden', 'true');
			rest.style.setProperty('--rest-rot', rnd(-8, 8).toFixed(1) + 'deg');
			rest.style.setProperty('--rest-x', rnd(-34, 34).toFixed(0) + '%');
			rest.innerHTML = svg;
			ground.appendChild(rest);
			if (fly.parentNode) fly.parentNode.removeChild(fly);
		}, { once: true });
	})();

	a3dInit();
})();
