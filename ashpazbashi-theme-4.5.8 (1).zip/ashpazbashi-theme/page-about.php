<?php
/**
 * Template Name: درباره ما
 *
 * @package Ashpazbashi
 */
get_header();
?>
<div class="ashp-wrap">
	<header class="ashp-page__head">
		<h1 class="ashp-page__title"><?php esc_html_e( 'درباره ما', 'ashpazbashi' ); ?></h1>
		<div class="ashp-neonline" aria-hidden="true"></div>
	</header>

	<div class="ashp-content ashp-about">
		<?php
		$ashp_admin_content = ( class_exists( 'ASHP_DB' ) ) ? ASHP_DB::page_content( 'about' ) : '';
		$ashp_fallback = ashpazbashi_default_page( 'about' );
		if ( '' === trim( $ashp_admin_content ) ) {
			$ashp_admin_content = $ashp_fallback;
		}
		if ( '' !== trim( $ashp_admin_content ) ) {
			echo wpautop( wp_kses_post( $ashp_admin_content ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- فیلترشده
		} else {
		while ( have_posts() ) :
			the_post();
			$content = get_the_content();
			if ( trim( wp_strip_all_tags( $content ) ) ) {
				the_content();
			} else {
				// متن پیش‌فرض — از پیشخوان قابل ویرایش است.
				?>
				<section class="ashp-panel">
					<h2><?php esc_html_e( 'آشپزباشی کیست؟', 'ashpazbashi' ); ?></h2>
					<p><?php esc_html_e( 'آشپزباشی یک دستیار آشپزی است که به شما می‌گوید با موادی که همین حالا در خانه دارید، چه غذایی می‌توانید بپزید. کافی است اسمتان را بنویسید، دستهٔ غذا را انتخاب کنید و مواد اولیه‌ای که در دسترس دارید را علامت بزنید؛ آشپزباشی از میان دیتابیس غذاهای ایرانی، محلی، فست‌فود ایتالیایی، آمریکایی و ترکی، غذاهای قابل طبخ را با دستور پخت کامل به شما نشان می‌دهد.', 'ashpazbashi' ); ?></p>
					<p><?php esc_html_e( 'هدف آشپزباشی ساده است: انتخاب غذا را از یک تصمیم سخت به یک تجربهٔ سریع و دوست‌داشتنی تبدیل کند؛ از انتخاب مواد اولیه تا رسیدن به دستور پخت.', 'ashpazbashi' ); ?></p>
				</section>

				<section class="ashp-panel" id="rules">
					<h2><?php esc_html_e( 'قوانین و مقررات', 'ashpazbashi' ); ?></h2>
					<ul>
						<li><?php esc_html_e( 'استفاده از دستور پخت‌ها برای مصرف شخصی و خانگی آزاد است.', 'ashpazbashi' ); ?></li>
						<li><?php esc_html_e( 'بازنشر محتوای سایت با ذکر منبع و لینک مستقیم مجاز است.', 'ashpazbashi' ); ?></li>
						<li><?php esc_html_e( 'نظرات کاربران پس از بررسی و تأیید مدیر منتشر می‌شوند.', 'ashpazbashi' ); ?></li>
					</ul>
				</section>

				<section class="ashp-panel" id="privacy">
					<h2><?php esc_html_e( 'حریم خصوصی', 'ashpazbashi' ); ?></h2>
					<p><?php esc_html_e( 'برای استفاده از سایت، هیچ ثبت‌نامی لازم نیست و ما رمز عبوری از شما نمی‌گیریم. تنها یک نام که خودتان وارد می‌کنید در مرورگر شما (کوکی) ذخیره می‌شود تا دفعهٔ بعد که سایت را باز کردید، همان نام نمایش داده شود. ایمیل و شماره تماس شما هرگز بدون اجازه منتشر نمی‌شود.', 'ashpazbashi' ); ?></p>
				</section>

				<section class="ashp-panel">
					<h2><?php esc_html_e( 'ارتباط با ما', 'ashpazbashi' ); ?></h2>
					<p>
						<?php esc_html_e( 'ایمیل:', 'ashpazbashi' ); ?>
						<a dir="ltr" href="mailto:<?php echo esc_attr( ashpazbashi_contact( 'email' ) ); ?>"><?php echo esc_html( ashpazbashi_contact( 'email' ) ); ?></a>
					</p>
					<?php if ( ashpazbashi_contact( 'phone' ) ) : ?>
						<p>
							<?php esc_html_e( 'تلفن:', 'ashpazbashi' ); ?>
							<a dir="ltr" href="<?php echo esc_url( ashpazbashi_tel_href() ); ?>"><?php echo esc_html( ashpazbashi_contact( 'phone' ) ); ?></a>
						</p>
					<?php endif; ?>
					<p><a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( ashpazbashi_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'صفحهٔ تماس با ما', 'ashpazbashi' ); ?></a></p>
				</section>
				<?php
			}
		endwhile;
		}
		?>
	</div>
</div>
<?php get_footer(); ?>
