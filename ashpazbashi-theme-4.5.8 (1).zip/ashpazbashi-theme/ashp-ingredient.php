<?php
/**
 * صفحهٔ یک مادهٔ اولیه — غذاهایی که این ماده را دارند
 *
 * این قالب توسط افزونهٔ «آشپزباشی — موتور» و از طریق ASHP_DB بارگذاری می‌شود.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$ashp_ing_row = ASHP_DB::current_ingredient();
if ( ! is_array( $ashp_ing_row ) ) {
	$ashp_ing_row = null;
}
$ashp_ctx = ASHP_DB::current_list_context();
if ( ! is_array( $ashp_ctx ) ) {
	$ashp_ctx = array();
}
$ashp_rows  = isset( $ashp_ctx['rows'] ) ? $ashp_ctx['rows'] : array();
$ashp_total = isset( $ashp_ctx['total'] ) ? (int) $ashp_ctx['total'] : 0;
?>
<div class="ashp-wrap">

	<nav class="ashp-breadcrumb" aria-label="<?php esc_attr_e( 'مسیر صفحه', 'ashpazbashi' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'خانه', 'ashpazbashi' ); ?></a>
		<span aria-hidden="true">›</span>
		<a href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'مواد اولیه', 'ashpazbashi' ); ?></a>
	</nav>

	<?php if ( ! $ashp_ing_row ) : ?>

		<div class="ashp-empty ashp-empty--big">
			<h1 class="ashp-page__title"><?php esc_html_e( 'این مادهٔ اولیه پیدا نشد', 'ashpazbashi' ); ?></h1>
			<p><?php esc_html_e( 'از صفحهٔ مواد اولیه می‌توانی همهٔ مواد موجود در آشپزباشی را ببینی.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'مواد اولیه', 'ashpazbashi' ); ?></a>
			</div>
		</div>

	<?php else : ?>

		<header class="ashp-section__head">
			<h1 class="ashp-section__title"><?php echo esc_html( sprintf( __( 'غذاهایی با %s', 'ashpazbashi' ), $ashp_ing_row['name'] ) ); ?></h1>
			<p class="ashp-section__sub">
				<?php
				printf(
					/* translators: %s: number of recipes */
					esc_html__( '%s دستور پخت با این ماده پیدا شد.', 'ashpazbashi' ),
					esc_html( number_format_i18n( $ashp_total ) )
				);
				?>
			</p>
		</header>

		<?php if ( $ashp_rows ) : ?>
			<div class="ashp-grid ashp-grid--cards">
				<?php foreach ( $ashp_rows as $r ) { echo ASHP_Front::recipe_card( $r ); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php else : ?>
			<div class="ashp-empty">
				<p><?php esc_html_e( 'برای این ماده هنوز دستوری ثبت نشده است.', 'ashpazbashi' ); ?></p>
			</div>
		<?php endif; ?>

		<div class="ashp-recipe__actions">
			<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'آشپزی با مواد موجود', 'ashpazbashi' ); ?></a>
		</div>

	<?php endif; ?>

</div>
<?php get_footer(); ?>
