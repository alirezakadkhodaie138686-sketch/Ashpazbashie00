<?php
/**
 * Ashpazbashi — قالب «آشپزباشی»
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* لایهٔ سئو، GEO و AEO — عنوان، توضیحات متا، canonical، اسکیما و نقشهٔ سایت */
require_once get_template_directory() . '/inc/seo.php';

if ( ! defined( 'ASHP_VER' ) ) {
	define( 'ASHP_VER', '4.5.8' );
}
if ( ! defined( 'ASHP_SITE_NAME' ) ) {
	define( 'ASHP_SITE_NAME', 'آشپزباشی' );
}
if ( ! defined( 'ASHP_TAGLINE' ) ) {
	define( 'ASHP_TAGLINE', 'بگو چه موادی داری، آشپزباشی بهترین غذا را پیشنهاد می‌دهد.' );
}

/* -------------------------------------------------------------------------
 * ۰) بررسی وجود افزونهٔ موتور
 * ---------------------------------------------------------------------- */
function ashpazbashi_engine_notice() {
	if ( class_exists( 'ASHP_DB' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'افزونهٔ «آشپزباشی — موتور و مدیریت» فعال نیست.', 'ashpazbashi' ) . '</strong> ' .
		esc_html__( 'این قالب لایهٔ نمایش است و برای نمایش غذاها، مواد اولیه و پنل مدیریت به افزونهٔ آشپزباشی نیاز دارد.', 'ashpazbashi' ) . ' ' .
		'<a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'رفتن به صفحهٔ افزونه‌ها', 'ashpazbashi' ) . '</a></p></div>';
}
add_action( 'admin_notices', 'ashpazbashi_engine_notice' );

/* -------------------------------------------------------------------------
 * ۱) راه‌اندازی قالب
 * ---------------------------------------------------------------------- */
function ashpazbashi_setup() {
	load_theme_textdomain( 'ashpazbashi', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'custom-logo', array(
		'height'      => 120,
		'width'       => 120,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

	add_editor_style( 'assets/css/main.css' );

	register_nav_menus( array(
		'primary'      => __( 'منوی اصلی (هدر)', 'ashpazbashi' ),
		'footer'       => __( 'منوی فوتر', 'ashpazbashi' ),
		'footer_links' => __( 'لینک‌های مفید فوتر', 'ashpazbashi' ),
	) );

	add_image_size( 'ashp-card', 640, 420, true );
	add_image_size( 'ashp-hero', 1200, 750, true );
}
add_action( 'after_setup_theme', 'ashpazbashi_setup' );

/* -------------------------------------------------------------------------
 * ۲) بارگذاری استایل و اسکریپت (همه محلی، بدون CDN)
 * ---------------------------------------------------------------------- */
/**
 * نسخهٔ دارایی‌های قالب.
 *
 * قبلاً یک عدد ثابت بود و هر بار که فایل CSS/JS عوض می‌شد بالا نمی‌رفت؛
 * نتیجه‌اش این بود که مرورگر و CDN نسخهٔ کش‌شدهٔ قدیمی را سرو می‌کردند و
 * ظاهر سایت با کد تازه ناهماهنگ می‌شد. الان از زمانِ آخرین تغییر فایل
 * ساخته می‌شود، پس با هر آپلود خودش عوض می‌شود.
 */
function ashpazbashi_asset_ver( $rel ) {
	$file = get_template_directory() . $rel;
	if ( file_exists( $file ) ) {
		return ASHP_VER . '.' . filemtime( $file );
	}
	return ASHP_VER;
}

function ashpazbashi_assets() {
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'ashp-fonts', $uri . '/assets/css/fonts.css', array(), ashpazbashi_asset_ver( '/assets/css/fonts.css' ) );
	wp_enqueue_style( 'ashp-main', $uri . '/assets/css/main.css', array( 'ashp-fonts' ), ashpazbashi_asset_ver( '/assets/css/main.css' ) );
	wp_enqueue_style( 'ashp-style', get_stylesheet_uri(), array( 'ashp-main' ), ASHP_VER );

	/* استایل نظرها و امتیاز — فقط در صفحهٔ دستور پخت بارگذاری می‌شود */
	$ashp_is_recipe = ( class_exists( 'ASHP_Router' ) && ASHP_Router::is_recipe_page() );
	if ( $ashp_is_recipe ) {
		wp_enqueue_style(
			'ashp-reviews',
			$uri . '/assets/css/reviews.css',
			array( 'ashp-main' ),
			ashpazbashi_asset_ver( '/assets/css/reviews.css' )
		);
	}

	wp_enqueue_script( 'ashp-cursor', $uri . '/assets/js/cursor.js', array(), ashpazbashi_asset_ver( '/assets/js/cursor.js' ), true );
	wp_enqueue_script( 'ashp-main-js', $uri . '/assets/js/main.js', array( 'ashp-cursor' ), ashpazbashi_asset_ver( '/assets/js/main.js' ), true );

	$ashp_foodsettings = class_exists( 'ASHP_FoodSettings' ) ? ASHP_FoodSettings::js_payload() : null;

	wp_localize_script( 'ashp-main-js', 'ASHP', array(
		'foodsettings' => $ashp_foodsettings,
		'cat'    => ashpazbashi_current_food_cat(),
		'home'   => esc_url( home_url( '/' ) ),
		'ajax'   => esc_url( admin_url( 'admin-ajax.php' ) ),
		'nonce'  => wp_create_nonce( 'ashp_nonce' ),
		'name'   => ashpazbashi_current_name(),
		'plugin' => class_exists( 'ASHP_DB' ) ? '1' : '0',
		'i18n'   => array(
			'welcome'  => __( 'جون خوش اومدی', 'ashpazbashi' ),
			'askName'  => __( 'اسمت چیه؟', 'ashpazbashi' ),
			'nameHint' => __( 'اسمت را وارد کن تا آشپزباشی با تو حرف بزند و پیشنهاد بدهد.', 'ashpazbashi' ),
			'start'    => __( 'شروع آشپزی', 'ashpazbashi' ),
			'pickMin'  => __( 'حداقل ۳ مادهٔ اصلی انتخاب کن تا غذاها نمایش داده شوند.', 'ashpazbashi' ),
			'noResult' => __( 'غذایی با این مواد پیدا نشد. مواد دیگری امتحان کن.', 'ashpazbashi' ),
			'loading'  => __( 'آشپزباشی در حال فکر کردن است…', 'ashpazbashi' ),
			'selected' => __( 'انتخاب‌شده', 'ashpazbashi' ),
			'thanks'   => __( 'ممنون! نظرت برای تأیید به پنل مدیریت رفت.', 'ashpazbashi' ),
		),
	) );
}
add_action( 'wp_enqueue_scripts', 'ashpazbashi_assets' );

/* -------------------------------------------------------------------------
 * ۳) نام کاربر — فقط با وارد کردن اسم، بدون ثبت‌نام
 * ---------------------------------------------------------------------- */
function ashpazbashi_current_name() {
	if ( ! empty( $_COOKIE['ashp_name'] ) ) {
		return sanitize_text_field( wp_unslash( $_COOKIE['ashp_name'] ) );
	}
	return '';
}

/**
 * ذخیرهٔ نام در کوکی (سمت سرور) تا در همان مرورگر دفعهٔ بعد نمایش داده شود.
 */
function ashpazbashi_save_name() {
	check_ajax_referer( 'ashp_nonce', 'nonce' );
	$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	if ( function_exists( 'mb_substr' ) ) {
		$name = mb_substr( $name, 0, 40 );
	} else {
		$name = substr( $name, 0, 40 );
	}
	$name = trim( $name );
	if ( '' === $name ) {
		wp_send_json_error( array( 'msg' => __( 'نام خالی است', 'ashpazbashi' ) ) );
	}
	setcookie(
		'ashp_name',
		$name,
		array(
			'expires'  => time() + YEAR_IN_SECONDS,
			'path'     => COOKIEPATH ? COOKIEPATH : '/',
			'domain'   => COOKIE_DOMAIN,
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		)
	);
	wp_send_json_success( array( 'name' => $name ) );
}
add_action( 'wp_ajax_ashp_save_name', 'ashpazbashi_save_name' );
add_action( 'wp_ajax_nopriv_ashp_save_name', 'ashpazbashi_save_name' );

/* -------------------------------------------------------------------------
 * ۴) ابزارک‌ها
 * ---------------------------------------------------------------------- */
function ashpazbashi_widgets() {
	register_sidebar( array(
		'name'          => __( 'ستون کناری', 'ashpazbashi' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<section class="ashp-widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="ashp-widget__title">',
		'after_title'   => '</h3>',
	) );
	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar( array(
			/* translators: %d: footer column number */
			'name'          => sprintf( __( 'فوتر — ستون %d', 'ashpazbashi' ), $i ),
			'id'            => 'footer-' . $i,
			'before_widget' => '<section class="ashp-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h4 class="ashp-widget__title">',
			'after_title'   => '</h4>',
		) );
	}
}
add_action( 'widgets_init', 'ashpazbashi_widgets' );

/**
 * آیکن متحرک «بشقاب اسپاگتی و چنگال» — سبک تصویرسازی مسطح ارسالی
 */
function ashpazbashi_dish_icon( $size = 58 ) {
	$s = (int) $size;
	if ( $s < 24 ) {
		$s = 24;
	}
	static $n = 0;
	$n++;
	$g = 'ashpDish' . $n;
	return '<svg class="ashp-dish" viewBox="0 0 96 96" width="' . $s . '" height="' . $s . '" role="img" aria-label="' . esc_attr__( 'بشقاب اسپاگتی و چنگال', 'ashpazbashi' ) . '">
		<defs>
			<linearGradient id="' . $g . 'p" x1="0" y1="0" x2="0" y2="1">
				<stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#dce2ea"/>
			</linearGradient>
			<linearGradient id="' . $g . 'n" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0%" stop-color="#ffd873"/><stop offset="100%" stop-color="#eda02f"/>
			</linearGradient>
			<linearGradient id="' . $g . 'm" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0%" stop-color="#e2496e"/><stop offset="100%" stop-color="#b21f3d"/>
			</linearGradient>
			<linearGradient id="' . $g . 'f" x1="0" y1="0" x2="1" y2="1">
				<stop offset="0%" stop-color="#bcc8d4"/><stop offset="100%" stop-color="#8f9dab"/>
			</linearGradient>
		</defs>
		<ellipse class="ashp-dish__shadow" cx="48" cy="80" rx="31" ry="5.6" fill="#000" opacity=".3"/>
		<ellipse cx="48" cy="70.5" rx="38" ry="14.5" fill="#c2cad4"/>
		<ellipse cx="48" cy="66" rx="38" ry="14.5" fill="url(#' . $g . 'p)"/>
		<ellipse cx="48" cy="67" rx="28.5" ry="10.6" fill="#eef2f7"/>
		<ellipse cx="48" cy="67" rx="26.5" ry="9.6" fill="url(#' . $g . 'n)"/>
		<g class="ashp-dish__swirl" fill="none" stroke="#dd9528" stroke-width="2.1" stroke-linecap="round" opacity=".55">
			<ellipse cx="48" cy="67" rx="20.5" ry="7.2"/>
			<ellipse cx="48" cy="67" rx="13" ry="4.6"/>
		</g>
		<path class="ashp-dish__food" d="M32 64.4c1.2-5.8 7.8-9.8 15.2-9.2 6.8.6 11.8 4.6 11.8 9 0 3.6-5.6 5.8-14.2 5.8s-14.2-2-12.8-5.6Z" fill="url(#' . $g . 'm)"/>
		<path d="M38.5 60c3.4-2.4 9-2.6 12.6-.4" stroke="#f19cb0" stroke-width="2" fill="none" stroke-linecap="round" opacity=".85"/>
		<g class="ashp-dish__steam" fill="none" stroke="#bcc9d6" stroke-width="2.2" stroke-linecap="round" opacity=".7">
			<path class="ashp-dish__s1" d="M31 42c-3 3.4 3 6.6 0 10"/>
			<path class="ashp-dish__s2" d="M39 38c-3 3.4 3 6.6 0 10"/>
			<path class="ashp-dish__s3" d="M47 42c-3 3.4 3 6.6 0 10"/>
		</g>
		<g class="ashp-dish__fork">
			<g transform="translate(60 42) rotate(34) scale(0.78)">
				<rect x="-3.2" y="-36" width="6.4" height="30" rx="3.2" fill="url(#' . $g . 'f)"/>
				<path d="M-7-9h14a3.4 3.4 0 0 1 3.4 3.4v2.6A3.4 3.4 0 0 1 7-.6h-14A3.4 3.4 0 0 1-10.4-4v-2.6A3.4 3.4 0 0 1-7-9Z" fill="url(#' . $g . 'f)"/>
				<rect x="-5.6" y="-0.6" width="2.5" height="12" rx="1.25" fill="#9dabb9"/>
				<rect x="-1.25" y="-0.6" width="2.5" height="13.6" rx="1.25" fill="#9dabb9"/>
				<rect x="3.1" y="-0.6" width="2.5" height="12" rx="1.25" fill="#9dabb9"/>
			</g>
		</g>
		<g class="ashp-dish__strands" fill="none" stroke="url(#' . $g . 'n)" stroke-width="4.4" stroke-linecap="round">
			<path class="ashp-dish__d1" d="M49 46c-3.4 6-8 11-10.6 16.6"/>
			<path class="ashp-dish__d2" d="M52 48c-3 5.8-6.8 10-9.2 14.4"/>
			<path class="ashp-dish__d3" d="M55 50c-2.4 5.2-4.8 8.6-6.8 12"/>
		</g>
	</svg>';
}

/* -------------------------------------------------------------------------
 * ۵) استیکر لبخند با گونه‌های سرخ (SVG درون‌خطی)
 * ---------------------------------------------------------------------- */
function ashpazbashi_blush_sticker( $size = 26 ) {
	$s = (int) $size;
	return '<svg class="ashp-blush" width="' . $s . '" height="' . $s . '" viewBox="0 0 64 64" role="img" aria-label="' . esc_attr__( 'لبخند با گونه‌های سرخ', 'ashpazbashi' ) . '">
		<defs><radialGradient id="ashpFace" cx="50%" cy="40%" r="70%">
			<stop offset="0%" stop-color="#fff3c4"/><stop offset="100%" stop-color="#ffd166"/>
			</radialGradient></defs>
		<circle cx="32" cy="32" r="28" fill="url(#ashpFace)" stroke="#ff2e6a" stroke-width="3"/>
		<circle cx="17" cy="40" r="7" fill="#ff2450" opacity=".85"/>
		<circle cx="47" cy="40" r="7" fill="#ff2450" opacity=".85"/>
		<circle cx="22" cy="25" r="3.6" fill="#2b0a2e"/>
		<circle cx="42" cy="25" r="3.6" fill="#2b0a2e"/>
		<path d="M20 39c3.5 6 8 8.5 12 8.5S40.5 45 44 39" fill="none" stroke="#2b0a2e" stroke-width="3.4" stroke-linecap="round"/>
	</svg>';
}

/* -------------------------------------------------------------------------
 * ۶) لوگو — در صورت تنظیم «لوگوی سفارشی»، همان نمایش داده می‌شود
 * ---------------------------------------------------------------------- */
function ashpazbashi_logo( $size = 48 ) {
	$size = (int) $size;

	if ( has_custom_logo() ) {
		$id  = get_theme_mod( 'custom_logo' );
		$src = wp_get_attachment_image_url( $id, 'full' );
		if ( $src ) {
			return '<a class="ashp-logo" href="' . esc_url( home_url( '/' ) ) . '" rel="home">' .
				'<img src="' . esc_url( $src ) . '" width="' . $size . '" height="' . $size . '" alt="' . esc_attr( ASHP_SITE_NAME ) . '">' .
				'</a>';
		}
	}

	$img = get_template_directory_uri() . '/assets/img/logo.png';
	return '<a class="ashp-logo" href="' . esc_url( home_url( '/' ) ) . '" rel="home">' .
		'<img src="' . esc_url( $img ) . '" width="' . $size . '" height="' . $size . '" alt="' . esc_attr( ASHP_SITE_NAME ) . '" loading="eager" decoding="async">' .
		'</a>';
}

/* -------------------------------------------------------------------------
 * ۷) منو با فالبک
 * ---------------------------------------------------------------------- */
function ashpazbashi_menu( $location = 'primary', $class = 'ashp-menu' ) {
	if ( has_nav_menu( $location ) ) {
		wp_nav_menu( array(
			'theme_location' => $location,
			'container'      => false,
			'menu_class'     => $class,
			'depth'          => 3,
			'fallback_cb'    => false,
		) );
		return;
	}

	$items = ashpazbashi_default_menu_items();
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( $items as $it ) {
		echo '<li class="menu-item' . ( ! empty( $it['children'] ) ? ' menu-item-has-children' : '' ) . '">';
		echo '<a href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['title'] ) . '</a>';
		if ( ! empty( $it['children'] ) ) {
			echo '<ul class="sub-menu">';
			foreach ( $it['children'] as $c ) {
				echo '<li class="menu-item"><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</li>';
	}
	echo '</ul>';
}

function ashpazbashi_default_menu_items() {
	$home  = array( 'title' => __( 'خانه', 'ashpazbashi' ), 'url' => home_url( '/' ) );

	if ( class_exists( 'ASHP_DB' ) ) {
		$items = array( $home );
		foreach ( ASHP_DB::categories() as $slug => $label ) {
			$items[] = array(
				'title' => $label,
				'url'   => ASHP_DB::category_url( $slug ),
			);
		}
		$items[] = array( 'title' => __( 'درباره ما', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'about' ) );
		$items[] = array( 'title' => __( 'تماس با ما', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'contact' ) );
		$items[] = array( 'title' => __( 'قوانین و مقررات', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'terms' ) );
		$items[] = array( 'title' => __( 'حریم خصوصی', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'privacy' ) );
		return $items;
	}

	return array(
		$home,
		array( 'title' => __( 'دستورها', 'ashpazbashi' ), 'url' => home_url( '/recipes/' ) ),
		array( 'title' => __( 'مواد اولیه', 'ashpazbashi' ), 'url' => home_url( '/ingredients/' ) ),
		array( 'title' => __( 'درباره ما', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'about' ) ),
		array( 'title' => __( 'تماس با ما', 'ashpazbashi' ), 'url' => ashpazbashi_page_url( 'contact' ) ),
	);
}

/**
 * آدرس یک برگهٔ ساخته‌شدهٔ قالب، یا آدرس پیش‌فرض در صورت نبودِ برگه.
 */
function ashpazbashi_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	if ( $page instanceof WP_Post ) {
		return get_permalink( $page );
	}
	return home_url( '/' . $slug . '/' );
}

/* -------------------------------------------------------------------------
 * ۸) جست‌وجوی سراسری سایت
 * ---------------------------------------------------------------------- */
function ashpazbashi_search_form() {
	$value = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

	echo '<form class="ashp-search" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '">';
	echo '<label class="screen-reader-text" for="ashp-site-search">' . esc_html__( 'جست‌وجوی آشپزباشی', 'ashpazbashi' ) . '</label>';
	echo '<input id="ashp-site-search" class="ashp-search__input" type="search" name="s" value="' . esc_attr( $value ) . '" placeholder="جست‌وجوی غذا، دستور پخت یا ماده اولیه…">';
	echo '<button class="ashp-search__btn" type="submit" aria-label="' . esc_attr__( 'جست‌وجو', 'ashpazbashi' ) . '"><svg class="ashp-ico-search" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.6" cy="10.6" r="6.1" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.3 15.3 20.6 20.6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>';
	echo '</form>';
}

/* -------------------------------------------------------------------------
 * ۹) منوی Mega — داده‌محور از دسته‌بندی‌های واقعی
 * ---------------------------------------------------------------------- */
function ashpazbashi_mega_menu() {
	$groups = array();

	if ( class_exists( 'ASHP_DB' ) ) {
		foreach ( ASHP_DB::taxonomy() as $slug => $info ) {
			$items = array();
			foreach ( $info['subs'] as $sub_slug => $sub_label ) {
				$items[ $sub_label ] = ASHP_DB::subcategory_url( $slug, $sub_slug );
			}
			if ( empty( $items ) ) {
				$items[ $info['fa'] ] = ASHP_DB::category_url( $slug );
			}
			$items[ __( 'همهٔ این دسته', 'ashpazbashi' ) ] = ASHP_DB::category_url( $slug );
			$groups[ $info['fa'] ] = $items;
		}
	}

	if ( empty( $groups ) ) {
		$groups = array(
			__( 'غذاها', 'ashpazbashi' )    => array(
				__( 'همهٔ دستورها', 'ashpazbashi' ) => home_url( '/recipes/' ),
			),
			__( 'آشپزی با مواد موجود', 'ashpazbashi' ) => array(
				__( 'انتخاب مواد اولیه', 'ashpazbashi' ) => home_url( '/ingredients/' ),
			),
		);
	}

	echo '<div class="ashp-mega">';
	foreach ( $groups as $title => $items ) {
		echo '<div class="ashp-mega__item">';
		echo '<button type="button" class="ashp-mega__trigger" aria-expanded="false">' . esc_html( $title ) . '</button>';
		echo '<div class="ashp-mega__panel"><div class="ashp-mega__title">' . esc_html( $title ) . '</div><div class="ashp-mega__grid">';
		foreach ( $items as $label => $url ) {
			echo '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</div></div></div>';
	}
	echo '</div>';
}

/* -------------------------------------------------------------------------
 * ۱۰) برگه‌های پیش‌فرض قالب + طول چکیده
 * ---------------------------------------------------------------------- */
function ashpazbashi_document_title( $parts ) {
	$parts['title']   = ASHP_SITE_NAME;
	$parts['tagline'] = ASHP_TAGLINE;
	if ( is_singular() ) {
		$parts['title'] = get_the_title();
	}
	return $parts;
}
add_filter( 'document_title_parts', 'ashpazbashi_document_title' );

/**
 * نام و شعار سایت همیشه «آشپزباشی» نمایش داده شود، مستقل از تنظیمات وردپرس.
 */
function ashpazbashi_bloginfo( $output, $show ) {
	if ( 'name' === $show ) {
		return ASHP_SITE_NAME;
	}
	if ( 'description' === $show ) {
		return ASHP_TAGLINE;
	}
	return $output;
}
add_filter( 'bloginfo', 'ashpazbashi_bloginfo', 10, 2 );

function ashpazbashi_excerpt_length( $len ) {
	return is_admin() ? $len : 24;
}
add_filter( 'excerpt_length', 'ashpazbashi_excerpt_length', 999 );

function ashpazbashi_excerpt_more( $more ) {
	return is_admin() ? $more : '…';
}
add_filter( 'excerpt_more', 'ashpazbashi_excerpt_more' );

/**
 * ساخت برگه‌های «درباره ما»، «تماس با ما» و «خطای ۵۰۴».
 *
 * فقط یک‌بار پس از فعال‌سازی قالب (یا پس از به‌روزرسانی نسخهٔ قالب) اجرا
 * می‌شود؛ اجرای آن در هر درخواست، سه کوئری و سه نوشتن اضافه ایجاد می‌کرد.
 */
function ashpazbashi_maybe_create_pages() {
	/*
	 * بررسی اینکه همهٔ برگه‌های استاندارد وجود دارند، در فواصل زمانی
	 * محدود انجام می‌شود تا اگر برگه‌ای پاک شد، خودش بازساخته شود.
	 */
	if ( 'yes' === get_transient( 'ashp_pages_checked' ) ) {
		return;
	}
	set_transient( 'ashp_pages_checked', 'yes', 6 * HOUR_IN_SECONDS );

	$pages = array(
		'about'   => array( __( 'درباره ما', 'ashpazbashi' ), 'page-about.php' ),
		'contact' => array( __( 'تماس با ما', 'ashpazbashi' ), 'page-contact.php' ),
		'terms'   => array( __( 'قوانین و مقررات', 'ashpazbashi' ), 'page-terms.php' ),
		'privacy' => array( __( 'حریم خصوصی', 'ashpazbashi' ), 'page-privacy.php' ),
		'e504'    => array( __( 'خطای ۵۰۴ — دریافت اطلاعات', 'ashpazbashi' ), 'page-error504.php' ),
	);

	foreach ( $pages as $slug => $data ) {
		$existing = get_page_by_path( $slug );
		if ( $existing instanceof WP_Post ) {
			$current = get_post_meta( $existing->ID, '_wp_page_template', true );
			if ( $current !== $data[1] ) {
				update_post_meta( $existing->ID, '_wp_page_template', $data[1] );
			}
			if ( '' === trim( (string) $existing->post_title ) ) {
				wp_update_post( array( 'ID' => $existing->ID, 'post_title' => $data[0] ) );
			}
			continue;
		}
		wp_insert_post( array(
			'post_title'    => $data[0],
			'post_name'     => $slug,
			'post_status'   => 'publish',
			'post_type'     => 'page',
			'post_content'  => '',
			'page_template' => $data[1],
		) );
	}

	update_option( 'ashp_pages_created', ASHP_VER, false );
}
/**
 * پاک‌سازی یک‌بارهٔ برگهٔ «پنل مدیریت آشپزباشی» که در نسخهٔ ۳.۷.۰ قالب
 * ساخته می‌شد. آن پنل حذف شده و مدیریت فقط در پیشخوان وردپرس است.
 */
function ashpazbashi_remove_panel_page() {
	if ( '1' === get_option( 'ashp_panel_page_removed' ) ) {
		return;
	}
	$page = get_page_by_path( 'ashp-panel' );
	if ( $page instanceof WP_Post && 'trash' !== $page->post_status ) {
		wp_trash_post( $page->ID );
	}
	update_option( 'ashp_panel_page_removed', '1', false );
}
add_action( 'admin_init', 'ashpazbashi_remove_panel_page' );

/**
 * دستهٔ جاری اگر یکی از دسته‌های انیمیشن غذا باشد.
 *
 * در صفحهٔ هر دسته، فقط غذاهای همان دسته باید بیفتند. کلیدها همان کلیدهای
 * دسته‌های افزونه هستند (iranian، fastfood، dessert، drink، appetizer،
 * seafood، kids).
 *
 * @return string
 */
function ashpazbashi_current_food_cat() {
	if ( ! function_exists( 'is_category' ) || ! function_exists( 'is_tax' ) ) {
		return '';
	}
	$slug = '';
	if ( is_category() || is_tax() ) {
		$term = get_queried_object();
		if ( $term && ! empty( $term->slug ) ) {
			$slug = (string) $term->slug;
		}
	}
	if ( '' === $slug || ! class_exists( 'ASHP_FoodSettings' ) ) {
		return '';
	}
	$cats = array_keys( ASHP_FoodSettings::foods() );
	return in_array( $slug, $cats, true ) ? $slug : '';
}


/**
 * نرمال‌سازی متن فارسی برای مقایسه (نیم‌فاصله، ی/ک عربی، اعراب).
 *
 * @param string $s متن.
 * @return string
 */
function ashpazbashi_norm_fa( $s ) {
	$s = (string) $s;
	$s = str_replace( array( "\u{200c}", 'ي', 'ك', 'ة', 'ۀ' ), array( ' ', 'ی', 'ک', 'ه', 'ه' ), $s );
	$s = preg_replace( '/[\x{064B}-\x{0652}\x{0670}\x{0640}]/u', '', $s );
	$s = preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', $s );
	return trim( preg_replace( '/\s+/u', ' ', $s ) );
}

/**
 * استیکر مخصوص هر مادهٔ اولیه.
 *
 * برای هر ماده یک استیکر واقع‌گرایانه و مخصوص خودش برمی‌گرداند؛ مثلاً گوشت
 * چرخ‌کرده با ران مرغ یا پنیر یکی نیست. الگوی کار مثل پارسر مواد اولیه است:
 * نام نرمال‌سازی می‌شود (نیم‌فاصله، ی/ک عربی، فاصله‌های اضافه) و بعد
 * **بلندترین کلیدواژه** برنده می‌شود تا «پنیر پیتزا» با «پنیر» قاطی نشود.
 * اگر هیچ کلیدواژه‌ای جور نشد، استیکر گروه (fallback) می‌ماند.
 *
 * @param string $name     نام ماده.
 * @param string $fallback استیکر گروه.
 * @return string
 */
function ashpazbashi_ingredient_sticker( $name, $fallback = '🍽' ) {
	static $map = null;
	if ( null === $map ) {
		/*
		 * ترتیب مهم نیست؛ کد خودش بلندترین کلیدواژه را انتخاب می‌کند.
		 * کلیدها به شکل نرمال‌شده نوشته می‌شوند (بدون نیم‌فاصله).
		 */
		$map = array(
			// ── گوشت و مرغ و ماهی ──
			'گوشت چرخ کرده' => '🍖', 'گوشت چرخ‌کرده' => '🍖', 'گوشت چرخ' => '🍖',
			'گوشت گوسفند' => '🐑', 'گوشت گوساله' => '🐄', 'گوشت خورشتی' => '🍲',
			'استیک' => '🥩', 'راسته' => '🥩', 'فیله گوساله' => '🥩', 'ماهیچه' => '🥩',
			'سینه مرغ' => '🍗', 'ران مرغ' => '🍗', 'فیله مرغ' => '🍗', 'باقلا مرغ' => '🍗',
			'آب مرغ' => '🍲', 'مرغ' => '🐔', 'بوقلمون' => '🦃',
			'فیله ماهی' => '🐟', 'ماهی' => '🐟', 'میگو' => '🦐', 'تن ماهی' => '🐟',
			'ژامبون' => '🥓', 'سوسیس' => '🌭', 'کالباس' => '🥓', 'بیکن' => '🥓',
			'گوشت' => '🥩', 'بال مرغ' => '🍗', 'جگر' => '🍖', 'دل و قلوه' => '🍖',

			// ── لبنیات و تخم‌مرغ ──
			'زرده تخم مرغ' => '🟡', 'سفیده تخم مرغ' => '⚪', 'تخم مرغ' => '🥚', 'تخم‌مرغ' => '🥚',
			'تخم بلدرچین' => '🥚', 'تخم' => '🥚',
			'پنیر خامه' => '🧈', 'پنیر پیتزا' => '🧀', 'پنیر پارمزان' => '🧀', 'پنیر موزارلا' => '🧀',
			'پنیر چدار' => '🧀', 'پنیر فتا' => '🧀', 'پنیر' => '🧀',
			'خامه' => '🍶', 'سرشیر' => '🍶', 'شیر' => '🥛', 'کره' => '🧈',
			'ماست چکیده' => '🥣', 'ماست' => '🥣', 'کشک' => '🥣', 'دوغ' => '🥛',

			// ── غلات و آرد و نان و پاستا ──
			'آرد نخودچی' => '🌾', 'آرد سوخاری' => '🍞', 'پودر سوخاری' => '🍞',
			'آرد برنج' => '🌾', 'آرد ذرت' => '🌽', 'آرد گندم' => '🌾', 'آرد سفید' => '🌾',
			'آرد' => '🌾', 'ارد' => '🌾',
			'برنج ایرانی' => '🍚', 'برنج باسماتی' => '🍚', 'برنج' => '🍚',
			'نان تست' => '🍞', 'نان باگت' => '🥖', 'نان' => '🍞', 'خمیر مایه' => '🍞', 'خمیر یوفکا' => '🥐',
			'ماکارونی' => '🍝', 'پاستا' => '🍝', 'اسپاگتی' => '🍝', 'نودل' => '🍜',
			'بلغور' => '🌾', 'جو' => '🌾', 'جو پرک' => '🥣', 'کینوا' => '🌾', 'سبوس' => '🌾',
			'نشاسته' => '🥣', 'بکینگ پودر' => '🥄', 'جوش شیرین' => '🥄', 'وانیل' => '🍦',
			'ذرت' => '🌽', 'پودر ژلاتین' => '🥄',

			// ── حبوبات ──
			'نخود فرنگی' => '🫛', 'نخود' => '🫘', 'لوبیا چیتی' => '🫘', 'لوبیا قرمز' => '🫘',
			'لوبیا سبز' => '🫛', 'لوبیا' => '🫘', 'لپه' => '🫘', 'عدس' => '🫘', 'سویا' => '🫘',
			'ماش' => '🫘', 'برنج قهوه‌ای' => '🍚',

			// ── روغن‌ها و چربی‌ها ──
			'روغن زیتون' => '🫒', 'روغن سرخ کردنی' => '🍳', 'روغن مایع' => '🫗',
			'روغن جامد' => '🧈', 'روغن کنجد' => '🫗', 'روغن' => '🫗',

			// ── سبزی و صیفی ──
			'فلفل دلمه ای قرمز' => '🫑', 'فلفل دلمه ای سبز' => '🫑', 'فلفل دلمه' => '🫑',
			'فلفل سبز تند' => '🌶', 'فلفل قرمز' => '🌶', 'فلفل سیاه' => '🧂', 'فلفل' => '🌶',
			'گوجه گیلاسی' => '🍅', 'گوجه فرنگی' => '🍅', 'گوجه' => '🍅', 'رب گوجه فرنگی' => '🥫',
			'رب گوجه' => '🥫', 'رب انار' => '🥫', 'رب' => '🥫',
			'سیب زمینی' => '🥔', 'سیب‌زمینی' => '🥔', 'هویج' => '🥕', 'هویچ' => '🥕',
			'پیازچه' => '🌱', 'پیاز قرمز' => '🧅', 'پیاز متوسط' => '🧅', 'پیاز' => '🧅',
			'سیر' => '🧄', 'پودر سیر' => '🧄', 'قارچ' => '🍄', 'بادمجان' => '🍆',
			'کدو سبز' => '🥒', 'کدو' => '🎃', 'خیارشور' => '🥒', 'خیار' => '🥒',
			'اسفناج' => '🥬', 'کاهو' => '🥬', 'کلم' => '🥬', 'بروکلی' => '🥦',
			'کرفس' => '🥬', 'ساقه کرفس' => '🥬', 'جعفری' => '🌿', 'گشنیز' => '🌿',
			'شوید' => '🌿', 'ریحان' => '🌿', 'نعنا' => '🌿', 'نعناع' => '🌿', 'ترخون' => '🌿',
			'تره' => '🌿', 'شنبلیله' => '🌿', 'برگ بو' => '🍃', 'آویشن' => '🌿', 'زیره' => '🌿',
			'سبزی' => '🌿', 'ریحان خشک' => '🌿',

			// ── میوه و خشکبار ──
			'لیمو ترش' => '🍋', 'لیمو امانی' => '🍋', 'آبلیمو' => '🍋', 'آب لیمو' => '🍋', 'لیمو' => '🍋',
			'پرتقال' => '🍊', 'آب نارنج' => '🍊', 'آب پرتقال' => '🍊', 'نارنگی' => '🍊',
			'سیب' => '🍎', 'موز' => '🍌', 'انگور' => '🍇', 'کشمش' => '🍇', 'زرشک' => '🍒',
			'آلبالو' => '🍒', 'گیلاس' => '🍒', 'توت فرنگی' => '🍓', 'هندوانه' => '🍉',
			'خربزه' => '🍈', 'طالبی' => '🍈', 'آناناس' => '🍍', 'هلو' => '🍑', 'زردآلو' => '🍑',
			'آلو' => '🍑', 'انار' => '🍎', 'به' => '🍐', 'گلابی' => '🍐', 'کیوی' => '🥝',
			'توت' => '🫐', 'بلوبری' => '🫐', 'تمشک' => '🫐', 'خرما' => '🌴', 'انجیر' => '🫐',
			'گردو' => '🌰', 'بادام' => '🌰', 'پسته' => '🌰', 'فندق' => '🌰', 'بادام زمینی' => '🥜',
			'کنجد' => '🌾', 'تخمه' => '🌰', 'نارگیل' => '🥥',

			// ── ادویه و افزودنی ──
			'زعفران دمکرده' => '🌺', 'زعفران' => '🌺', 'گلاب' => '🌹',
			'زردچوبه' => '🟡', 'دارچین' => '🪵', 'پودر دارچین' => '🪵', 'چوب دارچین' => '🪵',
			'جوز هندی' => '🌰', 'پودر هل' => '🌿', 'هل' => '🌿', 'ادویه کاری' => '🍛',
			'پودر کاری' => '🍛', 'ادویه' => '🧂', 'پاپریکا' => '🌶', 'پودر پاپریکا' => '🌶',
			'نمک و فلفل و زردچوبه' => '🧂', 'نمک و فلفل' => '🧂', 'نمک فلفل' => '🧂',
			'نمک و زردچوبه' => '🧂', 'نمک' => '🧂', 'شکر' => '🍬', 'قند' => '🍬',
			'عسل' => '🍯', 'شکلات' => '🍫', 'کاکائو' => '🍫', 'پودر کاکائو' => '🍫',
			'شیرین کننده' => '🍬', 'ژلاتین' => '🥄',

			// ── مایعات و سس‌ها ──
			'آب جوش' => '♨', 'آب گرم' => '♨', 'آب سرد' => '💧', 'آب گوشت' => '🍲',
			'آب' => '💧', 'اب' => '💧',
			'سرکه سیب' => '🧴', 'سرکه' => '🧴', 'آبغوره' => '🧴', 'آب نارنج' => '🍊',
			'سس سویا' => '🍶', 'سس مایونز' => '🥣', 'سس کچاپ' => '🍅', 'سس گوجه' => '🍅',
			'سس خردل' => '🌭', 'سس' => '🥣', 'خردل' => '🌭',
			'چای' => '🍵', 'قهوه' => '☕', 'نسکافه' => '☕', 'نوشابه' => '🥤', 'شربت' => '🥤',

			// ── شیرینی و پخت ──
			'شکلات تخته' => '🍫', 'پودر قند' => '🍬', 'خامه صبحانه' => '🍶',
			'کیک' => '🍰', 'بیسکویت' => '🍪', 'کلوچه' => '🍪', 'ویفر' => '🍫',
			'بستنی' => '🍦', 'پودر کاسترد' => '🍮', 'کارامل' => '🍮',
			'پودر نارگیل' => '🥥', 'خلال پسته' => '🌰', 'خلال بادام' => '🌰',
			'گوشت کوساله' => '🐄', 'مغز' => '🧠', 'استخوان' => '🦴',

			// ── چند مورد باقی‌مانده ──
			'زنجبیل' => '🫚', 'پودر زنجبیل' => '🫚', 'سماق' => '🌿', 'سیاه دانه' => '🌰',
			'رازیانه' => '🌿', 'گلپر' => '🌿', 'جوانه' => '🌱', 'سبزی خوردن' => '🌿',
			'سبزی خشک' => '🌿', 'پودر نارگیل' => '🥥', 'آب انار' => '🥤', 'شربت' => '🥤',
			'دمکرده' => '🍵', 'چای سبز' => '🍵', 'خیار شور' => '🥒', 'کلم بروکلی' => '🥦',
			'فیله ماهی قزل' => '🐟', 'میگو پاک کرده' => '🦐', 'تخم مرغ آبپز' => '🥚',
		);
	}

	$key = ashpazbashi_norm_fa( (string) $name );
	if ( '' === $key ) {
		return $fallback;
	}

	$best  = '';
	$emoji = '';
	foreach ( $map as $needle => $ico ) {
		$needle = ashpazbashi_norm_fa( $needle );
		if ( '' === $needle || false === strpos( $key, $needle ) ) {
			continue;
		}
		/* بلندترین کلیدواژه برنده است */
		if ( strlen( $needle ) > strlen( $best ) ) {
			$best  = $needle;
			$emoji = $ico;
		}
	}

	return $emoji ? $emoji : $fallback;
}


add_action( 'after_switch_theme', 'ashpazbashi_maybe_create_pages' );
add_action( 'init', 'ashpazbashi_maybe_create_pages', 20 );
/* پس از به‌روزرسانی درجا (بدون فعال‌سازی مجدد) هم یک‌بار بررسی می‌شود.
   این هوک فقط در پیشخوان اجرا می‌شود، پس هزینه‌ای برای بازدیدکننده ندارد. */
add_action( 'admin_init', 'ashpazbashi_maybe_create_pages' );

/* -------------------------------------------------------------------------
 * ۱۱) کلاس بدنه
 * ---------------------------------------------------------------------- */
function ashpazbashi_body_class( $classes ) {
	$classes[] = 'ashp-dark';
	$classes[] = 'ashp-rtl';

	/*
	 * انیمیشن سه‌بعدی غذا: در همهٔ صفحه‌ها ۲ سانتی‌متر پایین‌تر می‌نشیند،
	 * فقط در «صفحهٔ اصلی» سایت دست نمی‌خورد.
	 */
	$ashp_is_front = ( function_exists( 'is_front_page' ) && is_front_page() )
		|| ( function_exists( 'is_home' ) && is_home() );
	if ( $ashp_is_front ) {
		$classes[] = 'ashp-is-front';
	}
	if ( ashpazbashi_current_name() ) {
		$classes[] = 'ashp-has-name';
	}
	return $classes;
}
add_filter( 'body_class', 'ashpazbashi_body_class' );

/* -------------------------------------------------------------------------
 * ۱۲) هدر/فوتر نئونی — رنگ‌ها و اطلاعات تماس با Customizer
 * ---------------------------------------------------------------------- */
function ashpazbashi_customize( $wp_customize ) {
	$wp_customize->add_section( 'ashp_colors', array(
		'title'    => __( 'رنگ‌های نئونی آشپزباشی', 'ashpazbashi' ),
		'priority' => 30,
	) );
	$fields = array(
		'ashp_neon_1' => array( __( 'نئون اصلی', 'ashpazbashi' ), '#00f5d4' ),
		'ashp_neon_2' => array( __( 'نئون دوم', 'ashpazbashi' ), '#ff2e97' ),
		'ashp_neon_3' => array( __( 'نئون سوم', 'ashpazbashi' ), '#7b2ff7' ),
	);
	foreach ( $fields as $id => $f ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $f[1],
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
			'label'   => $f[0],
			'section' => 'ashp_colors',
		) ) );
	}

	$wp_customize->add_setting( 'ashp_footer_note', array(
		'default'           => '',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'ashp_footer_note', array(
		'label'   => __( 'متن معرفی در فوتر', 'ashpazbashi' ),
		'section' => 'ashp_colors',
		'type'    => 'textarea',
	) );

	/* --- اطلاعات تماس (قبلاً در کد هاردکد شده بود) --- */
	$wp_customize->add_section( 'ashp_contact', array(
		'title'    => __( 'اطلاعات تماس آشپزباشی', 'ashpazbashi' ),
		'priority' => 31,
	) );

	$contact = array(
		'ashp_phone'   => array( __( 'شمارهٔ تماس', 'ashpazbashi' ), '09372566131', 'text' ),
		'ashp_email'   => array( __( 'ایمیل', 'ashpazbashi' ), 'ashpazbashie@gmail.com', 'text' ),
		'ashp_address' => array( __( 'نشانی', 'ashpazbashi' ), '', 'textarea' ),
	);
	foreach ( $contact as $id => $c ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $c[1],
			'sanitize_callback' => 'text' === $c[2] ? 'sanitize_text_field' : 'wp_kses_post',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $c[0],
			'section' => 'ashp_contact',
			'type'    => $c[2],
		) );
	}
}
add_action( 'customize_register', 'ashpazbashi_customize' );

/**
 * مقادیر پیش‌فرض اطلاعات تماس (اگر Customizer خالی باشد).
 */
/**
 * اگر ایمیل قدیمی در سازگارساز قالب ذخیره شده باشد، یک‌بار به ایمیل تازه
 * تغییر داده می‌شود تا مقدار کهنه روی مقدار پیش‌فرض سایه نیندازد.
 */
function ashpazbashi_maybe_migrate_email() {
	if ( get_option( 'ashp_email_migrated' ) ) {
		return;
	}
	$stored = get_theme_mod( 'ashp_email', '' );
	if ( '' === $stored || 'ashpazbashie@gmail.com' === $stored ) {
		set_theme_mod( 'ashp_email', 'info@ashpazbashie.ir' );
	}
	update_option( 'ashp_email_migrated', 1 );
}
add_action( 'init', 'ashpazbashi_maybe_migrate_email' );

function ashpazbashi_contact( $key ) {
	$defaults = array(
		'phone'   => '09372566131',
		'email'   => 'info@ashpazbashie.ir',
		'address' => '',
	);
	$map      = array(
		'phone'   => 'ashp_phone',
		'email'   => 'ashp_email',
		'address' => 'ashp_address',
	);
	$value = get_theme_mod( $map[ $key ], $defaults[ $key ] );
	return ( '' === $value ) ? $defaults[ $key ] : $value;
}

/** شمارهٔ تلفن به شکل قابل استفاده در href="tel:" */
function ashpazbashi_tel_href() {
	return 'tel:' . preg_replace( '/[^0-9+]/', '', ashpazbashi_contact( 'phone' ) );
}

function ashpazbashi_neon_css() {
	$c1 = get_theme_mod( 'ashp_neon_1', '#00f5d4' );
	$c2 = get_theme_mod( 'ashp_neon_2', '#ff2e97' );
	$c3 = get_theme_mod( 'ashp_neon_3', '#7b2ff7' );
	printf(
		'<style id="ashp-neon-vars">:root{--neon-1:%1$s;--neon-2:%2$s;--neon-3:%3$s;}</style>',
		esc_html( sanitize_hex_color( $c1 ) ),
		esc_html( sanitize_hex_color( $c2 ) ),
		esc_html( sanitize_hex_color( $c3 ) )
	);
}
add_action( 'wp_head', 'ashpazbashi_neon_css', 5 );

/* -------------------------------------------------------------------------
 * ۱۳) آیکون‌ها و متای سرصفحه
 * ---------------------------------------------------------------------- */
function ashpazbashi_head_meta() {
	$uri = get_template_directory_uri();

	if ( ! has_site_icon() ) {
		printf(
			'<link rel="icon" href="%s" sizes="any">' . "\n",
			esc_url( $uri . '/assets/img/favicon.png' )
		);
		printf(
			'<link rel="apple-touch-icon" href="%s">' . "\n",
			esc_url( $uri . '/assets/img/logo-180.png' )
		);
	}
	printf( '<link rel="preload" as="image" href="%s">' . "\n", esc_url( $uri . '/assets/img/logo.png' ) );

	/*
	 * متا‌تگ‌های توضیحات، شبکه‌های اجتماعی و canonical به inc/seo.php منتقل شدند
	 * تا فقط یک بار و بدون تکرار تولید شوند.
	 */
}
add_action( 'wp_head', 'ashpazbashi_head_meta', 6 );

function ashpazbashi_meta_description() {
	if ( is_front_page() || is_home() ) {
		return ASHP_TAGLINE;
	}

	if ( class_exists( 'ASHP_Router' ) && ASHP_Router::is_recipe_page() ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			$bits = array( $r['name'] );
			$sub  = ASHP_DB::subcategory_label( $r['category'], $r['subcategory'] );
			if ( '' !== $sub ) {
				$bits[] = $sub;
			}
			$t = ASHP_Front::time_label( ASHP_Front::total_time( $r ) );
			if ( '' !== $t ) {
				$bits[] = $t;
			}
			if ( ! empty( $r['servings'] ) ) {
				$bits[] = ASHP_Front::servings_label( $r['servings'] );
			}
			return implode( ' — ', $bits );
		}
	}

	if ( class_exists( 'ASHP_Router' ) && ( ASHP_Router::is_list_page() || ASHP_Router::is_picker_page() ) ) {
		$ctx = ASHP_DB::current_list_context();
		$out = $ctx['title'];
		if ( ! empty( $ctx['desc'] ) ) {
			$out .= ' — ' . $ctx['desc'];
		}
		return $out;
	}

	if ( is_singular() ) {
		$excerpt = get_the_excerpt();
		if ( $excerpt ) {
			return wp_strip_all_tags( $excerpt );
		}
		return wp_trim_words( wp_strip_all_tags( get_the_content() ), 30, '…' );
	}
	return '';
}

/* -------------------------------------------------------------------------
 * ۱۴) داده‌های ساختاریافتهٔ Recipe (Schema.org)
 * ---------------------------------------------------------------------- */
function ashpazbashi_recipe_schema() {
	if ( ! class_exists( 'ASHP_DB' ) || ! class_exists( 'ASHP_Front' ) ) {
		return;
	}

	$recipe = null;

	if ( class_exists( 'ASHP_Router' ) && ASHP_Router::is_recipe_page() ) {
		$recipe = ASHP_DB::current_recipe();
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$recipe = ASHP_DB::get_by_slug( $post->post_name );
		}
	}

	if ( ! $recipe ) {
		return;
	}

	$data = function_exists( 'ashpseo_schema_data' )
		? ashpseo_schema_data( $recipe )
		: ASHP_Front::schema_data( $recipe );
	if ( empty( $data ) ) {
		return;
	}

	echo '<script type="application/ld+json">' .
		wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) .
		'</script>' . "\n";
}
add_action( 'wp_head', 'ashpazbashi_recipe_schema', 7 );

/* -------------------------------------------------------------------------
 * ۱۵) فرم تماس واقعی (به‌جای استفاده از بخش نظرات وردپرس)
 * ---------------------------------------------------------------------- */

/**
 * نمایش فرم تماس.
 */
function ashpazbashi_contact_form() {
	$sent  = isset( $_GET['ashp_sent'] ) ? sanitize_key( wp_unslash( $_GET['ashp_sent'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$error = isset( $_GET['ashp_error'] ) ? sanitize_key( wp_unslash( $_GET['ashp_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

	if ( 'ok' === $sent ) {
		echo '<div class="ashp-note ashp-note--ok"><strong>' . esc_html__( 'پیام شما ارسال شد.', 'ashpazbashi' ) . '</strong> ' .
			esc_html__( 'ممنون که با ما تماس گرفتید؛ در اولین فرصت پاسخ می‌دهیم.', 'ashpazbashi' ) . '</div>';
	}

	$messages = array(
		'fields'  => __( 'نام، ایمیل و متن پیام را کامل وارد کنید.', 'ashpazbashi' ),
		'email'   => __( 'ایمیل وارد‌شده معتبر نیست.', 'ashpazbashi' ),
		'mail'    => __( 'ارسال پیام ناموفق بود. لطفاً بعداً تلاش کنید یا از ایمیل مستقیم استفاده کنید.', 'ashpazbashi' ),
		'flood'   => __( 'پیش از ارسال پیام بعدی کمی صبر کنید.', 'ashpazbashi' ),
		'generic' => __( 'خطایی رخ داد. لطفاً دوباره تلاش کنید.', 'ashpazbashi' ),
	);
	if ( $error && isset( $messages[ $error ] ) ) {
		echo '<div class="ashp-note"><strong>' . esc_html__( 'ارسال نشد:', 'ashpazbashi' ) . '</strong> ' . esc_html( $messages[ $error ] ) . '</div>';
	}
	?>
	<form class="ashp-cform" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="ashp_contact">
		<?php wp_nonce_field( 'ashp_contact', 'ashp_contact_nonce' ); ?>

		<p class="ashp-cform__row">
			<label for="ashp-c-name"><?php esc_html_e( 'نام شما', 'ashpazbashi' ); ?></label>
			<input id="ashp-c-name" type="text" name="ashp_name" maxlength="80" required>
		</p>
		<p class="ashp-cform__row">
			<label for="ashp-c-email"><?php esc_html_e( 'ایمیل شما', 'ashpazbashi' ); ?></label>
			<input id="ashp-c-email" type="email" name="ashp_email" maxlength="120" dir="ltr" required>
		</p>
		<p class="ashp-cform__row">
			<label for="ashp-c-msg"><?php esc_html_e( 'پیام شما', 'ashpazbashi' ); ?></label>
			<textarea id="ashp-c-msg" name="ashp_message" rows="6" maxlength="3000" required></textarea>
		</p>

		<?php /* تلهٔ ربات — کاربر واقعی این فیلد را نمی‌بیند */ ?>
		<p class="ashp-cform__hp" aria-hidden="true">
			<label for="ashp-c-web"><?php esc_html_e( 'وب‌سایت', 'ashpazbashi' ); ?></label>
			<input id="ashp-c-web" type="text" name="ashp_website" tabindex="-1" autocomplete="off">
		</p>

		<p><button class="ashp-btn ashp-btn--primary" type="submit"><?php esc_html_e( 'ارسال پیام', 'ashpazbashi' ); ?></button></p>
	</form>
	<?php
}

/**
 * پردازش ارسال فرم تماس.
 */
function ashpazbashi_contact_handler() {
	$back = wp_get_referer();
	$back = $back ? $back : home_url( '/' );
	$back = remove_query_arg( array( 'ashp_sent', 'ashp_error' ), $back );

	$fail = function ( $code ) use ( $back ) {
		wp_safe_redirect( add_query_arg( 'ashp_error', $code, $back ) . '#ashp-contact-form' );
		exit;
	};

	if ( ! isset( $_POST['ashp_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['ashp_contact_nonce'] ) ), 'ashp_contact' ) ) {
		$fail( 'generic' );
	}

	/* تلهٔ ربات */
	if ( ! empty( $_POST['ashp_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'ashp_sent', 'ok', $back ) );
		exit;
	}

	/* محدودیت نرخ: حداکثر یک پیام در هر ۶۰ ثانیه از هر بازدیدکننده */
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$key = 'ashp_cf_' . md5( $ip . '|' . get_site_url() );
	if ( get_transient( $key ) ) {
		$fail( 'flood' );
	}

	$name    = isset( $_POST['ashp_name'] ) ? sanitize_text_field( wp_unslash( $_POST['ashp_name'] ) ) : '';
	$email   = isset( $_POST['ashp_email'] ) ? sanitize_email( wp_unslash( $_POST['ashp_email'] ) ) : '';
	$message = isset( $_POST['ashp_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ashp_message'] ) ) : '';

	if ( '' === $name || '' === $message || '' === $email ) {
		$fail( 'fields' );
	}
	if ( ! is_email( $email ) ) {
		$fail( 'email' );
	}

	$to = ashpazbashi_contact( 'email' );
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}

	$subject = sprintf(
		/* translators: %s: sender name */
		__( '[آشپزباشی] پیام تازه از %s', 'ashpazbashi' ),
		$name
	);

	$body = sprintf(
		"%s\n\n%s: %s\n%s: %s\n\n%s:\n%s",
		__( 'پیام تازه از فرم تماس آشپزباشی:', 'ashpazbashi' ),
		__( 'نام', 'ashpazbashi' ),
		$name,
		__( 'ایمیل', 'ashpazbashi' ),
		$email,
		__( 'متن پیام', 'ashpazbashi' ),
		$message
	);

	$headers = array(
		sprintf( 'Reply-To: %s <%s>', $name, $email ),
	);

	$sent = wp_mail( $to, $subject, $body, $headers );

	set_transient( $key, 1, MINUTE_IN_SECONDS );

	if ( ! $sent ) {
		$fail( 'mail' );
	}

	wp_safe_redirect( add_query_arg( 'ashp_sent', 'ok', $back ) . '#ashp-contact-form' );
	exit;
}
add_action( 'admin_post_ashp_contact', 'ashpazbashi_contact_handler' );
add_action( 'admin_post_nopriv_ashp_contact', 'ashpazbashi_contact_handler' );


/* -------------------------------------------------------------------------
 * ناوبری تازه: بخش‌ها و نوار پایین موبایل
 * ---------------------------------------------------------------------- */

/** فهرست بخش‌های اصلی سایت */
function ashpazbashi_hub_items() {
	$items = array(
		array( 'food',        '🍲', __( 'غذاها و مواد اولیه', 'ashpazbashi' ), '/food/',   false ),
		array( 'sweets',      '🍰', __( 'نوشیدنی‌ها و دسرها', 'ashpazbashi' ), '/sweets/', false ),
		array( 'recipes',     '📖', __( 'همهٔ دستورها', 'ashpazbashi' ),        '/recipes/', false ),
		array( 'party',       '🎉', __( 'فود پارتی', 'ashpazbashi' ),           '/party/',  false ),
		array( 'kids',        '🧸', __( 'غذای کودکان', 'ashpazbashi' ),         '/kids/',   false ),
		array( 'ingredients', '🧺', __( 'آشپزی با مواد موجود', 'ashpazbashi' ), '/ingredients/', true ),
	);
	$out = array();
	foreach ( $items as $it ) {
		$out[] = array(
			'key'    => $it[0],
			'emoji'  => $it[1],
			'label'  => $it[2],
			'url'    => home_url( $it[3] ),
			'accent' => $it[4],
		);
	}
	return $out;
}

/** نوار پایین موبایل — پنج دسترسی پرکاربرد */
function ashpazbashi_bottom_items() {
	$path  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$items = array(
		array( 'home',    '🏠', __( 'خانه', 'ashpazbashi' ),          '/' ),
		array( 'food',    '🍲', __( 'غذاها', 'ashpazbashi' ),         '/food/' ),
		array( 'recipes', '📖', __( 'دستورها', 'ashpazbashi' ),       '/recipes/' ),
		array( 'party',   '🎉', __( 'فود پارتی', 'ashpazbashi' ),     '/party/' ),
		array( 'kids',    '🧸', __( 'کودکان', 'ashpazbashi' ),        '/kids/' ),
	);
	$out = array();
	foreach ( $items as $it ) {
		$slug  = ltrim( $it[3], '/' );
		$on    = ( '/' === $it[3] )
			? ( '' === trim( $path, '/' ) || '/' === $path )
			: ( '' !== $slug && false !== strpos( $path, '/' . $slug ) );
		$out[] = array(
			'emoji' => $it[1],
			'label' => $it[2],
			'url'   => home_url( $it[3] ),
			'on'    => $on,
		);
	}
	return $out;
}

/** متن پیش‌فرض صفحه‌های ثابت (از پنل قابل ویرایش است) */
function ashpazbashi_default_page( $key ) {
	$pages = array(
		'about'   => '<h2>آشپزباشی کیست؟</h2>
<p>آشپزباشی یک دستیار آشپزی فارسی است که کارش را ساده کرده: شما می‌گویید چه موادی در خانه دارید، او بهترین غذاها را با مواد اولیه، مقدار دقیق و مراحل پخت قدم‌به‌قدم پیشنهاد می‌دهد.</p>
<h3>چه کاری می‌کند؟</h3>
<ul>
<li>از میان چند هزار دستور ایرانی، محلی و بین‌المللی، آن‌هایی را پیدا می‌کند که با مواد شما هم‌خوانی دارند.</li>
<li>درصد تطابق هر دستور را نشان می‌دهد تا بدانید چقدر به مواد موجودتان نزدیک است.</li>
<li>برای هر دستور، مواد اولیه با مقدار و مراحل پخت فارسی و ویراستاری‌شده دارد.</li>
<li>بخش‌های آماده‌ای دارد: فود پارتی برای مهمانی، غذای کودکان برای ۳ تا ۸ سال، و نوشیدنی و دسر.</li>
</ul>
<h3>با چه هدفی ساخته شد؟</h3>
<p>هدف ما این است که هیچ‌وقت پشت یخچال نمانید و دنبال «امروز چی بپزم؟» نگردید. آشپزباشی به شما می‌گوید با همین مواد، بهترین گزینه چیست.</p>
<h3>چند نکته</h3>
<p>هیچ ثبت‌نام و رمز عبوری لازم نیست؛ فقط اسمتان را می‌نویسیم تا سایت شما را به نام خودتان صدا بزند. اطلاعات شما جای دیگری نمی‌رود.</p>',
		'contact' => '<h2>با ما حرف بزنید</h2>
<p>اگر پیشنهادی دارید، دستوری پیدا نکردید، یا جایی از سایت درست کار نکرد، خوشحال می‌شویم بشنویم. پیام شما مستقیم به تیم آشپزباشی می‌رسد.</p>
<h3>چه چیزهایی را بگویید؟</h3>
<ul>
<li>دستوری که می‌خواهید اضافه شود</li>
<li>غلط املایی یا اشتباه در مواد اولیه و مقدارها</li>
<li>مشکل فنی در نمایش یا جست‌وجوی سایت</li>
<li>پیشنهاد برای بهتر شدن بخش‌ها</li>
</ul>
<p>معمولاً در اولین فرصت پاسخ می‌دهیم. اگر موضوع فوری است، از راه‌های ارتباطی پایین صفحه استفاده کنید.</p>',
		'terms'   => '<h2>قوانین و مقررات</h2>
<p>استفاده از آشپزباشی به معنای پذیرفتن این قوانین است. لطفاً یک‌بار با حوصله بخوانید.</p>
<h3>۱. استفاده از محتوا</h3>
<p>همهٔ دستورها، متون و طراحی این سایت برای استفادهٔ شخصی و آشپزی خانگی شماست. استفادهٔ تجاری از محتوا بدون اجازهٔ کتبی ما مجاز نیست.</p>
<h3>۲. دقت دستورها</h3>
<p>مواد اولیه، مقدارها و مراحل پخت با دقت آماده شده‌اند، اما سلیقه و تجهیزات آشپزخانه‌ها متفاوت است. مسئولیت نتیجهٔ نهایی پخت با شماست. اگر حساسیت غذایی دارید، همیشه مواد را خودتان بازبینی کنید.</p>
<h3>۳. سلامت و ایمنی</h3>
<p>آشپزباشی یک راهنمای آشپزی است و جایگزین نظر پزشک یا متخصص تغذیه نیست. دربارهٔ رژیم‌های خاص یا حساسیت‌ها با متخصص مشورت کنید.</p>
<h3>۴. حساب کاربری</h3>
<p>سایت بدون ثبت‌نام کار می‌کند. نامی که وارد می‌کنید فقط در مرورگر خودتان ذخیره می‌شود.</p>
<h3>۵. تغییر قوانین</h3>
<p>ممکن است این قوانین به‌مرور به‌روزرسانی شوند. نسخهٔ معتبر همیشه همین صفحه است.</p>',
		'privacy' => '<h2>حریم خصوصی</h2>
<p>در آشپزباشی، ساده‌ترین حالت ممکن را برای حفظ حریم خصوصی شما انتخاب کرده‌ایم.</p>
<h3>چه اطلاعاتی جمع می‌کنیم؟</h3>
<ul>
<li><strong>هیچ حساب کاربری و رمز عبوری نداریم.</strong> ثبت‌نام وجود ندارد.</li>
<li>نامی که در کادر خوش‌آمدگویی می‌نویسید، فقط در <em>مرورگر خودتان</em> ذخیره می‌شود تا دفعهٔ بعد سایت شما را با همان نام صدا بزند. این نام برای ما ارسال نمی‌شود و در سرور ذخیره نمی‌گردد.</li>
<li>اگر فرم تماس را پر کنید، فقط همان نام، ایمیل و متن پیام دریافت می‌شود و صرفاً برای پاسخ دادن به شما استفاده می‌شود.</li>
</ul>
<h3>کوکی‌ها</h3>
<p>در صورت استفاده از کوکی، تنها برای نگه‌داشتن نام شما و بهبود نمایش سایت است، نه ردیابی یا تبلیغات.</p>
<h3>اشتراک‌گذاری با دیگران</h3>
<p>اطلاعات شما را با هیچ شخص یا شرکت دیگری به اشتراک نمی‌گذاریم و نمی‌فروشیم.</p>
<h3>حق حذف</h3>
<p>هر زمان بخواهید می‌توانید نام ذخیره‌شده در مرورگرتان را پاک کنید؛ کافی است داده‌های سایت را از تنظیمات مرورگر حذف کنید.</p>',
	);
	return isset( $pages[ $key ] ) ? $pages[ $key ] : '';
}

/* -------------------------------------------------------------------------
 * نوار مدیریت وردپرس در نمای سایت نمایش داده نمی‌شود تا هدر بدون هیچ فاصله‌ای
 * به لبهٔ بالای صفحه بچسبد. (خودِ پیشخوان وردپرس دست‌نخورده است)
 * ---------------------------------------------------------------------- */
function ashpazbashi_hide_admin_bar() {
	return false;
}
add_filter( 'show_admin_bar', 'ashpazbashi_hide_admin_bar' );

/* -------------------------------------------------------------------------
 * ۱۱) تضمین باز شدن برگه‌های استاندارد (تماس با ما، درباره ما و…)
 *
 * اگر برگهٔ متناظر در وردپرس وجود نداشته باشد یا قالبش عوض شده باشد،
 * آدرس به‌جای ۴۰۴ با همان قالبِ خودش نمایش داده می‌شود؛ پس صفحهٔ
 * «تماس با ما» هرگز خالی و بدون هدر/فوتر نمی‌ماند.
 * ---------------------------------------------------------------------- */
function ashpazbashi_page_fallback() {
	if ( ! is_404() ) {
		return;
	}
	$map = array(
		'about'           => 'page-about.php',
		'contact'         => 'page-contact.php',
		'contact-us'      => 'page-contact.php',
		'tamas-ba-ma'     => 'page-contact.php',
		'terms'           => 'page-terms.php',
		'privacy'         => 'page-privacy.php',
		'e504'            => 'page-error504.php',
	);

	$path = trim( (string) wp_parse_url( add_query_arg( array() ), PHP_URL_PATH ), '/' );
	$slug = strtolower( basename( $path ) );
	if ( '' === $slug || ! isset( $map[ $slug ] ) ) {
		return;
	}

	$file = get_template_directory() . '/' . $map[ $slug ];
	if ( ! file_exists( $file ) ) {
		return;
	}

	status_header( 200 );
	nocache_headers();
	$GLOBALS['ashp_page_fallback_slug'] = $slug;
	include $file;
	exit;
}
add_action( 'template_redirect', 'ashpazbashi_page_fallback', 5 );

/* -------------------------------------------------------------------------
 * ۱۲) بهینه‌سازی بارگذاری
 * ---------------------------------------------------------------------- */

/** اسکریپت‌های قالب با defer بارگذاری می‌شوند تا رندر صفحه بلاک نشود. */
function ashpazbashi_defer_scripts( $tag, $handle ) {
	if ( in_array( $handle, array( 'ashp-cursor', 'ashp-main-js' ), true ) && false === strpos( $tag, ' defer' ) ) {
		$tag = str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'ashpazbashi_defer_scripts', 10, 2 );

/** تصاویر قالب با بارگذاری تنبل و رمزگشایی غیرهمزمان. */
function ashpazbashi_lazy_images( $content ) {
	if ( is_admin() || is_feed() || '' === trim( (string) $content ) ) {
		return $content;
	}
	if ( false === strpos( $content, '<img' ) ) {
		return $content;
	}
	if ( false === strpos( $content, 'loading=' ) ) {
		$content = str_replace( '<img ', '<img loading="lazy" decoding="async" ', $content );
	}
	return $content;
}
add_filter( 'the_content', 'ashpazbashi_lazy_images', 20 );
add_filter( 'wp_get_attachment_image_attributes', function ( $attr ) {
	if ( empty( $attr['loading'] ) ) {
		$attr['loading'] = 'lazy';
	}
	if ( empty( $attr['decoding'] ) ) {
		$attr['decoding'] = 'async';
	}
	return $attr;
} );
