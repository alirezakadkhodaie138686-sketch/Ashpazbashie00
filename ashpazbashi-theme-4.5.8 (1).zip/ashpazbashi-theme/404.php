<?php
/**
 * صفحهٔ ۴۰۴
 *
 * @package Ashpazbashi
 */

get_header();
?>
<div class="ashp-wrap">
	<div class="ashp-empty ashp-empty--big">
		<span class="ashp-empty__code" aria-hidden="true">۴۰۴</span>
		<h1 class="ashp-page__title"><?php esc_html_e( 'این صفحه پیدا نشد!', 'ashpazbashi' ); ?></h1>
		<p><?php esc_html_e( 'شاید دستور پخت جابه‌جا شده باشد. از کادر جست‌وجو، دسته‌بندی‌ها یا صفحهٔ مواد اولیه استفاده کن.', 'ashpazbashi' ); ?></p>

		<div class="ashp-hero__actions">
			<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'صفحهٔ اصلی', 'ashpazbashi' ); ?></a>
			<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'آشپزی با مواد موجود', 'ashpazbashi' ); ?></a>
		</div>
	</div>

	<?php if ( class_exists( 'ASHP_DB' ) ) : ?>
		<section class="ashp-section">
			<header class="ashp-section__head">
				<h2 class="ashp-section__title"><?php esc_html_e( 'از این دسته‌ها شروع کن', 'ashpazbashi' ); ?></h2>
			</header>
			<div class="ashp-cats">
				<?php foreach ( ASHP_DB::cats_full() as $ashp_slug => $ashp_info ) : ?>
					<a class="ashp-catcard" href="<?php echo esc_url( ASHP_DB::category_url( $ashp_slug ) ); ?>">
						<span class="ashp-catcard__emoji" aria-hidden="true"><?php echo esc_html( $ashp_info['emoji'] ); ?></span>
						<span class="ashp-catcard__fa"><?php echo esc_html( $ashp_info['fa'] ); ?></span>
						<span class="ashp-catcard__count"><?php echo esc_html( number_format_i18n( ASHP_DB::category_count( $ashp_slug ) ) ); ?> <?php esc_html_e( 'غذا', 'ashpazbashi' ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
