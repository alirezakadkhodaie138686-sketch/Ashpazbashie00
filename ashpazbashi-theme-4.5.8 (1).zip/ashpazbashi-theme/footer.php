<?php
/**
 * فوتر سایت
 *
 * @package Ashpazbashi
 */
?>
</main>

<footer class="ashp-footer">
	<div class="ashp-footer__inner">

		<div class="ashp-footer__brand">
			<div class="ashp-footer__logorow">
				<?php echo ashpazbashi_logo( 58 ); // phpcs:ignore WordPress.Security.EscapeOutput -- خروجی تابع خودش escape شده است ?>
				<div>
					<strong class="ashp-footer__name"><?php echo esc_html( ASHP_SITE_NAME ); ?></strong>
					<span class="ashp-footer__tag"><?php esc_html_e( 'دستیار آشپزی تو', 'ashpazbashi' ); ?></span>
				</div>
			</div>
			<p class="ashp-footer__user">
				<span class="ashp-user__name" data-ashp-uname><?php echo esc_html( ashpazbashi_current_name() ? ashpazbashi_current_name() : __( 'مهمان', 'ashpazbashi' ) ); ?></span>
				<span><?php esc_html_e( 'جون خوش اومدی', 'ashpazbashi' ); ?></span>
				<?php echo ashpazbashi_blush_sticker( 22 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت ?>
			</p>

			<p class="ashp-footer__note">
				<?php
				$ashp_note = get_theme_mod( 'ashp_footer_note', '' );
				if ( '' !== trim( (string) $ashp_note ) ) {
					echo wp_kses_post( $ashp_note );
				} else {
					esc_html_e( 'آشپزباشی دستیار آشپزی توست؛ مواد موجود در خانه را بگو تا بهترین غذاها را با مواد اولیه و مراحل پخت پیشنهاد بدهد.', 'ashpazbashi' );
				}
				?>
			</p>
		</div>

		<div class="ashp-footer__col">
			<h4 class="ashp-footer__title"><?php echo esc_html( ASHP_SITE_NAME ); ?></h4>
			<?php
			if ( has_nav_menu( 'footer_links' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'footer_links',
					'container'      => false,
					'menu_class'     => 'ashp-footer__list',
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
			} else {
				?>
				<ul class="ashp-footer__list">
					<li><a href="<?php echo esc_url( ashpazbashi_page_url( 'about' ) ); ?>"><?php esc_html_e( 'درباره ما', 'ashpazbashi' ); ?></a></li>
					<li><a href="<?php echo esc_url( ashpazbashi_page_url( 'contact' ) ); ?>"><?php esc_html_e( 'تماس با ما', 'ashpazbashi' ); ?></a></li>
					<li><a href="<?php echo esc_url( ashpazbashi_page_url( 'terms' ) ); ?>"><?php esc_html_e( 'قوانین و مقررات', 'ashpazbashi' ); ?></a></li>
					<li><a href="<?php echo esc_url( ashpazbashi_page_url( 'privacy' ) ); ?>"><?php esc_html_e( 'حریم خصوصی', 'ashpazbashi' ); ?></a></li>
				</ul>
				<?php
			}
			?>
		</div>

		<div class="ashp-footer__col">
			<h4 class="ashp-footer__title"><?php esc_html_e( 'تماس', 'ashpazbashi' ); ?></h4>
			<ul class="ashp-footer__list ashp-footer__list--contact">
				<?php if ( ashpazbashi_contact( 'phone' ) ) : ?>
					<li>
						<span aria-hidden="true">☎</span>
						<a href="<?php echo esc_url( ashpazbashi_tel_href() ); ?>" dir="ltr"><?php echo esc_html( ashpazbashi_contact( 'phone' ) ); ?></a>
					</li>
				<?php endif; ?>
				<?php if ( ashpazbashi_contact( 'email' ) ) : ?>
					<li>
						<span aria-hidden="true">✉</span>
						<a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=<?php echo esc_attr( ashpazbashi_contact( 'email' ) ); ?>" dir="ltr"><?php echo esc_html( ashpazbashi_contact( 'email' ) ); ?></a>
					</li>
				<?php endif; ?>
			</ul>
		</div>

		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
			<div class="ashp-footer__widgets">
				<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
					<?php if ( is_active_sidebar( 'footer-' . $i ) ) : ?>
						<div class="ashp-footer__col"><?php dynamic_sidebar( 'footer-' . $i ); ?></div>
					<?php endif; ?>
				<?php endfor; ?>
			</div>
		<?php endif; ?>

	</div>

	<div class="ashp-footer__bottom">
		<p>
			<?php
			printf(
				/* translators: %s: current year */
				esc_html__( '© %s آشپزباشی — تمامی حقوق محفوظ است.', 'ashpazbashi' ),
				esc_html( date_i18n( 'Y' ) )
			);
			?>
		</p>
		<p class="ashp-footer__made"><?php esc_html_e( 'ساخته‌شده با', 'ashpazbashi' ); ?> <span aria-hidden="true">❤️</span> <?php esc_html_e( 'برای مامان‌ها', 'ashpazbashi' ); ?></p>
	</div>

	<button class="ashp-top" type="button" aria-label="<?php esc_attr_e( 'بازگشت به بالا', 'ashpazbashi' ); ?>"><span aria-hidden="true">↑</span></button>
</footer>
<?php wp_footer(); ?>
</body>
</html>
