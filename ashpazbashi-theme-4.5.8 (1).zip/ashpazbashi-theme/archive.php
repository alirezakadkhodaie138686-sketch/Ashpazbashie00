<?php
/**
 * آرشیو
 *
 * @package Ashpazbashi
 */
get_header();
?>
<div class="ashp-wrap">
	<header class="ashp-page__head">
		<h1 class="ashp-page__title"><?php the_archive_title(); ?></h1>
		<?php the_archive_description( '<div class="ashp-section__sub">', '</div>' ); ?>
	</header>
	<?php if ( have_posts() ) : ?>
		<div class="ashp-grid ashp-grid--3">
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="ashp-card">
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="ashp-card__thumb" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'ashp-card' ); ?></a>
					<?php endif; ?>
					<h4 class="ashp-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					<p class="ashp-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
					<span class="ashp-card__cta"><?php esc_html_e( 'ادامه', 'ashpazbashi' ); ?> ←</span>
				</article>
			<?php endwhile; ?>
		</div>
		<div class="ashp-pagination"><?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?></div>
	<?php else : ?>
		<div class="ashp-empty"><p><?php esc_html_e( 'موردی یافت نشد.', 'ashpazbashi' ); ?></p></div>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
