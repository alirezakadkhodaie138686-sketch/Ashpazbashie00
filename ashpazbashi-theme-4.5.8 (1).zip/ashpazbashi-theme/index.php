<?php
/**
 * صفحهٔ اصلی — هیرو، انتخاب نوع غذا، غذای روز، آمار دیتابیس
 *
 * @package Ashpazbashi
 */

get_header();

$ashp_name = ashpazbashi_current_name();
$ashp_has  = class_exists( 'ASHP_DB' );
?>

<section class="ashp-hero">
	<div class="ashp-hero__bg" aria-hidden="true"></div>
	<div class="ashp-hero__inner">
		<h1 class="ashp-hero__title"><?php echo esc_html( ASHP_SITE_NAME ); ?></h1>
		<p class="ashp-hero__tag"><?php echo esc_html( ASHP_TAGLINE ); ?></p>

		<div class="ashp-hero__welcome">
			<?php echo ashpazbashi_blush_sticker( 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت ?>
			<span class="ashp-hero__hi">
				<strong><?php echo esc_html( $ashp_name ? $ashp_name : __( 'مهمان', 'ashpazbashi' ) ); ?></strong>
				<?php esc_html_e( 'جون خوش اومدی', 'ashpazbashi' ); ?>
			</span>
		</div>

		<div class="ashp-hero__actions">
			<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>">
				<?php esc_html_e( 'انتخاب مواد اولیه و دیدن غذاها', 'ashpazbashi' ); ?>
			</a>
			<a class="ashp-btn ashp-btn--ghost" href="#ashp-cats"><?php esc_html_e( 'انتخاب نوع غذا', 'ashpazbashi' ); ?></a>
		</div>

		<?php if ( $ashp_has ) : ?>
			<?php $c = ASHP_DB::counts(); ?>
			<ul class="ashp-stats">
				<li><b><?php echo esc_html( number_format_i18n( $c['recipes'] ) ); ?></b><span><?php esc_html_e( 'دستور پخت', 'ashpazbashi' ); ?></span></li>
				<li><b><?php echo esc_html( number_format_i18n( $c['ingredients'] ) ); ?></b><span><?php esc_html_e( 'مادهٔ اولیه', 'ashpazbashi' ); ?></span></li>
				<li><b><?php echo esc_html( number_format_i18n( count( ASHP_DB::cats_full() ) ) ); ?></b><span><?php esc_html_e( 'دستهٔ اصلی', 'ashpazbashi' ); ?></span></li>
			</ul>
		<?php endif; ?>
	</div>
</section>

<?php if ( ! $ashp_has && current_user_can( 'manage_options' ) ) : ?>
	<div class="ashp-wrap">
		<div class="ashp-panel ashp-panel--warn">
			<h2><?php esc_html_e( 'موتور آشپزباشی فعال نیست', 'ashpazbashi' ); ?></h2>
			<p><?php esc_html_e( 'این قالب برای نمایش دستورها به افزونهٔ «آشپزباشی — موتور» نیاز دارد. تا زمانی که افزونه نصب و فعال نشود، آمار، دسته‌بندی‌ها و جست‌وجوی غذاها خالی می‌ماند.', 'ashpazbashi' ); ?></p>
			<p><a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'رفتن به صفحهٔ افزونه‌ها', 'ashpazbashi' ); ?></a></p>
		</div>
	</div>
<?php endif; ?>

<section class="ashp-roadmap" aria-labelledby="ashp-roadmap-title">
	<div class="ashp-roadmap__head">
		<h2 id="ashp-roadmap-title"><?php esc_html_e( 'آشپزباشی چگونه کار می‌کند؟', 'ashpazbashi' ); ?></h2>
		<p><?php esc_html_e( 'پنج قدم ساده تا شام امشب — لازم نیست دنبال دستور بگردی، فقط بگو چه داری.', 'ashpazbashi' ); ?></p>
	</div>
	<div class="ashp-roadmap__line">
		<article><i>۱</i><b><?php esc_html_e( 'یخچال و کابینت را نگاه کن', 'ashpazbashi' ); ?></b><span><?php esc_html_e( 'هر چیزی که در خانه داری انتخاب کن — پیاز و سیب‌زمینی هم کافی است.', 'ashpazbashi' ); ?></span></article>
		<article><i>۲</i><b><?php esc_html_e( 'آشپزباشی دنبال غذا می‌گردد', 'ashpazbashi' ); ?></b><span><?php esc_html_e( 'بین چند هزار دستور واقعی، آن‌هایی که با مواد تو جور در می‌آیند پیدا می‌کند.', 'ashpazbashi' ); ?></span></article>
		<article><i>۳</i><b><?php esc_html_e( 'درصد تطابق را ببین', 'ashpazbashi' ); ?></b><span><?php esc_html_e( 'هر غذا نشان می‌دهد چند درصد به مواد تو نزدیک است؛ بالاتر یعنی راحت‌تر.', 'ashpazbashi' ); ?></span></article>
		<article><i>۴</i><b><?php esc_html_e( 'دستور را باز کن', 'ashpazbashi' ); ?></b><span><?php esc_html_e( 'مواد اولیه با مقدار دقیق و مراحل پخت، فارسی و قدم‌به‌قدم.', 'ashpazbashi' ); ?></span></article>
		<article><i>۵</i><b><?php esc_html_e( 'بپز و لذت ببر', 'ashpazbashi' ); ?> ❤️</b><span><?php esc_html_e( 'و اگر خواستی سفره را با خانواده قسمت کن.', 'ashpazbashi' ); ?></span></article>
	</div>
</section>

<section id="ashp-cats" class="ashp-section">
	<header class="ashp-section__head">
		<h2 class="ashp-section__title"><?php esc_html_e( 'انتخاب نوع غذا', 'ashpazbashi' ); ?></h2>
	</header>

	<div class="ashp-cats">
		<?php
		if ( $ashp_has ) :
			foreach ( ASHP_DB::cats_full() as $slug => $info ) :
				$count = ASHP_DB::category_count( $slug );
				?>
				<a class="ashp-catcard" href="<?php echo esc_url( ASHP_DB::category_url( $slug ) ); ?>">
					<span class="ashp-catcard__emoji" aria-hidden="true"><?php echo esc_html( $info['emoji'] ); ?></span>
					<span class="ashp-catcard__fa"><?php echo esc_html( $info['fa'] ); ?></span>
					<span class="ashp-catcard__en" dir="ltr"><?php echo esc_html( $info['en'] ); ?></span>
					<span class="ashp-catcard__desc"><?php echo esc_html( $info['desc'] ); ?></span>
					<span class="ashp-catcard__count"><?php echo esc_html( number_format_i18n( $count ) ); ?> <?php esc_html_e( 'غذا', 'ashpazbashi' ); ?></span>
				</a>
				<?php
			endforeach;
		else :
			?>
			<div class="ashp-empty">
				<p><?php esc_html_e( 'دسته‌بندی‌ها به‌محض فعال شدن افزونهٔ موتور آشپزباشی نمایش داده می‌شوند.', 'ashpazbashi' ); ?></p>
			</div>
			<?php
		endif;
		?>
	</div>
</section>

<?php if ( $ashp_has ) : ?>
	<?php
	$ashp_today = ASHP_DB::recipe_of_the_day();
	if ( $ashp_today ) :
		?>
		<section class="ashp-section">
			<header class="ashp-section__head">
				<h2 class="ashp-section__title"><?php esc_html_e( 'پیشنهاد امروز آشپزباشی', 'ashpazbashi' ); ?></h2>
			</header>
			<?php foreach ( ASHP_DB::today_suggestions() as $ashp_band ) : ?>
				<div class="ashp-band">
					<div class="ashp-band__head">
						<span class="ashp-band__emoji" aria-hidden="true"><?php echo esc_html( $ashp_band['emoji'] ); ?></span>
						<a class="ashp-band__title" href="<?php echo esc_url( $ashp_band['url'] ); ?>"><?php echo esc_html( $ashp_band['label'] ); ?></a>
					</div>
					<div class="ashp-grid ashp-grid--cards">
						<?php foreach ( $ashp_band['rows'] as $ashp_row ) : ?>
							<?php echo ASHP_Front::recipe_card( $ashp_row ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</section>
	<?php endif; ?>
<?php endif; ?>

<div class="ashp-rain" aria-hidden="true"></div>

<?php get_footer(); ?>
