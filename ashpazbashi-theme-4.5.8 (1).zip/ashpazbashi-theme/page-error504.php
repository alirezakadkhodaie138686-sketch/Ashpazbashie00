<?php
/**
 * Template Name: خطای ۵۰۴ — دریافت اطلاعات
 *
 * @package Ashpazbashi
 */

get_header();
?>
<div class="ashp-wrap">
	<div class="ashp-error504">
		<div class="ashp-error504__card">
			<div class="ashp-error504__code" aria-hidden="true">۵۰۴</div>
			<h1 class="ashp-page__title"><?php esc_html_e( 'خطای دریافت اطلاعات', 'ashpazbashi' ); ?></h1>
			<p><?php esc_html_e( 'در حال حاضر دسترسی به اطلاعات آشپزباشی ممکن نیست. لطفاً دوباره تلاش کنید.', 'ashpazbashi' ); ?></p>
			<div class="ashp-hero__actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'صفحهٔ اصلی', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn ashp-btn--ghost" href="<?php echo esc_url( home_url( '/ingredients/' ) ); ?>"><?php esc_html_e( 'آشپزی با مواد موجود', 'ashpazbashi' ); ?></a>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
