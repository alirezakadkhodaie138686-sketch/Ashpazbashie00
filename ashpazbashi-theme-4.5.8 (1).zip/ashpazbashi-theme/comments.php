<?php
/**
 * قالب نظرات
 *
 * @package Ashpazbashi
 */
if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="ashp-comments">
	<?php if ( have_comments() ) : ?>
		<h3 class="ashp-comments__title">
			<?php
			$count = get_comments_number();
			/* translators: %s: comment count */
			printf( esc_html( _n( '%s نظر', '%s نظر', $count, 'ashpazbashi' ) ), esc_html( number_format_i18n( $count ) ) );
			?>
		</h3>
		<ol class="ashp-comments__list">
			<?php
			wp_list_comments( array(
				'style'      => 'ol',
				'short_ping' => true,
				'avatar_size'=> 44,
			) );
			?>
		</ol>
		<?php the_comments_pagination( array( 'mid_size' => 2 ) ); ?>
	<?php endif; ?>

	<?php
	comment_form( array(
		'title_reply'         => __( 'نظر خود را بنویسید', 'ashpazbashi' ),
		'comment_notes_before'=> '',
		'class_submit'        => 'ashp-btn ashp-btn--primary',
	) );
	?>
</div>
