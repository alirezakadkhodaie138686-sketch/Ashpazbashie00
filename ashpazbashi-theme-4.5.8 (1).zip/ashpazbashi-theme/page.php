<?php
/**
 * برگه — پشتیبانی از قالب اختصاصی و ستون کناری
 *
 * @package Ashpazbashi
 */

get_header();
?>
<div class="ashp-wrap ashp-wrap--page">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article <?php post_class( 'ashp-page' ); ?>>
			<header class="ashp-page__head">
				<h1 class="ashp-page__title"><?php the_title(); ?></h1>
				<div class="ashp-neonline" aria-hidden="true"></div>
			</header>
			<div class="ashp-content">
				<?php the_content(); ?>
			</div>
		</article>
		<?php
	endwhile;
	get_sidebar();
	?>
</div>
<?php get_footer(); ?>
