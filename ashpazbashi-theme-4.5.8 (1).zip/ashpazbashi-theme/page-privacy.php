<?php
/**
 * Template Name: حریم خصوصی
 *
 * @package Ashpazbashi
 */

get_header();

$ashp_admin_content = ( class_exists( 'ASHP_DB' ) ) ? ASHP_DB::page_content( 'privacy' ) : '';
?>
<div class="ashp-wrap">
	<header class="ashp-page__head">
		<h1 class="ashp-page__title"><?php esc_html_e( 'حریم خصوصی', 'ashpazbashi' ); ?></h1>
		<div class="ashp-neonline" aria-hidden="true"></div>
	</header>

	<div class="ashp-content">
		<?php
		$ashp_fallback = ashpazbashi_default_page( 'privacy' );
		if ( '' === trim( $ashp_admin_content ) ) {
			$ashp_admin_content = $ashp_fallback;
		}
		if ( '' !== trim( $ashp_admin_content ) ) {
			echo wpautop( wp_kses_post( $ashp_admin_content ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- فیلترشده
		} else {
			while ( have_posts() ) :
				the_post();
				if ( trim( wp_strip_all_tags( get_the_content() ) ) ) {
					the_content();
				} else {
					echo '<p>' . esc_html__( 'متن این صفحه هنوز نوشته نشده است. از پیشخوان › آشپزباشی › صفحه‌ها می‌توانید آن را کامل کنید.', 'ashpazbashi' ) . '</p>';
				}
			endwhile;
		}
		?>
	</div>
</div>
<?php
get_footer();
