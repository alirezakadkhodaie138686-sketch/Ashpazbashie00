<?php
/**
 * Template Name: تماس با ما
 *
 * @package Ashpazbashi
 */

get_header();
?>
<div class="ashp-wrap">
	<header class="ashp-page__head">
		<h1 class="ashp-page__title"><?php esc_html_e( 'تماس با ما', 'ashpazbashi' ); ?></h1>
		<div class="ashp-neonline" aria-hidden="true"></div>
	</header>

	<div class="ashp-content">
		<?php
		$ashp_admin_content = ( class_exists( 'ASHP_DB' ) ) ? ASHP_DB::page_content( 'contact' ) : '';
		$ashp_fallback = ashpazbashi_default_page( 'contact' );
		if ( '' === trim( $ashp_admin_content ) ) {
			$ashp_admin_content = $ashp_fallback;
		}
		if ( '' !== trim( $ashp_admin_content ) ) {
			echo wpautop( wp_kses_post( $ashp_admin_content ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- فیلترشده
		} elseif ( have_posts() ) {
			while ( have_posts() ) :
				the_post();
				if ( trim( wp_strip_all_tags( get_the_content() ) ) ) {
					the_content();
				}
			endwhile;
		}
		?>

		<div class="ashp-grid ashp-grid--3 ashp-contact">
			<?php if ( ashpazbashi_contact( 'email' ) ) : ?>
				<div class="ashp-panel">
					<h3><span aria-hidden="true">✉</span> <?php esc_html_e( 'ایمیل', 'ashpazbashi' ); ?></h3>
					<p dir="ltr"><a href="mailto:<?php echo esc_attr( ashpazbashi_contact( 'email' ) ); ?>"><?php echo esc_html( ashpazbashi_contact( 'email' ) ); ?></a></p>
				</div>
			<?php endif; ?>

			<?php if ( ashpazbashi_contact( 'phone' ) ) : ?>
				<div class="ashp-panel">
					<h3><span aria-hidden="true">☎</span> <?php esc_html_e( 'تلفن', 'ashpazbashi' ); ?></h3>
					<p dir="ltr"><a href="<?php echo esc_url( ashpazbashi_tel_href() ); ?>"><?php echo esc_html( ashpazbashi_contact( 'phone' ) ); ?></a></p>
				</div>
			<?php endif; ?>

			<div class="ashp-panel">
				<h3><span aria-hidden="true">◉</span> <?php esc_html_e( 'نشانی', 'ashpazbashi' ); ?></h3>
				<p>
					<?php
					if ( ashpazbashi_contact( 'address' ) ) {
						echo wp_kses_post( ashpazbashi_contact( 'address' ) );
					} else {
						esc_html_e( 'برای ارتباط با آشپزباشی از شمارهٔ تماس یا ایمیل استفاده کنید.', 'ashpazbashi' );
					}
					?>
				</p>
			</div>
		</div>

		<section id="ashp-contact-form" class="ashp-panel">
			<h2><?php esc_html_e( 'ارسال پیام', 'ashpazbashi' ); ?></h2>
			<p class="ashp-section__sub"><?php esc_html_e( 'فرم زیر مستقیم به ایمیل آشپزباشی می‌رسد. ایمیل شما منتشر نمی‌شود.', 'ashpazbashi' ); ?></p>
			<?php ashpazbashi_contact_form(); ?>
		</section>
	</div>
</div>
<?php get_footer(); ?>
