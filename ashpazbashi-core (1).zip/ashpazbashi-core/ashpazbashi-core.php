<?php
/**
 * Plugin Name:       آشپزباشی — موتور، مدیریت و دیتابیس
 * Plugin URI:        https://ashpazbashi.ir
 * Description:       موتور دادهٔ سایت آشپزباشی: جدول‌های دستورها، مواد اولیه و دسته‌بندی‌ها را می‌سازد، دادهٔ آمادهٔ ۴٬۶۳۱ دستور را وارد می‌کند، مسیرهای /recipes/ و /food/ و /sweets/ و /ingredients/ را راه می‌اندازد و یک پنل مدیریت کامل برای افزودن و ویرایش غذاها دارد. قالب «آشپزباشی» لایهٔ نمایش همین افزونه است.
 * Version:           4.3.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Ashpazbashi Studio
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ashpazbashi
 * Domain Path:       /languages
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'ASHP_CORE_LOADED' ) ) {
	return;
}
define( 'ASHP_CORE_LOADED', true );

define( 'ASHP_CORE_VER', '4.3.2' );
define( 'ASHP_CORE_FILE', __FILE__ );
define( 'ASHP_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'ASHP_CORE_URL', plugin_dir_url( __FILE__ ) );

/* نام و شعار پیش‌فرض — اگر قالب مقدار خودش را تعریف کرده باشد، همان می‌ماند */
if ( ! defined( 'ASHP_SITE_NAME' ) ) {
	define( 'ASHP_SITE_NAME', 'آشپزباشی' );
}
if ( ! defined( 'ASHP_TAGLINE' ) ) {
	define( 'ASHP_TAGLINE', 'بگو چه موادی داری، آشپزباشی بهترین غذا را پیشنهاد می‌دهد.' );
}

/** نام جدول‌های موتور */
if ( ! function_exists( 'ashp_core_table' ) ) {

function ashp_core_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'ashp_' . $name;
}

/* -------------------------------------------------------------------------
 * دسته‌بندی رسمی آشپزباشی
 * ---------------------------------------------------------------------- */
/**
 * ساختار دسته‌ها: slug => [ fa, en, emoji, desc, subs[slug => label] ].
 *
 * این تنها منبع حقیقت برای دسته‌بندی سایت است؛ هم منو، هم آدرس‌ها و هم
 * دسته‌بندی رکوردها بر پایهٔ همین آرایه ساخته می‌شوند.
 */

}

if ( ! function_exists( 'ashp_core_taxonomy' ) ) {

function ashp_core_taxonomy() {
	return array(
		'iranian-formal' => array(
			'fa'    => 'غذاهای ایرانی',
			'en'    => 'Iranian',
			'emoji' => '🍚',
			'desc'  => 'پلوی ایرانی، خورش، خوراک، کباب و کوکو — پرتکرارترین غذاهای سفرهٔ ایرانی.',
			'subs'  => array(
				'polo'         => 'پلویی و چلویی',
				'khoresh'      => 'خورش',
				'khorak'       => 'خوراک',
				'kabab'        => 'کباب، کوفته، کوکو و کتلت',
				'meat-chicken' => 'غذای گوشت و مرغ',
				'seafood'      => 'غذاهای دریایی',
				'vegetarian'   => 'غذای گیاهی',
				'kuku'         => 'کوکو',
				'dolmeh'       => 'دلمه',
				'souffle'      => 'سوفله و گراتن',
				'puree'        => 'پوره',
				'bread'        => 'نان و خمیر',
				'diet'         => 'غذاهای لاغری',
				'kids'         => 'غذای کودکان',
				'microwave'    => 'طبخ در مایکروویو',
				'new'          => 'غذاهای جدید',
			),
		),
		'iranian-local'  => array(
			'fa'    => 'غذاهای محلی ایرانی',
			'en'    => 'Iranian Local',
			'emoji' => '🏡',
			'desc'  => 'غذاهای محلی و منطقه‌ای ایران، از گیلان و مازندران تا جنوب و آذربایجان.',
			'subs'  => array(
				'local'        => 'غذای محلی',
				'polo'         => 'پلویی و چلویی',
				'khoresh'      => 'خورش',
				'khorak'       => 'خوراک',
				'kabab'        => 'کباب، کوفته، کوکو و کتلت',
				'meat-chicken' => 'غذای گوشت و مرغ',
				'seafood'      => 'غذاهای دریایی',
				'vegetarian'   => 'غذای گیاهی',
				'kuku'         => 'کوکو',
				'bread'        => 'نان و خمیر',
				'new'          => 'غذاهای جدید',
				'diet'         => 'غذاهای لاغری',
			),
		),
		'world'          => array(
			'fa'    => 'غذاهای خارجی',
			'en'    => 'World Cuisine',
			'emoji' => '🍝',
			'desc'  => 'غذاهای بین‌المللی که مواد اولیه‌شان در ایران پیدا می‌شود و در ایران هم سرو می‌شوند.',
			'subs'  => array(
				'italian'           => 'ایتالیایی',
				'american-fastfood' => 'فست‌فود آمریکایی',
				'turkish-fastfood'  => 'فست‌فود ترکیه‌ای',
				'international'     => 'بین‌المللی',
			),
		),
		'fastfood'       => array(
			'fa'    => 'ساندویچ، پیتزا و پاستا',
			'en'    => 'Fast Food',
			'emoji' => '🍕',
			'desc'  => 'پیتزا، ساندویچ، ماکارونی و پاستا.',
			'subs'  => array(
				'pizza'    => 'پیتزا و خمیر پیتزا',
				'sandwich' => 'ساندویچ',
				'pasta'    => 'ماکارونی و پاستا',
			),
		),
		'appetizer'      => array(
			'fa'    => 'پیش‌غذا',
			'en'    => 'Appetizer',
			'emoji' => '🥗',
			'desc'  => 'سوپ و آش، سالاد، فینگر فود، اسنک، ترشی و سس.',
			'subs'  => array(
				'soup-ash'    => 'سوپ و آش',
				'salad'       => 'سالاد',
				'finger-food' => 'فینگر فود',
				'snack'       => 'اسنک و پیراشکی',
				'fried'       => 'سوخاری',
				'pickle'      => 'ترشی و شور',
				'sauce'       => 'سس و ادویه',
			),
		),
		'dessert'        => array(
			'fa'    => 'دسر و شیرینی',
			'en'    => 'Dessert',
			'emoji' => '🍰',
			'desc'  => 'کیک، شیرینی، دسر، بستنی، حلوا و مربا.',
			'subs'  => array(
				'cake'      => 'کیک',
				'sweet'     => 'شیرینی خشک و تر',
				'jelly'     => 'دسر، ژله و بامیه',
				'icecream'  => 'بستنی',
				'halva'     => 'حلوا و فرنی',
				'jam'       => 'مربا',
				'chocolate' => 'شکلات و لواشک',
			),
		),
		'drink'          => array(
			'fa'    => 'نوشیدنی',
			'en'    => 'Drink',
			'emoji' => '🥤',
			'desc'  => 'نوشیدنی گرم و سرد، از شربت و اسموتی تا چای و دمنوش.',
			'subs'  => array(
				'cold' => 'نوشیدنی سرد',
				'hot'  => 'نوشیدنی گرم',
			),
		),
	);
}

/** گروه‌بندی مواد اولیه (برای صفحهٔ انتخاب مواد) */

}

if ( ! function_exists( 'ashp_core_ingredient_groups' ) ) {

function ashp_core_ingredient_groups() {
	return array(
		'protein'   => array( 'label' => 'پروتئین', 'emoji' => '🍖' ),
		'veg'       => array( 'label' => 'سبزیجات', 'emoji' => '🥬' ),
		'grain'     => array( 'label' => 'برنج، غلات و آرد', 'emoji' => '🌾' ),
		'legume'    => array( 'label' => 'حبوبات', 'emoji' => '🫘' ),
		'dairy'     => array( 'label' => 'لبنیات و تخم مرغ', 'emoji' => '🥛' ),
		'fruit'     => array( 'label' => 'میوه، مغز و خشکبار', 'emoji' => '🍎' ),
		'fat'       => array( 'label' => 'روغن و کره', 'emoji' => '🫒' ),
		'spice'     => array( 'label' => 'ادویه، سبزی خشک و چاشنی', 'emoji' => '🧂' ),
		'sweetener' => array( 'label' => 'شکر، شیرین‌کننده و شکلات', 'emoji' => '🍯' ),
		'bakery'    => array( 'label' => 'نان و خمیر', 'emoji' => '🍞' ),
		'other'     => array( 'label' => 'سایر مواد', 'emoji' => '🥄' ),
	);
}

/* -------------------------------------------------------------------------
 * ساخت و به‌روزرسانی جدول‌ها
 * ---------------------------------------------------------------------- */

}

if ( ! function_exists( 'ashp_core_install' ) ) {

function ashp_core_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$charset = $wpdb->get_charset_collate();
	$recipes = ashp_core_table( 'recipes' );
	$ings    = ashp_core_table( 'ingredients' );
	$rel     = ashp_core_table( 'recipe_ingredients' );

	$sql = array();

	$sql[] = "CREATE TABLE $recipes (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		name VARCHAR(255) NOT NULL,
		slug VARCHAR(255) NOT NULL,
		category VARCHAR(60) NOT NULL DEFAULT '',
		subcategory VARCHAR(60) NOT NULL DEFAULT '',
		cuisine VARCHAR(40) NOT NULL DEFAULT '',
		meal VARCHAR(40) NOT NULL DEFAULT '',
		suitable_for VARCHAR(60) NOT NULL DEFAULT '',
		servings SMALLINT UNSIGNED NULL DEFAULT NULL,
		prep_time_min DECIMAL(7,1) NULL DEFAULT NULL,
		cook_time_min DECIMAL(7,1) NULL DEFAULT NULL,
		difficulty VARCHAR(30) NOT NULL DEFAULT '',
		cooking_method VARCHAR(60) NOT NULL DEFAULT '',
		instructions LONGTEXT NULL,
		instructions_status VARCHAR(20) NOT NULL DEFAULT 'none',
		calories_kcal DECIMAL(8,1) NULL DEFAULT NULL,
		image_url VARCHAR(600) NOT NULL DEFAULT '',
		source_dataset VARCHAR(60) NOT NULL DEFAULT '',
		source_row INT NULL DEFAULT NULL,
		completeness VARCHAR(30) NOT NULL DEFAULT '',
		is_active TINYINT(1) NOT NULL DEFAULT 1,
		is_halal TINYINT(1) NOT NULL DEFAULT 1,
		halal_note VARCHAR(255) NOT NULL DEFAULT '',
		kid_ok TINYINT(1) NOT NULL DEFAULT 0,
		party_ok TINYINT(1) NOT NULL DEFAULT 0,
		province VARCHAR(60) NOT NULL DEFAULT '',
		country VARCHAR(60) NOT NULL DEFAULT '',
		created_at DATETIME NULL DEFAULT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY ashp_slug (slug),
		KEY ashp_cat (category, subcategory),
		KEY ashp_active_cat (is_active, category),
		KEY ashp_kid (kid_ok),
		KEY ashp_party (party_ok),
		KEY ashp_halal (is_halal),
		KEY ashp_name (name(64))
	) $charset;";

	$sql[] = "CREATE TABLE $ings (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		name VARCHAR(190) NOT NULL,
		slug VARCHAR(190) NOT NULL,
		normalized_name VARCHAR(190) NOT NULL,
		group_key VARCHAR(40) NOT NULL DEFAULT 'other',
		recipes_count INT UNSIGNED NOT NULL DEFAULT 0,
		PRIMARY KEY  (id),
		UNIQUE KEY ashp_norm (normalized_name),
		KEY ashp_group (group_key),
		KEY ashp_count (recipes_count)
	) $charset;";

	$sql[] = "CREATE TABLE $rel (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		recipe_id BIGINT UNSIGNED NOT NULL,
		ingredient_id BIGINT UNSIGNED NOT NULL,
		amount_value DECIMAL(10,3) NULL DEFAULT NULL,
		amount_text VARCHAR(80) NULL DEFAULT NULL,
		unit VARCHAR(40) NULL DEFAULT NULL,
		is_main TINYINT(1) NOT NULL DEFAULT 0,
		amount_is_free TINYINT(1) NOT NULL DEFAULT 0,
		sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
		PRIMARY KEY  (id),
		KEY ashp_recipe (recipe_id, sort_order),
		KEY ashp_ingredient (ingredient_id),
		KEY ashp_main (recipe_id, is_main)
	) $charset;";

	foreach ( $sql as $statement ) {
		dbDelta( $statement );
	}

	update_option( 'ashp_core_ver', ASHP_CORE_VER, false );
}

}

/* -------------------------------------------------------------------------
 * بررسی سازگاری — بدون متوقف‌کردن فعال‌سازی
 *
 * نکتهٔ مهم: در هوک فعال‌سازی نباید deactivate_plugins() یا wp_die() صدا
 * زده شود؛ همین کار چرخهٔ وردپرس را می‌شکند و پیام «خطای مرگ‌آور» می‌سازد.
 * ---------------------------------------------------------------------- */
if ( ! function_exists( 'ashp_core_conflicting_theme' ) ) {

/** اگر قالب موتور قدیمی را داخل خود داشته باشد نامش را برمی‌گرداند */
function ashp_core_conflicting_theme() {
	$theme = get_template_directory();
	foreach ( array( $theme . '/inc/class-ashp-db.php', $theme . '/inc/class-ashp-front.php' ) as $file ) {
		if ( file_exists( $file ) ) {
			return basename( $theme );
		}
	}
	return '';
}

/** بررسی سازگاری — بدون متوقف‌کردن فعال‌سازی */
function ashp_core_compat_problems() {
	$problems = array();

	if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
		$problems[] = sprintf(
			/* translators: %s: current PHP version */
			__( 'نسخهٔ PHP شما %s است و این افزونه به PHP ۷.۴ یا بالاتر نیاز دارد.', 'ashpazbashi' ),
			PHP_VERSION
		);
	}

	$theme = ashp_core_conflicting_theme();
	if ( '' !== $theme ) {
		$problems[] = sprintf(
			/* translators: %s: theme folder name */
			__( 'قالب فعال («%s») نسخهٔ قدیمی موتور آشپزباشی را داخل خود دارد. لطفاً قالب را به نسخهٔ ۲.۷.۰ یا بالاتر به‌روزرسانی کنید تا پنل مدیریت و صفحه‌های تازه درست کار کنند.', 'ashpazbashi' ),
			$theme
		);
	}

	return $problems;
}

/** ثبت نتیجهٔ بررسی سازگاری (بدون توقف) */
function ashp_core_activation_guard() {
	$problems = ashp_core_compat_problems();
	if ( $problems ) {
		update_option( 'ashp_core_compat', $problems );
	} else {
		delete_option( 'ashp_core_compat' );
	}
}

/** هشدار پیشخوان در صورت وجود مشکل سازگاری */
function ashp_core_conflict_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	$stored = get_option( 'ashp_core_compat' );
	if ( ! is_array( $stored ) || ! $stored ) {
		return;
	}

	echo '<div class="notice notice-warning"><p><strong>' .
		esc_html__( 'آشپزباشی — هشدار سازگاری:', 'ashpazbashi' ) . '</strong></p><ul style="margin-inline-start:18px;list-style:disc">';
	foreach ( $stored as $line ) {
		echo '<li>' . esc_html( $line ) . '</li>';
	}
	echo '</ul><p><a href="' . esc_url( admin_url( 'themes.php' ) ) . '">' .
		esc_html__( 'به‌روزرسانی قالب', 'ashpazbashi' ) . '</a></p></div>';
}
}

add_action( 'admin_notices', 'ashp_core_conflict_notice' );


register_activation_hook( __FILE__, 'ashp_core_activation_guard' );
register_activation_hook( __FILE__, 'ashp_core_install' );

/* -------------------------------------------------------------------------
 * بارگذاری کلاس‌ها
 * ---------------------------------------------------------------------- */
require_once ASHP_CORE_DIR . 'includes/class-ashp-db.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-front.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-router.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-ajax.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-importer.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-admin.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-health.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-foodsettings.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-dbpage.php';
require_once ASHP_CORE_DIR . 'includes/class-ashp-comments.php';

/*
 * نظرات و امتیازدهی دستورهای پخت.
 *
 * جدول نظرات روی سایت‌های موجود هم ساخته می‌شود: کاربری که فقط فایل‌های
 * افزونه را جایگزین می‌کند هرگز هوک فعال‌سازی را اجرا نمی‌کند، پس ساخت
 * جدول را به init گره می‌زنیم و با یک گزینهٔ نسخه کنترل می‌کنیم تا هر
 * بارگذاری، کوئری اضافه نزند.
 */
if ( class_exists( 'ASHP_Comments' ) ) {
	add_action( 'init', array( 'ASHP_Comments', 'maybe_install' ), 5 );
	add_action( 'admin_menu', array( 'ASHP_Comments', 'admin_menu' ), 20 );
	add_action( 'template_redirect', array( 'ASHP_Comments', 'maybe_handle_submit' ), 5 );
}

/* اصلاح یک‌بارهٔ تنظیمات انیمیشن غذا (اگر خاموش مانده باشد) */
add_action( 'admin_init', array( 'ASHP_FoodSettings', 'maybe_fix_defaults' ) );
add_action( 'admin_notices', array( 'ASHP_FoodSettings', 'fix_notice' ) );
ASHP_FoodSettings::init();

/* -------------------------------------------------------------------------
 * راه‌اندازی
 * ---------------------------------------------------------------------- */
/**
 * آیا موتور تازهٔ آشپزباشی آماده است؟
 *
 * اگر قالب قدیمی همان کلاس‌ها را تعریف کرده باشد، متدهای تازه وجود ندارند و
 * صدا زدنشان خطای مرگ‌آور می‌دهد. در آن حالت بخش‌های وابسته ثبت نمی‌شوند.
 */
if ( ! function_exists( 'ashp_core_engine_ready' ) ) {

function ashp_core_engine_ready() {
	if ( ! class_exists( 'ASHP_DB' ) || ! class_exists( 'ASHP_Router' ) ) {
		return false;
	}
	foreach ( array( 'pick_recipes', 'clean_slugs', 'query_recipes', 'search_recipes' ) as $m ) {
		if ( ! method_exists( 'ASHP_DB', $m ) ) {
			return false;
		}
	}
	return true;
}

}

if ( ashp_core_engine_ready() ) {
	add_action( 'init', array( 'ASHP_Router', 'register_rules' ) );
}
if ( ashp_core_engine_ready() ) {
	add_action( 'init', array( 'ASHP_Router', 'register_query_vars' ) );
}
if ( ashp_core_engine_ready() ) {
	add_filter( 'template_include', array( 'ASHP_Router', 'template_include' ), 99 );
}

/** مسیرهای آشپزباشی برگه یا نوشتهٔ واقعی وردپرس نیستند؛ ۴۰۴ نشوند. */
add_filter( 'pre_handle_404', function ( $preempt, $wp_query ) {
	if ( ! ashp_core_engine_ready() ) {
		return $preempt;
	}
	if ( ASHP_Router::is_ashp_page() ) {
		return true;
	}
	return $preempt;
}, 10, 2 );

/** عنوان صفحه برای مسیرهای آشپزباشی */
add_filter( 'document_title_parts', function ( $parts ) {
	if ( ASHP_Router::is_recipe_page() ) {
		$r = ASHP_DB::current_recipe();
		if ( $r ) {
			$parts['title'] = $r['name'];
		}
	} elseif ( ASHP_Router::is_ingredient_page() ) {
		$i = ASHP_DB::current_ingredient();
		if ( $i ) {
			/* translators: %s: ingredient name */
			$parts['title'] = sprintf( __( 'غذاهایی با %s', 'ashpazbashi' ), $i['name'] );
		}
	} elseif ( ASHP_Router::is_picker_page() ) {
		$parts['title'] = __( 'آشپزی با مواد موجود', 'ashpazbashi' );
	} elseif ( ASHP_Router::is_hub_page() ) {
		$parts['title'] = ASHP_Router::hub_title();
	} elseif ( ASHP_Router::is_list_page() ) {
		$ctx            = ASHP_DB::current_list_context();
		$parts['title'] = $ctx['title'];
	}
	return $parts;
}, 20 );

/** کلاس بدنه برای مسیرهای آشپزباشی */
add_filter( 'body_class', function ( $classes ) {
	if ( ! ashp_core_engine_ready() ) {
		return $classes;
	}
	if ( ASHP_Router::is_recipe_page() ) {
		$classes[] = 'ashp-route-recipe';
	} elseif ( ASHP_Router::is_ingredient_page() ) {
		$classes[] = 'ashp-route-ingredient';
	} elseif ( ASHP_Router::is_picker_page() ) {
		$classes[] = 'ashp-route-picker';
	} elseif ( ASHP_Router::is_hub_page() ) {
		$classes[] = 'ashp-route-hub';
	} elseif ( ASHP_Router::is_list_page() ) {
		$classes[] = 'ashp-route-list';
	}
	return $classes;
} );

/** آیا صفحهٔ جاری یک «تک‌صفحهٔ» آشپزباشی است؟ */
if ( ! function_exists( 'ashp_core_is_singular_page' ) ) {

function ashp_core_is_singular_page() {
	return is_singular() || ASHP_Router::is_recipe_page() || ASHP_Router::is_ingredient_page();
}

}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! ashp_core_engine_ready() || ! ASHP_Router::is_picker_page() ) {
		return;
	}
	wp_enqueue_script( 'ashp-picker', ASHP_CORE_URL . 'assets/picker.js', array(), ASHP_CORE_VER, true );
} );

/** ساخت جدول‌ها پس از به‌روزرسانی افزونه */
add_action( 'plugins_loaded', function () {
	if ( get_option( 'ashp_core_ver' ) !== ASHP_CORE_VER ) {
		ashp_core_install();
		/* نام query varها ممکن است در به‌روزرسانی عوض شده باشد؛ قواعد مسیر
		   باید یک‌بار از نو ساخته شوند وگرنه صفحات ۴۰۴ می‌شوند. */
		if ( class_exists( 'ASHP_Router' ) ) {
			ASHP_Router::register_rules();
			flush_rewrite_rules( false );
		}
	}
}, 5 );

/** تازه‌سازی مسیرها هنگام فعال‌سازی */
if ( ! function_exists( 'ashp_core_activation_routes' ) ) {

function ashp_core_activation_routes() {
	ASHP_Router::register_rules();
	flush_rewrite_rules();
}

}

register_activation_hook( __FILE__, 'ashp_core_activation_routes' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
