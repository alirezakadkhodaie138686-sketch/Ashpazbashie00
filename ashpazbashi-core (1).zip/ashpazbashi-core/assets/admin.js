/* ==================================================================
   پنل مدیریت آشپزباشی — رفتار فرم‌ها
   ================================================================== */
(function () {
	'use strict';

	var CFG = window.ASHP_ADMIN || {};

	function $(s, c) { return (c || document).querySelector(s); }
	function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }

	/* ---------------- ۱) زیردستهٔ وابسته به دسته ---------------- */

	function syncSubcats() {
		var catSel = $('#ashp-cat');
		var subSel = $('#ashp-sub');
		if (!catSel || !subSel) return;

		var map = CFG.subs || {};
		var subs = map[catSel.value] || {};
		var current = subSel.getAttribute('data-current') || '';

		subSel.innerHTML = '';
		var first = document.createElement('option');
		first.value = '';
		first.textContent = '— انتخاب کنید —';
		subSel.appendChild(first);

		Object.keys(subs).forEach(function (slug) {
			var o = document.createElement('option');
			o.value = slug;
			o.textContent = subs[slug];
			if (slug === current) o.selected = true;
			subSel.appendChild(o);
		});
	}

	var catSel = $('#ashp-cat');
	if (catSel) {
		catSel.addEventListener('change', function () {
			var subSel = $('#ashp-sub');
			if (subSel) subSel.setAttribute('data-current', '');
			syncSubcats();
		});
		syncSubcats();
	}

	/* ---------------- ۲) اسلاگ خودکار ---------------- */

	var nameInput = $('#ashp-name');
	var slugInput = $('#ashp-slug');
	var slugTouched = false;

	if (slugInput) {
		slugInput.addEventListener('input', function () { slugTouched = true; });
	}
	if (nameInput && slugInput) {
		nameInput.addEventListener('blur', function () {
			if (slugTouched || slugInput.value.trim()) return;
			slugInput.value = nameInput.value.trim();
		});
	}

	/* ---------------- ۳) ردیف‌های مواد اولیه ---------------- */

	var box = $('#ashp-ing-rows');
	var tpl = $('#ashp-ing-template');

	function renumber() {
		if (!box) return;
		$$('.ashp-ing-row', box).forEach(function (row, i) {
			var n = $('.ashp-ing-row__n', row);
			if (n) n.textContent = faNum(i + 1);
		});
	}

	function faNum(n) {
		try { return Number(n).toLocaleString('fa-IR'); } catch (e) { return String(n); }
	}

	function addRow(data) {
		if (!box || !tpl) return;
		var node = tpl.content.cloneNode(true);
		var row = node.querySelector('.ashp-ing-row');

		if (data) {
			var nameIn = row.querySelector('input[name="ing_name[]"]');
			var valIn = row.querySelector('input[name="ing_value[]"]');
			var unitIn = row.querySelector('input[name="ing_unit[]"]');
			var mainIn = row.querySelector('input[name="ing_main[]"]');
			if (nameIn && data.name) nameIn.value = data.name;
			if (valIn && data.value !== '' && data.value !== null && data.value !== undefined) valIn.value = data.value;
			if (unitIn && data.unit) unitIn.value = data.unit;
			if (mainIn) mainIn.checked = !!data.main;
		}
		box.appendChild(node);
		renumber();
	}

	if (box) {
		/* بارگذاری مواد اولیهٔ ذخیره‌شده (حالت ویرایش) */
		var data = document.getElementById('ashp-ing-data');
		if (data) {
			try {
				JSON.parse(data.textContent || '[]').forEach(function (row) {
					addRow({ name: row.name, unit: row.unit, main: row.main, value: row.value });
				});
			} catch (e) { /* دادهٔ نامعتبر — ردیف خالی می‌سازیم */ }
		}
		if (!box.querySelector('.ashp-ing-row')) addRow(null);
		renumber();
		updateCount();

		box.addEventListener('click', function (e) {
			var btn = e.target.closest('.ashp-ing-remove');
			if (!btn) return;
			var row = btn.closest('.ashp-ing-row');
			if (row) row.remove();
			renumber();
			updateCount();
		});

		var addBtn = $('#ashp-ing-add');
		if (addBtn) {
			addBtn.addEventListener('click', function () { addRow(null); updateCount(); });
		}
		if (!box.querySelector('.ashp-ing-row')) addRow(null);
	}

	function updateCount() {
		var el = $('#ashp-ing-count');
		if (!el || !box) return;
		el.textContent = faNum($$('.ashp-ing-row', box).length);
	}
	updateCount();

	/* ---------------- ۴) تأیید عملیات خطرناک ---------------- */

	$$('[data-ashp-confirm]').forEach(function (el) {
		el.addEventListener('click', function (e) {
			if (!window.confirm(el.getAttribute('data-ashp-confirm'))) e.preventDefault();
		});
	});

	/* ---------------- ۵) فیلتر جست‌وجوی مواد اولیه در فرم ---------------- */

	var ingSearch = $('#ashp-ing-filter');
	if (ingSearch) {
		ingSearch.addEventListener('input', function () {
			var q = ingSearch.value.trim().toLowerCase();
			$$('.ashp-ing-row', box).forEach(function (row) {
				var input = row.querySelector('input[type=text]');
				var hit = !q || (input && input.value.toLowerCase().indexOf(q) !== -1);
				row.style.display = hit ? '' : 'none';
			});
		});
	}

	/* ---------------- ۶) صفحهٔ «انیمیشن غذا و پیشنهادها» ---------------- */

	var fsForm = document.querySelector('[data-ashp-fs-form]');

	if (fsForm) {
		var fsBoxes = $$('input[name="ashp[enabled][]"]', fsForm);
		var fsSave = document.querySelector('[data-ashp-fs-savebar]');
		var fsSaveTxt = document.querySelector('[data-ashp-fs-savetxt]');
		var fsKpi = document.querySelector('[data-ashp-fs-kpi="on"]');
		var fsDirty = false;

		function fsMarkDirty() {
			if (fsDirty || !fsSave) return;
			fsDirty = true;
			fsSave.classList.add('is-dirty');
			if (fsSaveTxt) fsSaveTxt.textContent = fsSaveTxt.getAttribute('data-dirty') || fsSaveTxt.textContent;
		}

		/* اسلایدر ↔ عدد ↔ نمایشگر */
		[['size', 40, 200, '٪'], ['offset', -220, 220, ' px']].forEach(function (cfg) {
			var key = cfg[0];
			var range = document.querySelector('[data-ashp-fs-range="' + key + '"]');
			var num = document.querySelector('[data-ashp-fs-num="' + key + '"]');
			var out = document.querySelector('[data-ashp-fs-out="' + key + '"]');
			if (!range || !num) return;

			function fsClamp(v) {
				v = parseInt(v, 10);
				if (isNaN(v)) v = 0;
				return Math.max(cfg[1], Math.min(cfg[2], v));
			}
			function fsSync(value, from) {
				var v = fsClamp(value);
				if (from !== 'range') range.value = v;
				if (from !== 'num') num.value = v;
				if (out) out.textContent = v + cfg[3];
			}
			range.addEventListener('input', function () { fsSync(range.value, 'range'); fsMarkDirty(); });
			num.addEventListener('input', function () { fsSync(num.value, 'num'); fsMarkDirty(); });
			fsSync(num.value, 'num');
		});

		/* شمارندهٔ دسته‌ها و کل */
		function fsCount() {
			var on = 0;
			fsBoxes.forEach(function (b) { if (b.checked) on++; });
			return on;
		}
		function fsRefresh() {
			var totalOn = 0;
			$$('[data-ashp-fs-group]', fsForm).forEach(function (g) {
				var inGroup = $$('input[name="ashp[enabled][]"]', g);
				var on = 0;
				inGroup.forEach(function (b) {
					if (b.checked) on++;
					var lab = b.closest('.ashp-fs__item');
					if (lab) lab.classList.toggle('is-off', !b.checked);
				});
				totalOn += on;
				var badge = g.querySelector('[data-ashp-fs-groupn]');
				if (badge) badge.textContent = faNum(on) + ' / ' + faNum(inGroup.length);
			});
			if (fsKpi) fsKpi.textContent = faNum(totalOn);
		}

		fsBoxes.forEach(function (b) {
			b.addEventListener('change', function () { fsRefresh(); fsMarkDirty(); });
		});

		$$('[data-ashp-fs-cat]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var g = btn.closest('[data-ashp-fs-group]');
				var on = btn.getAttribute('data-ashp-fs-cat') === '1';
				$$('input[name="ashp[enabled][]"]', g).forEach(function (b) { b.checked = on; });
				fsRefresh();
				fsMarkDirty();
			});
		});

		$$('[data-ashp-fs-all]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var on = btn.getAttribute('data-ashp-fs-all') === '1';
				fsBoxes.forEach(function (b) { b.checked = on; });
				fsRefresh();
				fsMarkDirty();
			});
		});

		fsForm.addEventListener('change', fsMarkDirty);
		fsForm.addEventListener('submit', function () {
			var btn = fsForm.querySelector('button[type="submit"]');
			if (btn) { btn.disabled = true; btn.textContent = '…'; }
		});

		fsRefresh();
	}
})();
