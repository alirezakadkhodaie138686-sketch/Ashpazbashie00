/* ==================================================================
   صفحهٔ «آشپزی با مواد موجود»
   انتخاب مواد اولیه و دریافت زندهٔ پیشنهادها از موتور آشپزباشی.
   بدون جاوااسکریپت هم فرم به‌صورت GET کار می‌کند.
   ================================================================== */
(function () {
	'use strict';

	var form = document.getElementById('ashp-picker');
	if (!form) return;

	var CFG = window.ASHP || {};
	var MIN_PICK = 3;

	var grid = document.getElementById('ashp-picker-grid');
	var countEl = document.getElementById('ashp-picked-count');
	var statusEl = document.getElementById('ashp-picker-status');
	var hintEl = document.getElementById('ashp-picker-hint');
	var searchEl = document.getElementById('ashp-ingsearch');
	var clearBtn = document.getElementById('ashp-picker-clear');

	var chips = Array.prototype.slice.call(form.querySelectorAll('.ashp-chip'));
	var hidBox = form.querySelector('[data-ashp-hidden]');
	var timer = null;
	var controller = null;
	var lastPayload = '';

	function fa(n) {
		try { return n.toLocaleString('fa-IR'); } catch (e) { return String(n); }
	}

	function selected() {
		return chips.filter(function (c) { return c.getAttribute('aria-pressed') === 'true'; });
	}

	/* فیلدهای مخفی را همگام می‌کند تا ارسال بدون جاوااسکریپت کار کند */
	function syncHidden(picked) {
		form.querySelectorAll('[data-ashp-hidden]').forEach(function (el) { el.remove(); });
		picked.forEach(function (c) {
			var input = document.createElement('input');
			input.type = 'hidden';
			input.name = 'ing[]';
			input.value = c.getAttribute('data-ashp-ing');
			input.setAttribute('data-ashp-hidden', '');
			form.appendChild(input);
		});
	}

	function renderCard(name, match, total, url) {
		var a = document.createElement('a');
		a.className = 'ashp-rcard';
		a.href = url;

		var media = document.createElement('span');
		media.className = 'ashp-rcard__media';
		var ph = document.createElement('span');
		ph.className = 'ashp-rcard__ph';
		ph.setAttribute('aria-hidden', 'true');
		ph.textContent = '🍽';
		media.appendChild(ph);

		var body = document.createElement('span');
		body.className = 'ashp-rcard__body';

		var t = document.createElement('span');
		t.className = 'ashp-rcard__title';
		t.textContent = name;
		body.appendChild(t);

		var badges = document.createElement('span');
		badges.className = 'ashp-rcard__badges';
		var b = document.createElement('span');
		if (match >= total) {
			b.className = 'ashp-badge ashp-badge--ok';
			b.textContent = 'همهٔ مواد را داری (' + fa(total) + ')';
		} else {
			b.className = 'ashp-badge ashp-badge--neon';
			b.textContent = fa(match) + ' از ' + fa(total) + ' ماده';
		}
		badges.appendChild(b);

		body.appendChild(badges);
		a.appendChild(media);
		a.appendChild(body);
		return a;
	}

	function showMessage(text) {
		grid.innerHTML = '';
		var box = document.createElement('div');
		box.className = 'ashp-empty';
		var p = document.createElement('p');
		p.textContent = text;
		box.appendChild(p);
		grid.appendChild(box);
	}

	function query(picked) {
		var payload = picked.map(function (c) { return c.getAttribute('data-ashp-ing'); }).sort().join(',');
		if (payload === lastPayload) return;
		lastPayload = payload;

		if (!CFG.plugin) {
			showMessage('افزونهٔ موتور آشپزباشی فعال نیست.');
			return;
		}

		if (controller) { controller.abort(); }
		controller = ('AbortController' in window) ? new AbortController() : null;

		statusEl.textContent = (CFG.i18n && CFG.i18n.loading) ? CFG.i18n.loading : 'در حال بررسی…';

		var fd = new FormData();
		fd.append('action', 'ashp_pick');
		fd.append('nonce', CFG.nonce || '');
		picked.forEach(function (c) { fd.append('ing[]', c.getAttribute('data-ashp-ing')); });

		fetch(CFG.ajax, {
			method: 'POST',
			body: fd,
			credentials: 'same-origin',
			signal: controller ? controller.signal : undefined
		})
			.then(function (r) { return r.json(); })
			.then(function (data) {
				if (!data || !data.success) {
					showMessage('خطا در دریافت پیشنهادها. دوباره تلاش کن.');
					return;
				}
				var items = data.data.recipes || [];
				statusEl.textContent = items.length
					? fa(items.length) + ' غذا با مواد انتخابی‌ات قابل پخت است.'
					: ((CFG.i18n && CFG.i18n.noResult) || 'غذایی با این مواد پیدا نشد. مواد دیگری امتحان کن.');

				grid.innerHTML = '';
				if (!items.length) {
					showMessage((CFG.i18n && CFG.i18n.noResult) || 'غذایی با این مواد پیدا نشد.');
					return;
				}
				items.forEach(function (it) {
					grid.appendChild(renderCard(it.name, it.match, it.total, it.url));
				});
			})
			.catch(function (err) {
				if (err && err.name === 'AbortError') return;
				showMessage('خطا در دریافت پیشنهادها. دوباره تلاش کن.');
			});
	}

	function update() {
		var picked = selected();
		countEl.textContent = fa(picked.length);
		syncHidden(picked);

		if (picked.length < MIN_PICK) {
			hintEl.textContent = (CFG.i18n && CFG.i18n.pickMin)
				|| ('حداقل ' + MIN_PICK + ' مادهٔ اصلی انتخاب کن.');
			grid.innerHTML = '';
			lastPayload = '';
			statusEl.textContent = 'هر چه مواد بیشتری انتخاب کنی، پیشنهادها دقیق‌تر می‌شود.';
			return;
		}
		hintEl.textContent = '';
		query(picked);
	}

	chips.forEach(function (chip) {
		chip.addEventListener('click', function () {
			var on = chip.getAttribute('aria-pressed') === 'true';
			chip.setAttribute('aria-pressed', on ? 'false' : 'true');
			update();
		});
	});

	if (searchEl) {
		searchEl.addEventListener('input', function () {
			var q = searchEl.value.trim().toLowerCase();
			chips.forEach(function (c) {
				var hit = !q || c.textContent.toLowerCase().indexOf(q) !== -1;
				c.style.display = hit ? '' : 'none';
			});
			form.querySelectorAll('[data-ashp-group]').forEach(function (g) {
				var visible = g.querySelectorAll('.ashp-chip:not([style*="display: none"])').length;
				g.style.display = visible ? '' : 'none';
			});
		});
	}

	if (clearBtn) {
		clearBtn.addEventListener('click', function () {
			chips.forEach(function (c) { c.setAttribute('aria-pressed', 'false'); });
			update();
		});
	}

	/* جلوگیری از ارسال فرم با کمتر از حد لازم */
	form.addEventListener('submit', function (e) {
		if (selected().length < MIN_PICK) {
			e.preventDefault();
			hintEl.textContent = (CFG.i18n && CFG.i18n.pickMin)
				|| ('حداقل ' + MIN_PICK + ' مادهٔ اصلی انتخاب کن.');
			form.querySelector('.ashp-picker__bar').scrollIntoView({ block: 'center' });
			return;
		}
	});

	/* وضعیت اولیه (از جمله وقتی با پارامتر آمده باشد) */
	update();
})();
