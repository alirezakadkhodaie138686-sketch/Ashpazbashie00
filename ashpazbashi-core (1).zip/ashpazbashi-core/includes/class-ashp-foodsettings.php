<?php
/**
 * مدیریت انیمیشن غذاها + غذای روز و پیشنهادی
 *
 * همهٔ تنظیمات در یک ردیف از جدول options وردپرس ذخیره می‌شود
 * (کلید: ashp_foodsettings) و از همین صفحه قابل برون‌بری/درون‌ریزی است.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_FoodSettings' ) ) {

	class ASHP_FoodSettings {

		const OPT = 'ashp_foodsettings';

		/** فهرست مرجع غذاهای انیمیشنی (کلید = همان catKey در قالب) */
		public static function foods() {
			return array(
				'iranian'   => array(
					'label' => __( 'غذای ایرانی', 'ashpazbashi' ),
					'items' => array( 'چلوکباب', 'قورمه‌سبزی', 'آش رشته' ),
				),
				'fastfood'  => array(
					'label' => __( 'فست‌فود', 'ashpazbashi' ),
					'items' => array( 'همبرگر', 'پیتزا', 'سیب‌زمینی سرخ‌کرده', 'ساندویچ' ),
				),
				'dessert'   => array(
					'label' => __( 'دسر', 'ashpazbashi' ),
					'items' => array( 'بستنی', 'کیک' ),
				),
				'drink'     => array(
					'label' => __( 'نوشیدنی', 'ashpazbashi' ),
					'items' => array( 'نوشابه', 'چای' ),
				),
				'appetizer' => array(
					'label' => __( 'پیش‌غذا و سالاد', 'ashpazbashi' ),
					'items' => array( 'سالاد', 'ماست و خیار' ),
				),
				'seafood'   => array(
					'label' => __( 'غذای دریایی', 'ashpazbashi' ),
					'items' => array( 'ماهی', 'میگو سوخاری' ),
				),
				'kids'      => array(
					'label' => __( 'غذای کودکان', 'ashpazbashi' ),
					'items' => array( 'پنکیک', 'ناگت' ),
				),
			);
		}

		/** دسته‌بندی‌های صفحهٔ اصلی برای «غذای روز و پیشنهادی» */
		public static function home_cats() {
			return array(
				'iranian-formal' => __( 'غذاهای ایرانی', 'ashpazbashi' ),
				'iranian-local'  => __( 'غذاهای محلی ایرانی', 'ashpazbashi' ),
				'world'          => __( 'غذاهای خارجی', 'ashpazbashi' ),
				'fastfood'       => __( 'ساندویچ، پیتزا و پاستا', 'ashpazbashi' ),
				'appetizer'      => __( 'پیش‌غذا', 'ashpazbashi' ),
				'dessert'        => __( 'دسر و شیرینی', 'ashpazbashi' ),
				'drink'          => __( 'نوشیدنی', 'ashpazbashi' ),
			);
		}

		/** مقادیر پیش‌فرض */
		/**
		 * اصلاح یک‌بارهٔ تنظیمات.
		 *
		 * اگر انیمیشن غذا (master) خاموش مانده باشد، یک بار خودش روشن
		 * می‌شود و یک یادداشت در پیشخوان نشان می‌دهد. این کار فقط یک بار
		 * انجام می‌شود؛ بعد از آن هر تغییری که خودت بدهی دست‌نخورده می‌ماند.
		 */
		public static function maybe_fix_defaults() {
			if ( get_option( 'ashp_fs_fixed' ) === ASHP_CORE_VER ) {
				return;
			}
			$saved = get_option( self::OPT, null );
			if ( is_array( $saved ) && empty( $saved['master'] ) ) {
				$saved['master'] = 1;
				update_option( self::OPT, $saved );
				set_transient( 'ashp_fs_fixed_notice', 1, 5 * MINUTE_IN_SECONDS );
			}
			update_option( 'ashp_fs_fixed', ASHP_CORE_VER, false );
		}

		/** یادداشت اصلاح تنظیمات. */
		public static function fix_notice() {
			if ( ! current_user_can( ASHP_Admin::CAP ) || ! get_transient( 'ashp_fs_fixed_notice' ) ) {
				return;
			}
			delete_transient( 'ashp_fs_fixed_notice' );
			printf(
				'<div class="notice notice-success is-dismissible"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
				esc_html__( 'انیمیشن غذا روشن شد.', 'ashpazbashi-core' ),
				esc_html__( 'خاموش مانده بود، پس یک‌بار خودکار روشنش کردم.', 'ashpazbashi-core' ),
				esc_url( admin_url( 'admin.php?page=ashpazbashi-food' ) ),
				esc_html__( 'تنظیمات انیمیشن غذا', 'ashpazbashi-core' )
			);
		}

		public static function defaults() {
			$enabled = array();
			foreach ( self::foods() as $cat => $info ) {
				foreach ( $info['items'] as $name ) {
					$enabled[ $name ] = 1;
				}
			}

			return array(
				'enabled'     => $enabled,
				'percat'      => 20,          /* تعداد انیمیشن هر دسته */
				'master'      => 1,           /* کل انیمیشن غذا روشن/خاموش */
				'size'        => 100,         /* درصد اندازه */
				'offset'      => 0,           /* جابه‌جایی عمودی نسبت به جای پیش‌فرض (px) */
				'anchor'      => 'roadmap',   /* جای درج */
				'dust'        => 1,           /* گرد و خاک */
				'drip'        => 1,           /* چکیدن سس */
				'day_cats'    => array( 'iranian-formal', 'appetizer', 'fastfood', 'world', 'dessert', 'drink' ),
				'day_count'   => 4,           /* چند دستور در هر دسته */
				'day_hours'   => 24,          /* هر چند ساعت عوض شود */
			);
		}

		/** تنظیمات فعلی (پیش‌فرض + ذخیره‌شده) */
		public static function get() {
			$saved = get_option( self::OPT, array() );
			if ( ! is_array( $saved ) ) {
				$saved = array();
			}
			$saved = array_merge( self::defaults(), $saved );
			if ( ! is_array( $saved['enabled'] ) ) {
				$saved['enabled'] = array();
			}
			if ( ! is_array( $saved['day_cats'] ) ) {
				$saved['day_cats'] = array();
			}
			/* سازگاری با نسخه‌های قدیمی: آن‌ها offset را مطلق ذخیره می‌کردند */
			if ( in_array( (int) $saved['offset'], array( -26, -30 ), true ) ) {
				$saved['offset'] = 0;
			}
			return $saved;
		}

		/** آیا این غذا در چرخه باشد؟ */
		public static function is_enabled( $name ) {
			$s = self::get();
			return ! empty( $s['enabled'][ $name ] );
		}

		/** فهرست غذاهای فعال، آماده برای جاوااسکریپت قالب */
		public static function js_payload() {
			$s    = self::get();
			$out  = array(
				'master' => (int) $s['master'],
				'percat' => max( 1, (int) $s['percat'] ),
				'size'   => max( 40, min( 200, (int) $s['size'] ) ),
				'offset' => (int) $s['offset'],
				'anchor' => sanitize_key( $s['anchor'] ),
				'dust'   => (int) $s['dust'],
				'drip'   => (int) $s['drip'],
				'list'   => array(),
			);
			foreach ( self::foods() as $cat => $info ) {
				foreach ( $info['items'] as $name ) {
					if ( self::is_enabled( $name ) ) {
						$out['list'][] = $name;
					}
				}
			}
			return $out;
		}

		/* ------------------------------------------------------------------
		 * ذخیره‌سازی
		 * --------------------------------------------------------------- */


		/** فقط برای تست: ذخیره بدون ریدایرکت */
		public static function handle_save_dry( $in ) {
			$new = self::defaults();
			$new['enabled'] = array();
			$on = isset( $in['enabled'] ) ? (array) $in['enabled'] : array();
			foreach ( self::foods() as $info ) {
				foreach ( $info['items'] as $name ) {
					if ( in_array( $name, $on, true ) ) { $new['enabled'][ $name ] = 1; }
				}
			}
			$new['master']    = empty( $in['master'] ) ? 0 : 1;
			$new['dust']      = empty( $in['dust'] ) ? 0 : 1;
			$new['drip']      = empty( $in['drip'] ) ? 0 : 1;
			$new['percat']    = max( 1, min( 60, (int) ( $in['percat'] ?? 20 ) ) );
			$new['size']      = max( 40, min( 200, (int) ( $in['size'] ?? 100 ) ) );
			$new['offset']    = max( -220, min( 220, (int) ( $in['offset'] ?? 0 ) ) );
			$new['anchor']    = sanitize_key( $in['anchor'] ?? 'roadmap' );
			$new['day_count'] = max( 1, min( 12, (int) ( $in['day_count'] ?? 4 ) ) );
			$new['day_hours'] = max( 1, min( 720, (int) ( $in['day_hours'] ?? 24 ) ) );
			$new['day_cats']  = array_values( isset( $in['day_cats'] ) ? (array) $in['day_cats'] : array() );
			update_option( self::OPT, $new );
			return $new;
		}

		/** فقط برای تست: درون‌ریزی بدون آپلود فایل */
		public static function import_dry( $json ) {
			$incoming = isset( $json['settings'] ) ? $json['settings'] : $json;
			$new = array_merge( self::defaults(), (array) $incoming );
			update_option( self::OPT, $new );
			return $new;
		}

		public static function handle_save() {
			if ( ! current_user_can( ASHP_Admin::CAP ) ) {
				wp_die( esc_html__( 'دسترسی ندارید.', 'ashpazbashi' ) );
			}
			check_admin_referer( 'ashp_save_foodsettings' );

			$in  = isset( $_POST['ashp'] ) ? (array) wp_unslash( $_POST['ashp'] ) : array();
			$new = self::defaults();

			/* غذاهای فعال */
			$new['enabled'] = array();
			$on             = isset( $in['enabled'] ) ? (array) $in['enabled'] : array();
			foreach ( self::foods() as $info ) {
				foreach ( $info['items'] as $name ) {
					if ( in_array( $name, $on, true ) ) {
						$new['enabled'][ $name ] = 1;
					}
				}
			}

			$new['master']    = empty( $in['master'] ) ? 0 : 1;
			$new['dust']      = empty( $in['dust'] ) ? 0 : 1;
			$new['drip']      = empty( $in['drip'] ) ? 0 : 1;
			$new['percat']    = max( 1, min( 60, (int) ( $in['percat'] ?? 20 ) ) );
			$new['size']      = max( 40, min( 200, (int) ( $in['size'] ?? 100 ) ) );
			$new['offset']    = max( -220, min( 220, (int) ( $in['offset'] ?? 0 ) ) );
			$new['anchor']    = sanitize_key( $in['anchor'] ?? 'roadmap' );
			$new['day_count'] = max( 1, min( 12, (int) ( $in['day_count'] ?? 4 ) ) );
			$new['day_hours'] = max( 1, min( 720, (int) ( $in['day_hours'] ?? 24 ) ) );

			$new['day_cats'] = array();
			$cats            = isset( $in['day_cats'] ) ? (array) $in['day_cats'] : array();
			foreach ( array_keys( self::home_cats() ) as $c ) {
				if ( in_array( $c, $cats, true ) ) {
					$new['day_cats'][] = $c;
				}
			}

			update_option( self::OPT, $new );

			/* غذای روز باید با تنظیمات تازه از نو ساخته شود */
			delete_option( 'ashp_today_cache' );

			wp_safe_redirect( add_query_arg( 'ashp-msg', 'saved', wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . ASHP_Admin::SLUG . '-food' ) ) );
			exit;
		}

		public static function handle_reset() {
			if ( ! current_user_can( ASHP_Admin::CAP ) ) {
				wp_die( esc_html__( 'دسترسی ندارید.', 'ashpazbashi' ) );
			}
			check_admin_referer( 'ashp_reset_foodsettings' );
			delete_option( self::OPT );
			delete_option( 'ashp_today_cache' );
			wp_safe_redirect( add_query_arg( 'ashp-msg', 'reset', wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . ASHP_Admin::SLUG . '-food' ) ) );
			exit;
		}

		/* ------------------------------------------------------------------
		 * برون‌بری و درون‌ریزی فایل تنظیمات (فایل دیتابیس)
		 * --------------------------------------------------------------- */

		public static function handle_export() {
			if ( ! current_user_can( ASHP_Admin::CAP ) ) {
				wp_die( esc_html__( 'دسترسی ندارید.', 'ashpazbashi' ) );
			}
			check_admin_referer( 'ashp_export_foodsettings' );

			$s    = self::get();
			$data = array(
				'plugin'    => 'ashpazbashi-core',
				'version'   => defined( 'ASHP_CORE_VER' ) ? ASHP_CORE_VER : '',
				'exported'  => current_time( 'mysql' ),
				'option'    => self::OPT,
				'settings'  => $s,
			);

			nocache_headers();
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=ashpazbashi-settings-' . gmdate( 'Ymd-His' ) . '.json' );
			echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
			exit;
		}

		public static function handle_import() {
			if ( ! current_user_can( ASHP_Admin::CAP ) ) {
				wp_die( esc_html__( 'دسترسی ندارید.', 'ashpazbashi' ) );
			}
			check_admin_referer( 'ashp_import_foodsettings' );

			$file = isset( $_FILES['ashp_file'] ) ? $_FILES['ashp_file'] : null; // phpcs:ignore
			if ( ! $file || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
				wp_safe_redirect( add_query_arg( 'ashp-msg', 'no_file', wp_get_referer() ) );
				exit;
			}

			$raw  = file_get_contents( $file['tmp_name'] ); // phpcs:ignore
			$json = json_decode( (string) $raw, true );
			if ( ! is_array( $json ) ) {
				wp_safe_redirect( add_query_arg( 'ashp-msg', 'bad_file', wp_get_referer() ) );
				exit;
			}
			$incoming = isset( $json['settings'] ) && is_array( $json['settings'] ) ? $json['settings'] : $json;

			$new = array_merge( self::defaults(), $incoming );
			if ( ! is_array( $new['enabled'] ) ) {
				$new['enabled'] = array();
			}
			if ( ! is_array( $new['day_cats'] ) ) {
				$new['day_cats'] = array();
			}
			update_option( self::OPT, $new );
			delete_option( 'ashp_today_cache' );

			wp_safe_redirect( add_query_arg( 'ashp-msg', 'imported', wp_get_referer() ) );
			exit;
		}

		/* ------------------------------------------------------------------
		 * هوک‌ها
		 * --------------------------------------------------------------- */

		public static function init() {
			add_action( 'admin_post_ashp_save_foodsettings', array( __CLASS__, 'handle_save' ) );
			add_action( 'admin_post_ashp_reset_foodsettings', array( __CLASS__, 'handle_reset' ) );
			add_action( 'admin_post_ashp_export_foodsettings', array( __CLASS__, 'handle_export' ) );
			add_action( 'admin_post_ashp_import_foodsettings', array( __CLASS__, 'handle_import' ) );
		}

		/* ------------------------------------------------------------------
		 * صفحهٔ مدیریت
		 * --------------------------------------------------------------- */

		public static function page() {
			if ( ! current_user_can( ASHP_Admin::CAP ) ) {
				return;
			}
			$s    = self::get();
			$msg  = isset( $_GET['ashp-msg'] ) ? sanitize_key( wp_unslash( $_GET['ashp-msg'] ) ) : '';
			$post = admin_url( 'admin-post.php' );

			$anchors = array(
				'roadmap' => __( 'وسط صفحه، بالای «آشپزباشی چگونه کار می‌کند؟»', 'ashpazbashi' ),
				'top'     => __( 'ابتدای محتوا (زیر هدر)', 'ashpazbashi' ),
				'hero'    => __( 'بعد از هیرو', 'ashpazbashi' ),
				'bottom'  => __( 'انتهای صفحه (بالای فوتر)', 'ashpazbashi' ),
			);
			$emoji = array(
				'iranian'   => '🍲',
				'fastfood'  => '🍔',
				'dessert'   => '🍰',
				'drink'     => '🥤',
				'appetizer' => '🥗',
				'seafood'   => '🐟',
				'kids'      => '🧒',
			);

			$total = 0;
			$on    = 0;
			foreach ( self::foods() as $info ) {
				foreach ( $info['items'] as $name ) {
					$total++;
					if ( ! empty( $s['enabled'][ $name ] ) ) {
						$on++;
					}
				}
			}
			$notes = array(
				'saved'    => array( 'ok', __( 'تنظیمات ذخیره شد و همین حالا روی سایت اعمال است.', 'ashpazbashi' ) ),
				'reset'    => array( 'ok', __( 'همه‌چیز به حالت پیش‌فرض برگشت.', 'ashpazbashi' ) ),
				'imported' => array( 'ok', __( 'فایل دیتابیس با موفقیت درون‌ریزی شد.', 'ashpazbashi' ) ),
				'bad_file' => array( 'err', __( 'آن فایل معتبر نبود؛ JSON خوانده نشد.', 'ashpazbashi' ) ),
				'no_file'  => array( 'err', __( 'هیچ فایلی انتخاب نشده بود.', 'ashpazbashi' ) ),
			);
			?>
			<div class="wrap ashp-admin">

				<div class="ashp-hero">
					<div class="ashp-hero__brand">
						<div>
							<h1 class="ashp-hero__name"><?php esc_html_e( 'انیمیشن غذا و پیشنهادهای روز', 'ashpazbashi' ); ?></h1>
							<p class="ashp-hero__tag"><?php esc_html_e( 'با هر بازدید، یک غذا از بالا داخل صفحه می‌افتد: یک‌بار ایرانی، بار بعد فست‌فود، بعد دسر و… . هرچه اینجا عوض کنی، بلافاصله روی سایت اعمال می‌شود.', 'ashpazbashi' ); ?></p>
						</div>
					</div>
					<div class="ashp-hero__stats">
						<div class="ashp-hero__stat"><b data-ashp-fs-kpi="on"><?php echo esc_html( number_format_i18n( $on ) ); ?></b><span><?php esc_html_e( 'غذای فعال', 'ashpazbashi' ); ?></span></div>
						<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( $total ) ); ?></b><span><?php esc_html_e( 'غذای موجود', 'ashpazbashi' ); ?></span></div>
						<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( (int) $s['percat'] ) ); ?></b><span><?php esc_html_e( 'انیمیشن هر دسته', 'ashpazbashi' ); ?></span></div>
						<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( (int) $s['size'] ) ); ?>٪</b><span><?php esc_html_e( 'اندازهٔ غذا', 'ashpazbashi' ); ?></span></div>
					</div>
				</div>

				<?php if ( isset( $notes[ $msg ] ) ) : ?>
					<div class="ashp-msg ashp-msg--<?php echo esc_attr( $notes[ $msg ][0] ); ?>"><?php echo esc_html( $notes[ $msg ][1] ); ?></div>
				<?php endif; ?>

				<?php if ( empty( $s['master'] ) ) : ?>
					<div class="ashp-msg ashp-msg--warn"><?php esc_html_e( 'انیمیشن بارش غذا الان خاموش است؛ هیچ غذایی روی سایت نمی‌افتد.', 'ashpazbashi' ); ?></div>
				<?php endif; ?>

				<form id="ashp-fs-form" method="post" action="<?php echo esc_url( $post ); ?>" data-ashp-fs-form>
					<input type="hidden" name="action" value="ashp_save_foodsettings">
					<?php wp_nonce_field( 'ashp_save_foodsettings' ); ?>

					<div class="ashp-grid2">

						<!-- وضعیت انیمیشن -->
						<div class="ashp-card">
							<h2 class="ashp-fs__h"><?php esc_html_e( 'وضعیت انیمیشن', 'ashpazbashi' ); ?></h2>

							<label class="ashp-fs__row ashp-switch">
								<input type="checkbox" name="ashp[master]" value="1" <?php checked( ! empty( $s['master'] ) ); ?>>
								<span class="ashp-switch__ui" aria-hidden="true"></span>
								<span class="ashp-fs__rowtxt">
									<b><?php esc_html_e( 'بارش غذا فعال باشد', 'ashpazbashi' ); ?></b>
									<i><?php esc_html_e( 'کلیدی‌ترین گزینه؛ اگر خاموش شود هیچ غذایی نمی‌افتد.', 'ashpazbashi' ); ?></i>
								</span>
							</label>

							<label class="ashp-fs__row ashp-switch">
								<input type="checkbox" name="ashp[dust]" value="1" <?php checked( ! empty( $s['dust'] ) ); ?>>
								<span class="ashp-switch__ui" aria-hidden="true"></span>
								<span class="ashp-fs__rowtxt">
									<b><?php esc_html_e( 'گرد و خاک هنگام فرود', 'ashpazbashi' ); ?></b>
									<i><?php esc_html_e( 'موقع نشستن غذا روی خط زمین.', 'ashpazbashi' ); ?></i>
								</span>
							</label>

							<label class="ashp-fs__row ashp-switch">
								<input type="checkbox" name="ashp[drip]" value="1" <?php checked( ! empty( $s['drip'] ) ); ?>>
								<span class="ashp-switch__ui" aria-hidden="true"></span>
								<span class="ashp-fs__rowtxt">
									<b><?php esc_html_e( 'چکیدن سس', 'ashpazbashi' ); ?></b>
									<i><?php esc_html_e( 'قطره‌های سس از پای غذا می‌چکد.', 'ashpazbashi' ); ?></i>
								</span>
							</label>
						</div>

						<!-- اندازه و جای درج -->
						<div class="ashp-card">
							<h2 class="ashp-fs__h"><?php esc_html_e( 'اندازه، جای درج و جابه‌جایی', 'ashpazbashi' ); ?></h2>

							<div class="ashp-field">
								<label for="ashp-anchor"><?php esc_html_e( 'جای درج صحنه', 'ashpazbashi' ); ?></label>
								<select id="ashp-anchor" name="ashp[anchor]">
									<?php foreach ( $anchors as $k => $lbl ) : ?>
										<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['anchor'], $k ); ?>><?php echo esc_html( $lbl ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>

							<div class="ashp-field">
								<label for="ashp-size"><?php esc_html_e( 'اندازه', 'ashpazbashi' ); ?></label>
								<div class="ashp-fs__range">
									<input type="range" min="40" max="200" step="5" value="<?php echo esc_attr( (int) $s['size'] ); ?>" data-ashp-fs-range="size" aria-label="<?php esc_attr_e( 'اندازه', 'ashpazbashi' ); ?>">
									<input id="ashp-size" type="number" min="40" max="200" step="5" name="ashp[size]" value="<?php echo esc_attr( (int) $s['size'] ); ?>" data-ashp-fs-num="size" class="small-text">
									<output data-ashp-fs-out="size"><?php echo esc_html( number_format_i18n( (int) $s['size'] ) ); ?>٪</output>
								</div>
							</div>

							<div class="ashp-field">
								<label for="ashp-offset"><?php esc_html_e( 'بالاتر / پایین‌تر', 'ashpazbashi' ); ?></label>
								<div class="ashp-fs__range">
									<input type="range" min="-220" max="220" step="2" value="<?php echo esc_attr( (int) $s['offset'] ); ?>" data-ashp-fs-range="offset" aria-label="<?php esc_attr_e( 'بالاتر یا پایین‌تر', 'ashpazbashi' ); ?>">
									<input id="ashp-offset" type="number" min="-220" max="220" step="2" name="ashp[offset]" value="<?php echo esc_attr( (int) $s['offset'] ); ?>" data-ashp-fs-num="offset" class="small-text">
									<output data-ashp-fs-out="offset"><?php echo esc_html( (int) $s['offset'] ); ?> px</output>
								</div>
								<span class="ashp-help"><?php esc_html_e( '۰ = همان جای تنظیم‌شدهٔ وسط صفحه. عدد منفی = بالاتر.', 'ashpazbashi' ); ?></span>
							</div>

							<div class="ashp-field">
								<label for="ashp-percat"><?php esc_html_e( 'تعداد انیمیشن هر دسته', 'ashpazbashi' ); ?></label>
								<input id="ashp-percat" type="number" min="1" max="60" name="ashp[percat]" value="<?php echo esc_attr( (int) $s['percat'] ); ?>" class="small-text">
								<span class="ashp-help"><?php esc_html_e( 'چند سبک مختلف افتادن برای هر دسته ساخته شود (پیش‌فرض ۲۰).', 'ashpazbashi' ); ?></span>
							</div>
						</div>
					</div>

					<!-- غذاهای چرخه -->
					<div class="ashp-card ashp-fs__card">
						<h2 class="ashp-fs__h">
							<?php esc_html_e( 'غذاهای چرخه', 'ashpazbashi' ); ?>
							<span class="ashp-fs__bulk">
								<button type="button" class="ashp-btn ashp-btn--sm" data-ashp-fs-all="1"><?php esc_html_e( 'انتخاب همه', 'ashpazbashi' ); ?></button>
								<button type="button" class="ashp-btn ashp-btn--sm" data-ashp-fs-all="0"><?php esc_html_e( 'هیچ‌کدام', 'ashpazbashi' ); ?></button>
							</span>
						</h2>
						<span class="ashp-help"><?php esc_html_e( 'تیک هر غذا را برداری، آن غذا از چرخهٔ بارش حذف می‌شود.', 'ashpazbashi' ); ?></span>

						<div class="ashp-fs__groups">
							<?php foreach ( self::foods() as $cat => $info ) : ?>
								<div class="ashp-fs__group" data-ashp-fs-group>
									<div class="ashp-fs__ghead">
										<span class="ashp-fs__gname">
											<?php echo esc_html( isset( $emoji[ $cat ] ) ? $emoji[ $cat ] : '🍴' ); ?>
											<?php echo esc_html( $info['label'] ); ?>
										</span>
										<span class="ashp-fs__gn" data-ashp-fs-groupn></span>
										<span class="ashp-fs__gbtns">
											<button type="button" class="ashp-btn ashp-btn--sm" data-ashp-fs-cat="1"><?php esc_html_e( 'همه', 'ashpazbashi' ); ?></button>
											<button type="button" class="ashp-btn ashp-btn--sm" data-ashp-fs-cat="0"><?php esc_html_e( 'هیچ‌کدام', 'ashpazbashi' ); ?></button>
										</span>
									</div>
									<div class="ashp-fs__grid">
										<?php foreach ( $info['items'] as $name ) : ?>
											<label class="ashp-fs__item ashp-switch<?php echo empty( $s['enabled'][ $name ] ) ? ' is-off' : ''; ?>">
												<input type="checkbox" name="ashp[enabled][]" value="<?php echo esc_attr( $name ); ?>" <?php checked( ! empty( $s['enabled'][ $name ] ) ); ?>>
												<span class="ashp-switch__ui" aria-hidden="true"></span>
												<span class="ashp-fs__itemname"><?php echo esc_html( $name ); ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>

					<!-- غذای روز و پیشنهادی -->
					<div class="ashp-card ashp-fs__card">
						<h2 class="ashp-fs__h"><?php esc_html_e( 'غذای روز و پیشنهادی', 'ashpazbashi' ); ?></h2>
						<span class="ashp-help"><?php esc_html_e( 'انتخاب کن پیشنهادهای صفحهٔ اصلی از کدام دسته‌ها بیایند و چند وقت یک‌بار عوض شوند.', 'ashpazbashi' ); ?></span>

						<div class="ashp-fs__grid ashp-fs__grid--cats">
							<?php foreach ( self::home_cats() as $c => $lbl ) : ?>
								<label class="ashp-fs__item ashp-switch">
									<input type="checkbox" name="ashp[day_cats][]" value="<?php echo esc_attr( $c ); ?>" <?php checked( in_array( $c, (array) $s['day_cats'], true ) ); ?>>
									<span class="ashp-switch__ui" aria-hidden="true"></span>
									<span class="ashp-fs__itemname"><?php echo esc_html( $lbl ); ?></span>
								</label>
							<?php endforeach; ?>
						</div>

						<div class="ashp-grid2 ashp-fs__daynums">
							<div class="ashp-field">
								<label for="ashp-daycount"><?php esc_html_e( 'تعداد در هر دسته', 'ashpazbashi' ); ?></label>
								<input id="ashp-daycount" type="number" min="1" max="12" name="ashp[day_count]" value="<?php echo esc_attr( (int) $s['day_count'] ); ?>" class="small-text">
								<span class="ashp-help"><?php esc_html_e( 'چند دستور از هر دسته پیشنهاد شود.', 'ashpazbashi' ); ?></span>
							</div>
							<div class="ashp-field">
								<label for="ashp-dayhours"><?php esc_html_e( 'چرخش هر چند ساعت', 'ashpazbashi' ); ?></label>
								<input id="ashp-dayhours" type="number" min="1" max="720" name="ashp[day_hours]" value="<?php echo esc_attr( (int) $s['day_hours'] ); ?>" class="small-text">
								<span class="ashp-help"><?php esc_html_e( 'پیش‌فرض ۲۴ ساعت؛ عدد کمتر = پیشنهاد تازه‌تر.', 'ashpazbashi' ); ?></span>
							</div>
						</div>
					</div>

					<div class="ashp-fs__save" data-ashp-fs-savebar>
						<span class="ashp-fs__savetxt" data-ashp-fs-savetxt data-clean="<?php echo esc_attr( __( 'تنظیمات روی سایت اعمال شده است.', 'ashpazbashi' ) ); ?>" data-dirty="<?php echo esc_attr( __( 'تغییرات ذخیره‌نشده داری — دکمهٔ «ذخیرهٔ تنظیمات» را بزن.', 'ashpazbashi' ) ); ?>"><?php esc_html_e( 'تنظیمات روی سایت اعمال شده است.', 'ashpazbashi' ); ?></span>
						<button class="ashp-btn ashp-btn--primary" type="submit"><?php esc_html_e( 'ذخیرهٔ تنظیمات', 'ashpazbashi' ); ?></button>
					</div>
				</form>

				<!-- فایل دیتابیس -->
				<div class="ashp-card ashp-fs__card">
					<h2 class="ashp-fs__h"><?php esc_html_e( 'فایل دیتابیس تنظیمات', 'ashpazbashi' ); ?></h2>
					<span class="ashp-help"><?php esc_html_e( 'همهٔ این تنظیمات در جدول options وردپرس ذخیره می‌شود. با دکمهٔ زیر یک فایل JSON می‌گیری که می‌توانی نگه داری، ویرایش کنی یا روی سایت دیگری درون‌ریزی کنی.', 'ashpazbashi' ); ?></span>

					<div class="ashp-fs__db">
						<form method="post" action="<?php echo esc_url( $post ); ?>">
							<input type="hidden" name="action" value="ashp_export_foodsettings">
							<?php wp_nonce_field( 'ashp_export_foodsettings' ); ?>
							<button class="ashp-btn" type="submit">⬇ <?php esc_html_e( 'دریافت فایل تنظیمات', 'ashpazbashi' ); ?></button>
						</form>

						<form method="post" action="<?php echo esc_url( $post ); ?>" enctype="multipart/form-data">
							<input type="hidden" name="action" value="ashp_import_foodsettings">
							<?php wp_nonce_field( 'ashp_import_foodsettings' ); ?>
							<label class="ashp-fs__file">
								<span><?php esc_html_e( 'فایل JSON', 'ashpazbashi' ); ?></span>
								<input type="file" name="ashp_file" accept=".json,application/json" required>
							</label>
							<button class="ashp-btn" type="submit">⬆ <?php esc_html_e( 'درون‌ریزی', 'ashpazbashi' ); ?></button>
						</form>

						<form method="post" action="<?php echo esc_url( $post ); ?>" data-ashp-confirm="<?php echo esc_attr( __( 'همهٔ تنظیمات به حالت پیش‌فرض برگردد؟', 'ashpazbashi' ) ); ?>">
							<input type="hidden" name="action" value="ashp_reset_foodsettings">
							<?php wp_nonce_field( 'ashp_reset_foodsettings' ); ?>
							<button class="ashp-btn ashp-btn--danger" type="submit"><?php esc_html_e( 'بازگشت به پیش‌فرض', 'ashpazbashi' ); ?></button>
						</form>
					</div>
				</div>

			</div>
			<?php
		}
	}
}
