<?php
/**
 * ورود دادهٔ آمادهٔ آشپزباشی به جدول‌های وردپرس (MySQL).
 *
 * دادهٔ منبع در پوشهٔ data/ افزونه به‌صورت CSV قرار دارد:
 *   recipes.csv            — یک ردیف برای هر دستور پخت (۲۰ ستون)
 *   ingredients.csv        — یک ردیف برای هر مادهٔ اولیه (۵ ستون)
 *   recipe_ingredients.csv — ارتباط دستور ↔ ماده (۸ ستون)
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Importer' ) ) {

class ASHP_Importer {

	const BATCH = 400;

	/** ستون‌های recipes.csv، به همان ترتیب فایل */
	const RECIPE_COLS = array(
		'name', 'slug', 'category', 'subcategory', 'cuisine', 'meal', 'suitable_for',
		'servings', 'prep_time_min', 'cook_time_min', 'difficulty', 'cooking_method',
		'instructions', 'instructions_status', 'calories_kcal', 'image_url',
		'source_dataset', 'source_row', 'completeness', 'is_active',
		'is_halal', 'halal_note', 'kid_ok', 'party_ok',
		'province', 'country',
	);

	const INGREDIENT_COLS = array( 'name', 'slug', 'normalized_name', 'group_key', 'recipes_count' );

	const RELATION_COLS = array(
		'recipe_slug', 'ingredient_normalized', 'amount_value', 'amount_text',
		'unit', 'is_main', 'amount_is_free', 'sort_order',
	);

	/**
	 * مسیر پوشهٔ داده.
	 *
	 * داده‌ها همراه خود افزونه هستند (data/*.csv). اگر برای سازگاری با نسخه‌های
	 * قدیمی، داده داخل قالب باشد، همان مسیر هم بررسی می‌شود.
	 */
	public static function data_dir() {
		/*
		 * اگر افزونهٔ «آشپزباشی — داده‌ها» نصب باشد، داده از آن خوانده می‌شود تا
		 * به‌روزرسانی داده و به‌روزرسانی کد مستقل از هم باشند.
		 */
		$custom = apply_filters( 'ashp_data_dir', '' );
		if ( $custom && ( file_exists( $custom . 'recipes.csv' ) || file_exists( $custom . 'ingredients.csv' ) ) ) {
			return trailingslashit( $custom );
		}

		$plugin_dir = ASHP_CORE_DIR . 'data/';
		if ( file_exists( $plugin_dir . 'recipes.csv' ) || file_exists( $plugin_dir . 'ingredients.csv' ) ) {
			return $plugin_dir;
		}

		$theme_dir = trailingslashit( get_template_directory() ) . 'data/';
		if ( file_exists( $theme_dir . 'recipes.csv' ) ) {
			return $theme_dir;
		}

		return $plugin_dir;
	}

	/** نشانی خوانا برای نمایش در پنل */
	public static function data_dir_label() {
		$dir = self::data_dir();
		if ( 0 === strpos( $dir, ASHP_CORE_DIR ) ) {
			return 'افزونه: ' . str_replace( ABSPATH, '', $dir );
		}
		return 'قالب: ' . str_replace( ABSPATH, '', $dir );
	}

	/** بررسی وجود فایل‌های داده */
	public static function data_files_status() {
		$files = array( 'recipes.csv', 'ingredients.csv', 'recipe_ingredients.csv' );
		$out   = array();
		foreach ( $files as $f ) {
			$path      = self::data_dir() . $f;
			$out[ $f ] = array(
				'exists' => file_exists( $path ),
				'size'   => file_exists( $path ) ? (int) filesize( $path ) : 0,
			);
		}
		return $out;
	}

	/**
	 * ساخت یک قطعهٔ VALUES با escape کامل و پشتیبانی از NULL واقعی.
	 *
	 * @param array $values مقادیر (null یعنی NULL در SQL).
	 * @return string
	 */
	private static function values_sql( array $values ) {
		global $wpdb;
		$parts = array();
		foreach ( $values as $v ) {
			if ( null === $v ) {
				$parts[] = 'NULL';
			} elseif ( is_int( $v ) ) {
				$parts[] = $wpdb->prepare( '%d', $v );
			} elseif ( is_float( $v ) ) {
				$parts[] = $wpdb->prepare( '%f', $v );
			} else {
				/* رشته‌های عددی هم به‌صورت رشته فرستاده می‌شوند تا MySQL خودش
				   آن‌ها را به نوع ستون (DECIMAL/INT) تبدیل کند. */
				$parts[] = $wpdb->prepare( '%s', (string) $v );
			}
		}
		return '(' . implode( ', ', $parts ) . ')';
	}

	/**
	 * اجرای کامل ورود داده.
	 *
	 * @param bool $fresh اگر true باشد، جدول‌ها ابتدا خالی می‌شوند.
	 * @return array گزارش
	 */
	public static function run( $fresh = true ) {
		global $wpdb;

		@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		@ini_set( 'memory_limit', '512M' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		$report = array(
			'recipes'     => 0,
			'ingredients' => 0,
			'relations'   => 0,
			'errors'      => array(),
			'seconds'     => 0,
		);

		$start = microtime( true );

		if ( $fresh ) {
			$wpdb->query( 'TRUNCATE TABLE ' . ASHP_DB::t( 'recipe_ingredients' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->query( 'TRUNCATE TABLE ' . ASHP_DB::t( 'recipes' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->query( 'TRUNCATE TABLE ' . ASHP_DB::t( 'ingredients' ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}

		$report['ingredients'] = self::import_ingredients( $report['errors'] );
		$report['recipes']     = self::import_recipes( $report['errors'] );

		$slug_to_id  = self::ingredient_lookup();
		$recipe_slug = self::recipe_lookup();

		$report['relations'] = self::import_relations( $slug_to_id, $recipe_slug, $report['errors'] );

		self::refresh_ingredient_counts();
		ASHP_DB::flush_cache();

		$report['seconds'] = round( microtime( true ) - $start, 2 );
		update_option( 'ashp_last_import', array_merge( $report, array( 'time' => current_time( 'mysql' ) ) ), false );

		return $report;
	}

	/** باز کردن یک فایل CSV با هدر */
	private static function open_csv( $filename, $expected_cols ) {
		$path = self::data_dir() . $filename;
		if ( ! file_exists( $path ) ) {
			return array( null, null, sprintf( 'فایل %s پیدا نشد.', $filename ) );
		}

		$fh = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			return array( null, null, sprintf( 'فایل %s باز نشد.', $filename ) );
		}

		$head = fgetcsv( $fh, 0, ',', '"', '\\' );
		if ( ! is_array( $head ) ) {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( null, null, sprintf( 'هدر %s خوانده نشد.', $filename ) );
		}

		if ( count( $head ) !== $expected_cols ) {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( null, null, sprintf( '%s باید %d ستون داشته باشد، %d ستون دارد.', $filename, $expected_cols, count( $head ) ) );
		}

		return array( $fh, $head, null );
	}

	/** کلیدهای عددی مواد اولیه بر پایهٔ نام نرمال‌شده */
	private static function ingredient_lookup() {
		global $wpdb;
		$ing  = ASHP_DB::t( 'ingredients' );
		$rows = $wpdb->get_results( "SELECT id, normalized_name FROM $ing", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$map  = array();
		foreach ( (array) $rows as $r ) {
			$map[ (string) $r['normalized_name'] ] = (int) $r['id'];
		}
		return $map;
	}

	/** نقشهٔ slug دستور → شناسه */
	private static function recipe_lookup() {
		global $wpdb;
		$recipes = ASHP_DB::t( 'recipes' );
		$rows    = $wpdb->get_results( "SELECT id, slug FROM $recipes", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$map     = array();
		foreach ( (array) $rows as $r ) {
			$map[ (string) $r['slug'] ] = (int) $r['id'];
		}
		return $map;
	}

	/** ورود مواد اولیه */
	private static function import_ingredients( &$errors ) {
		$cols = count( self::INGREDIENT_COLS );
		list( $fh, $head, $err ) = self::open_csv( 'ingredients.csv', $cols );
		if ( $err ) {
			$errors[] = $err;
			return 0;
		}

		global $wpdb;
		$table = ASHP_DB::t( 'ingredients' );
		$count = 0;
		$batch = array();

		while ( ( $row = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) {
			if ( count( $row ) !== $cols ) {
				continue;
			}
			$d       = array_combine( self::INGREDIENT_COLS, $row );
			$batch[] = self::values_sql( array(
				(string) $d['name'],
				(string) $d['slug'],
				(string) $d['normalized_name'],
				(string) $d['group_key'],
				(int) $d['recipes_count'],
			) );
			if ( count( $batch ) >= self::BATCH ) {
				$count += self::flush( $table, '(name, slug, normalized_name, group_key, recipes_count)', $batch, true );
			}
		}
		$count += self::flush( $table, '(name, slug, normalized_name, group_key, recipes_count)', $batch, true );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $count;
	}

	/** ورود دستورها */
	private static function import_recipes( &$errors ) {
		$cols = count( self::RECIPE_COLS );
		list( $fh, $head, $err ) = self::open_csv( 'recipes.csv', $cols );
		if ( $err ) {
			$errors[] = $err;
			return 0;
		}

		global $wpdb;
		$table     = ASHP_DB::t( 'recipes' );
		$count     = 0;
		$batch     = array();
		$now       = current_time( 'mysql' );

		$columns = '(name, slug, category, subcategory, cuisine, meal, suitable_for, servings,
			prep_time_min, cook_time_min, difficulty, cooking_method, instructions, instructions_status,
			calories_kcal, image_url, source_dataset, source_row, completeness, is_active,
			is_halal, halal_note, kid_ok, party_ok, province, country, created_at)';

		while ( ( $row = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) {
			if ( count( $row ) !== $cols ) {
				continue;
			}
			$d = array_combine( self::RECIPE_COLS, $row );

			$batch[] = self::values_sql( array(
				(string) $d['name'],
				(string) $d['slug'],
				(string) $d['category'],
				(string) $d['subcategory'],
				(string) $d['cuisine'],
				(string) $d['meal'],
				(string) $d['suitable_for'],
				self::int_or_null( $d['servings'] ),
				self::float_or_null( $d['prep_time_min'] ),
				self::float_or_null( $d['cook_time_min'] ),
				(string) $d['difficulty'],
				(string) $d['cooking_method'],
				(string) $d['instructions'],
				(string) $d['instructions_status'],
				self::float_or_null( $d['calories_kcal'] ),
				(string) $d['image_url'],
				(string) $d['source_dataset'],
				self::int_or_null( $d['source_row'] ),
				(string) $d['completeness'],
				(int) $d['is_active'],
				self::int_or_null( $d['is_halal'] ),
				(string) $d['halal_note'],
				(int) $d['kid_ok'],
				(int) $d['party_ok'],
				(string) $d['province'],
				(string) $d['country'],
				$now,
			) );

			if ( count( $batch ) >= self::BATCH ) {
				$count += self::flush( $table, $columns, $batch, true );
			}
		}
		$count += self::flush( $table, $columns, $batch, true );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $count;
	}

	/** ورود ارتباط دستور ↔ مادهٔ اولیه */
	private static function import_relations( $ing_map, $recipe_map, &$errors ) {
		$cols = count( self::RELATION_COLS );
		list( $fh, $head, $err ) = self::open_csv( 'recipe_ingredients.csv', $cols );
		if ( $err ) {
			$errors[] = $err;
			return 0;
		}

		global $wpdb;
		$table = ASHP_DB::t( 'recipe_ingredients' );
		$count = 0;
		$batch = array();
		$skipped = 0;

		$columns = '(recipe_id, ingredient_id, amount_value, amount_text, unit, is_main, amount_is_free, sort_order)';

		while ( ( $row = fgetcsv( $fh, 0, ',', '"', '\\' ) ) !== false ) {
			if ( count( $row ) !== $cols ) {
				continue;
			}
			$d = array_combine( self::RELATION_COLS, $row );

			$rid = isset( $recipe_map[ $d['recipe_slug'] ] ) ? (int) $recipe_map[ $d['recipe_slug'] ] : 0;
			$iid = isset( $ing_map[ $d['ingredient_normalized'] ] ) ? (int) $ing_map[ $d['ingredient_normalized'] ] : 0;
			if ( ! $rid || ! $iid ) {
				$skipped++;
				continue;
			}

			$batch[] = self::values_sql( array(
				$rid,
				$iid,
				self::float_or_null( $d['amount_value'] ),
				(string) $d['amount_text'],
				(string) $d['unit'],
				(int) $d['is_main'],
				(int) $d['amount_is_free'],
				(int) $d['sort_order'],
			) );

			if ( count( $batch ) >= self::BATCH ) {
				$count += self::flush( $table, $columns, $batch, false );
			}
		}
		$count += self::flush( $table, $columns, $batch, false );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( $skipped > 0 ) {
			$errors[] = sprintf( '%d ارتباط به‌دلیل نبود دستور یا مادهٔ متناظر رد شد.', $skipped );
		}
		if ( $count < 1 ) {
			$errors[] = 'هیچ ارتباطی بین دستور و مادهٔ اولیه برقرار نشد.';
		}
		return $count;
	}

	/** اجرای یک دستهٔ INSERT */
	private static function flush( $table, $columns, &$batch, $ignore ) {
		if ( empty( $batch ) ) {
			return 0;
		}
		global $wpdb;
		$verb = $ignore ? 'INSERT IGNORE' : 'INSERT';
		$n    = (int) $wpdb->query( $verb . ' INTO ' . $table . ' ' . $columns . ' VALUES ' . implode( ',', $batch ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$batch = array();
		return $n;
	}

	private static function int_or_null( $value ) {
		$value = trim( (string) $value );
		return ( '' === $value ) ? null : (int) $value;
	}

	private static function float_or_null( $value ) {
		$value = trim( (string) $value );
		return ( '' === $value ) ? null : (float) $value;
	}

	/** شمارش تعداد دستور برای هر مادهٔ اولیه */
	public static function refresh_ingredient_counts() {
		global $wpdb;
		$ing = ASHP_DB::t( 'ingredients' );
		$rel = ASHP_DB::t( 'recipe_ingredients' );
		$wpdb->query( "UPDATE $ing SET recipes_count = 0" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->query(
			"UPDATE $ing i
			 SET recipes_count = (
				SELECT COUNT(DISTINCT ri.recipe_id) FROM $rel ri WHERE ri.ingredient_id = i.id
			 )" // phpcs:ignore WordPress.DB.PreparedSQL
		);
		ASHP_DB::flush_cache();
	}
}

}
