<?php
/**
 * پنل مدیریت آشپزباشی — هم‌رنگ با برند سایت.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Admin' ) ) {

class ASHP_Admin {

	const CAP  = 'manage_options';
	const SLUG = 'ashpazbashi';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_action( 'admin_post_ashp_save_recipe', array( __CLASS__, 'handle_save_recipe' ) );
		add_action( 'admin_post_ashp_save_pages', array( __CLASS__, 'handle_save_pages' ) );
		add_action( 'admin_post_ashp_delete_recipe', array( __CLASS__, 'handle_delete_recipe' ) );
		add_action( 'admin_post_ashp_toggle_recipe', array( __CLASS__, 'handle_toggle_recipe' ) );
		add_action( 'admin_post_ashp_save_ingredient', array( __CLASS__, 'handle_save_ingredient' ) );
		add_action( 'admin_post_ashp_delete_ingredient', array( __CLASS__, 'handle_delete_ingredient' ) );
		add_action( 'admin_post_ashp_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_ashp_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_ashp_recount', array( __CLASS__, 'handle_recount' ) );
		add_action( 'admin_post_ashp_flush_rules', array( __CLASS__, 'handle_flush_rules' ) );
		add_action( 'admin_post_ashp_rebuild_tables', array( __CLASS__, 'handle_rebuild_tables' ) );
	}

	/* =====================================================================
	 * منو و دارایی‌ها
	 * ================================================================== */

	public static function page_food() {
		ASHP_FoodSettings::page();
	}

	public static function menu() {
		add_menu_page(
			__( 'آشپزباشی', 'ashpazbashi' ),
			__( 'آشپزباشی', 'ashpazbashi' ),
			self::CAP,
			self::SLUG,
			array( __CLASS__, 'page_dashboard' ),
			self::menu_icon(),
			26
		);

		$subs = array(
			'dashboard'   => array( __( 'داشبورد', 'ashpazbashi' ), 'page_dashboard' ),
			'recipes'     => array( __( 'همهٔ غذاها', 'ashpazbashi' ), 'page_recipes' ),
			'recipe-new'  => array( __( 'افزودن غذا', 'ashpazbashi' ), 'page_recipe_edit' ),
			'ingredients' => array( __( 'مواد اولیه', 'ashpazbashi' ), 'page_ingredients' ),
			'categories'  => array( __( 'دسته‌بندی‌ها', 'ashpazbashi' ), 'page_categories' ),
			'pages'       => array( __( 'صفحه‌ها', 'ashpazbashi' ), 'page_pages' ),
			'data'        => array( __( 'داده‌ها', 'ashpazbashi' ), 'page_data' ),
			'food'        => array( __( 'انیمیشن غذا', 'ashpazbashi' ), 'page_food' ),
			'health'      => array( __( 'تست سلامت', 'ashpazbashi' ), 'page_health' ),
		);

		foreach ( $subs as $key => $info ) {
			add_submenu_page(
				self::SLUG,
				$info[0],
				$info[0],
				self::CAP,
				'dashboard' === $key ? self::SLUG : self::SLUG . '-' . $key,
				array( __CLASS__, $info[1] )
			);
		}
	}

	/** آیکون منو با رنگ برند آشپزباشی */
	private static function menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
			. 'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'
			. '<path d="M3 11h18a9 9 0 0 1-9 9 9 9 0 0 1-9-9Z"/>'
			. '<path d="M8 11c0-3 1.6-5 4-7 2.4 2 4 4 4 7"/>'
			. '<path d="M12 4V2"/></svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'ashp-admin', ASHP_CORE_URL . 'assets/admin.css', array(), ASHP_CORE_VER );
		wp_enqueue_script( 'ashp-admin', ASHP_CORE_URL . 'assets/admin.js', array(), ASHP_CORE_VER, true );

		$subs = array();
		foreach ( ASHP_DB::taxonomy() as $slug => $info ) {
			$subs[ $slug ] = $info['subs'];
		}

		wp_localize_script( 'ashp-admin', 'ASHP_ADMIN', array(
			'subs' => $subs,
			'i18n' => array(
				'confirmDelete'   => __( 'این مورد برای همیشه حذف شود؟', 'ashpazbashi' ),
				'confirmImport'   => __( 'جدول‌ها خالی و از نو پر می‌شوند. مطمئن هستید؟', 'ashpazbashi' ),
				'confirmRecount'  => __( 'تعداد مواد اولیه بازشماری شود؟', 'ashpazbashi' ),
			),
		) );
	}

	/** رنگ‌های برند — از سفارشی‌ساز قالب خوانده می‌شود */
	private static function brand() {
		return array(
			'neon'  => get_theme_mod( 'ashp_neon_1', '#00f5d4' ),
			'neon2' => get_theme_mod( 'ashp_neon_2', '#ff2e97' ),
			'neon3' => get_theme_mod( 'ashp_neon_3', '#7b2ff7' ),
			'name'  => defined( 'ASHP_SITE_NAME' ) ? ASHP_SITE_NAME : get_bloginfo( 'name' ),
			'tag'   => defined( 'ASHP_TAGLINE' ) ? ASHP_TAGLINE : get_bloginfo( 'description' ),
			'logo'  => get_template_directory_uri() . '/assets/img/logo.png',
		);
	}

	/** آدرس یک صفحهٔ پنل */
	private static function url( $page, $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG . ( 'dashboard' === $page ? '' : '-' . $page ) ), $args ), admin_url( 'admin.php' ) );
	}

	/* =====================================================================
	 * اجزای مشترک رابط
	 * ================================================================== */

	private static function hero( $active = 'dashboard' ) {
		$b     = self::brand();
		$c     = ASHP_DB::counts();
		$halal = (int) ASHP_DB::count_halal();

		$tabs = array(
			'dashboard'   => array( '📊', __( 'داشبورد', 'ashpazbashi' ), '' ),
			'recipes'     => array( '🍲', __( 'همهٔ غذاها', 'ashpazbashi' ), number_format_i18n( $c['recipes'] ) ),
			'recipe-new'  => array( '➕', __( 'افزودن غذا', 'ashpazbashi' ), '' ),
			'ingredients' => array( '🧂', __( 'مواد اولیه', 'ashpazbashi' ), number_format_i18n( $c['ingredients'] ) ),
			'categories'  => array( '🗂', __( 'دسته‌بندی‌ها', 'ashpazbashi' ), number_format_i18n( count( ASHP_DB::taxonomy() ) ) ),
			'pages'       => array( '📝', __( 'صفحه‌ها', 'ashpazbashi' ), '' ),
			'data'        => array( '💾', __( 'داده‌ها', 'ashpazbashi' ), '' ),
		);
		?>
		<div class="ashp-admin">
			<div class="ashp-hero">
				<div class="ashp-hero__brand">
					<img class="ashp-hero__logo" src="<?php echo esc_url( $b['logo'] ); ?>" alt="">
					<div>
						<h1 class="ashp-hero__name"><?php echo esc_html( $b['name'] ); ?></h1>
						<p class="ashp-hero__tag"><?php echo esc_html( $b['tag'] ); ?></p>
					</div>
				</div>
				<div class="ashp-hero__stats">
					<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( $c['recipes'] ) ); ?></b><span><?php esc_html_e( 'غذا', 'ashpazbashi' ); ?></span></div>
					<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( $c['ingredients'] ) ); ?></b><span><?php esc_html_e( 'مادهٔ اولیه', 'ashpazbashi' ); ?></span></div>
					<div class="ashp-hero__stat"><b><?php echo esc_html( number_format_i18n( $halal ) ); ?></b><span><?php esc_html_e( 'حلال', 'ashpazbashi' ); ?></span></div>
				</div>
			</div>

			<nav class="ashp-tabs">
				<?php foreach ( $tabs as $key => $t ) : ?>
					<a class="ashp-tab <?php echo $key === $active ? 'is-active' : ''; ?>" href="<?php echo esc_url( self::url( $key ) ); ?>">
						<span aria-hidden="true"><?php echo esc_html( $t[0] ); ?></span>
						<?php echo esc_html( $t[1] ); ?>
						<?php if ( '' !== $t[2] ) : ?><span class="ashp-tab__n"><?php echo esc_html( $t[2] ); ?></span><?php endif; ?>
					</a>
				<?php endforeach; ?>
			</nav>
		<?php
	}

	private static function end() {
		echo '</div>';
	}

	/** پیام نتیجه */
	private static function notice() {
		self::render_notice();
	}

	/** نمایش پیام نتیجه (برای استفاده در همهٔ صفحه‌ها) */
	public static function render_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$msg  = isset( $_GET['ashp_msg'] ) ? sanitize_key( wp_unslash( $_GET['ashp_msg'] ) ) : '';
		$text = isset( $_GET['ashp_text'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['ashp_text'] ) ) ) : '';
		// phpcs:enable

		$map = array(
			'saved'    => array( 'ok', __( 'ذخیره شد.', 'ashpazbashi' ) ),
			'deleted'  => array( 'ok', __( 'حذف شد.', 'ashpazbashi' ) ),
			'imported' => array( 'ok', __( 'داده‌ها با موفقیت وارد شد.', 'ashpazbashi' ) ),
			'recount'  => array( 'ok', __( 'تعداد مواد اولیه بازشماری شد.', 'ashpazbashi' ) ),
			'error'    => array( 'err', __( 'خطا: عملیات انجام نشد.', 'ashpazbashi' ) ),
			'inuse'    => array( 'warn', __( 'این ماده در چند دستور به کار رفته و حذف نشد.', 'ashpazbashi' ) ),
			'noname'   => array( 'err', __( 'نام غذا را وارد کنید.', 'ashpazbashi' ) ),
			'pagesaved' => array( 'ok', __( 'صفحه‌ها ذخیره شد.', 'ashpazbashi' ) ),
			'flushed'  => array( 'ok', __( 'قواعد مسیر از نو ساخته شد.', 'ashpazbashi' ) ),
			'rebuilt'  => array( 'ok', __( 'جدول‌ها بررسی و درست شدند.', 'ashpazbashi' ) ),
		);
		if ( ! $msg || ! isset( $map[ $msg ] ) ) {
			return;
		}
		$cls = 'ok' === $map[ $msg ][0] ? 'ashp-msg--ok' : ( 'warn' === $map[ $msg ][0] ? 'ashp-msg--warn' : 'ashp-msg--err' );
		echo '<div class="ashp-msg ' . esc_attr( $cls ) . '">' . esc_html( $map[ $msg ][1] );
		if ( '' !== $text ) {
			echo ' <strong>' . esc_html( $text ) . '</strong>';
		}
		echo '</div>';
	}

	private static function stat_card( $value, $label, $variant = '' ) {
		printf(
			'<div class="ashp-card %s"><b>%s</b><span>%s</span></div>',
			esc_attr( '' === $variant ? '' : 'ashp-card--' . $variant ),
			esc_html( number_format_i18n( $value ) ),
			esc_html( $label )
		);
	}

	/* =====================================================================
	 * صفحهٔ داشبورد
	 * ================================================================== */

	public static function page_dashboard() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		global $wpdb;
		$recipes = ASHP_DB::t( 'recipes' );
		$rel     = ASHP_DB::t( 'recipe_ingredients' );

		$total      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$active     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes WHERE is_active = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$halal      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes WHERE is_halal = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$steps      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes WHERE instructions_status = 'source'" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$relations  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $rel" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$orphans    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes r WHERE r.is_active = 1 AND NOT EXISTS ( SELECT 1 FROM $rel ri WHERE ri.recipe_id = r.id )" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$notes      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes WHERE halal_note <> ''" ); // phpcs:ignore WordPress.DB.PreparedSQL

		$cats = $wpdb->get_results(
			"SELECT category, COUNT(*) AS n FROM $recipes WHERE is_active = 1 GROUP BY category ORDER BY n DESC", // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$max  = 0;
		foreach ( (array) $cats as $c ) {
			$max = max( $max, (int) $c['n'] );
		}

		$custom = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $recipes WHERE source_dataset = 'admin'" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$last   = get_option( 'ashp_last_import' );

		self::hero( 'dashboard' );
		self::notice();
		?>

		<?php if ( $total < 1 ) : ?>
			<div class="ashp-msg ashp-msg--warn">
				<strong><?php esc_html_e( 'هنوز داده‌ای وارد نشده است.', 'ashpazbashi' ); ?></strong>
				<?php esc_html_e( 'برای شروع، از صفحهٔ «داده‌ها» دیتابیس آمادهٔ آشپزباشی را وارد کنید.', 'ashpazbashi' ); ?>
				<a href="<?php echo esc_url( self::url( 'data' ) ); ?>"><?php esc_html_e( 'رفتن به صفحهٔ داده‌ها', 'ashpazbashi' ); ?></a>
			</div>
		<?php endif; ?>

		<div class="ashp-cards">
			<?php
			self::stat_card( $total, __( 'کل غذاها', 'ashpazbashi' ) );
			self::stat_card( $active, __( 'غذای فعال', 'ashpazbashi' ), 'ok' );
			self::stat_card( $halal, __( 'دارای نشان حلال', 'ashpazbashi' ), 'ok' );
			self::stat_card( ASHP_DB::counts()['ingredients'], __( 'مادهٔ اولیه', 'ashpazbashi' ), 'pink' );
			self::stat_card( $relations, __( 'ارتباط غذا ↔ ماده', 'ashpazbashi' ) );
			self::stat_card( $custom, __( 'غذای افزوده توسط شما', 'ashpazbashi' ), 'pink' );
			self::stat_card( $steps, __( 'با متن مراحل از منبع', 'ashpazbashi' ) );
			self::stat_card( $orphans, __( 'غذای بدون مادهٔ اولیه', 'ashpazbashi' ), $orphans ? 'warn' : 'ok' );
			?>
		</div>

		<div class="ashp-panel">
			<div class="ashp-panel__head">
				<h2><i>📈</i> <?php esc_html_e( 'توزیع غذاها بر پایهٔ دسته', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint"><?php echo esc_html( sprintf( __( '%s دستهٔ اصلی', 'ashpazbashi' ), number_format_i18n( count( $cats ) ) ) ); ?></p>
			</div>
			<div class="ashp-bars">
				<?php foreach ( (array) $cats as $c ) : ?>
					<?php $pct = $max ? round( 100 * (int) $c['n'] / $max ) : 0; ?>
					<div class="ashp-bar">
						<span class="ashp-bar__label"><?php echo esc_html( ASHP_DB::category_label( $c['category'] ) ); ?></span>
						<span class="ashp-bar__track"><span class="ashp-bar__fill" style="width:<?php echo esc_attr( $pct ); ?>%"></span></span>
						<span class="ashp-bar__n"><?php echo esc_html( number_format_i18n( (int) $c['n'] ) ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="ashp-panel">
			<div class="ashp-panel__head">
				<h2><i>⚡</i> <?php esc_html_e( 'کارهای سریع', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint"><?php esc_html_e( 'رایج‌ترین کارها با یک کلیک', 'ashpazbashi' ); ?></p>
			</div>
			<div class="ashp-actions">
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( self::url( 'recipe-new' ) ); ?>">➕ <?php esc_html_e( 'افزودن غذای تازه', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn" href="<?php echo esc_url( self::url( 'recipes' ) ); ?>">🍲 <?php esc_html_e( 'مدیریت غذاها', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn" href="<?php echo esc_url( self::url( 'recipes', array( 'halal' => '0' ) ) ); ?>">☪ <?php esc_html_e( 'بررسی حلال', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn" href="<?php echo esc_url( self::url( 'ingredients' ) ); ?>">🧂 <?php esc_html_e( 'مواد اولیه', 'ashpazbashi' ); ?></a>
				<a class="ashp-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">🌐 <?php esc_html_e( 'دیدن سایت', 'ashpazbashi' ); ?></a>
			</div>
		</div>

		<?php if ( $notes > 0 ) : ?>
			<div class="ashp-msg ashp-msg--warn">
				<?php
				printf(
					/* translators: %s: number of recipes */
					esc_html__( '%s غذا یادداشت حلال دارند (موادی مثل ژلاتین، پنیر یا سوسیس که باید از منبع حلال تهیه شوند). این یادداشت‌ها به کاربر نمایش داده می‌شود.', 'ashpazbashi' ),
					esc_html( number_format_i18n( $notes ) )
				);
				?>
			</div>
		<?php endif; ?>

		<?php if ( is_array( $last ) ) : ?>
			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>🕘</i> <?php esc_html_e( 'آخرین ورود داده', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint"><?php echo esc_html( isset( $last['time'] ) ? $last['time'] : '' ); ?></p>
				</div>
				<p class="ashp-help">
					<?php
					printf(
						/* translators: 1: recipes, 2: ingredients, 3: relations */
						esc_html__( '%1$s غذا، %2$s مادهٔ اولیه، %3$s ارتباط.', 'ashpazbashi' ),
						esc_html( number_format_i18n( isset( $last['recipes'] ) ? $last['recipes'] : 0 ) ),
						esc_html( number_format_i18n( isset( $last['ingredients'] ) ? $last['ingredients'] : 0 ) ),
						esc_html( number_format_i18n( isset( $last['relations'] ) ? $last['relations'] : 0 ) )
					);
					?>
				</p>
			</div>
		<?php endif; ?>

		<?php
		self::end();
	}

	/* =====================================================================
	 * فهرست غذاها
	 * ================================================================== */

	public static function page_recipes() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		global $wpdb;
		$table = ASHP_DB::t( 'recipes' );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$q     = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$cat   = isset( $_GET['cat'] ) ? sanitize_title( wp_unslash( $_GET['cat'] ) ) : '';
		$sub   = isset( $_GET['sub'] ) ? sanitize_title( wp_unslash( $_GET['sub'] ) ) : '';
		$state = isset( $_GET['state'] ) ? sanitize_key( wp_unslash( $_GET['state'] ) ) : '';
		$halal = isset( $_GET['halal'] ) ? sanitize_key( wp_unslash( $_GET['halal'] ) ) : '';
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		// phpcs:enable

		$per   = 30;
		$where = array( '1=1' );
		$args  = array();

		if ( '' !== $q ) {
			$where[] = 'name LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( $q ) . '%';
		}
		if ( '' !== $cat ) {
			$where[] = 'category = %s';
			$args[]  = $cat;
		}
		if ( '' !== $sub ) {
			$where[] = 'subcategory = %s';
			$args[]  = $sub;
		}
		if ( 'inactive' === $state ) {
			$where[] = 'is_active = 0';
		} elseif ( 'nosteps' === $state ) {
			$where[] = "instructions_status = 'none'";
		} elseif ( 'active' === $state ) {
			$where[] = 'is_active = 1';
		}
		if ( '0' === $halal ) {
			$where[] = 'is_halal = 0';
		} elseif ( '1' === $halal ) {
			$where[] = 'is_halal = 1';
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
		$total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		$sql  = "SELECT * FROM $table WHERE $where_sql ORDER BY id DESC LIMIT %d OFFSET %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( $per, ( $paged - 1 ) * $per ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$pages = max( 1, (int) ceil( $total / $per ) );

		self::hero( 'recipes' );
		self::notice();
		?>

		<div class="ashp-panel">
			<div class="ashp-panel__head">
				<h2><i>🍲</i> <?php esc_html_e( 'همهٔ غذاها', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint">
					<?php
					printf(
						/* translators: 1: filtered count, 2: total count */
						esc_html__( '%1$s نتیجه از %2$s غذا', 'ashpazbashi' ),
						esc_html( number_format_i18n( $total ) ),
						esc_html( number_format_i18n( ASHP_DB::counts()['recipes'] ) )
					);
					?>
				</p>
			</div>

			<form class="ashp-filters" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG . '-recipes' ); ?>">

				<div class="ashp-field">
					<label for="ashp-q"><?php esc_html_e( 'جست‌وجو', 'ashpazbashi' ); ?></label>
					<input type="search" id="ashp-q" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="<?php esc_attr_e( 'نام غذا…', 'ashpazbashi' ); ?>">
				</div>

				<div class="ashp-field">
					<label for="ashp-fcat"><?php esc_html_e( 'دسته', 'ashpazbashi' ); ?></label>
					<select id="ashp-fcat" name="cat">
						<option value=""><?php esc_html_e( 'همه', 'ashpazbashi' ); ?></option>
						<?php foreach ( ASHP_DB::categories() as $slug => $label ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $cat, $slug ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="ashp-field">
					<label for="ashp-fstate"><?php esc_html_e( 'وضعیت', 'ashpazbashi' ); ?></label>
					<select id="ashp-fstate" name="state">
						<option value=""><?php esc_html_e( 'همه', 'ashpazbashi' ); ?></option>
						<option value="active" <?php selected( $state, 'active' ); ?>><?php esc_html_e( 'فعال', 'ashpazbashi' ); ?></option>
						<option value="inactive" <?php selected( $state, 'inactive' ); ?>><?php esc_html_e( 'غیرفعال', 'ashpazbashi' ); ?></option>
						<option value="nosteps" <?php selected( $state, 'nosteps' ); ?>><?php esc_html_e( 'بدون مراحل پخت', 'ashpazbashi' ); ?></option>
					</select>
				</div>

				<div class="ashp-field">
					<label for="ashp-fhalal"><?php esc_html_e( 'حلال', 'ashpazbashi' ); ?></label>
					<select id="ashp-fhalal" name="halal">
						<option value=""><?php esc_html_e( 'همه', 'ashpazbashi' ); ?></option>
						<option value="1" <?php selected( $halal, '1' ); ?>><?php esc_html_e( 'علامت‌خورده', 'ashpazbashi' ); ?></option>
						<option value="0" <?php selected( $halal, '0' ); ?>><?php esc_html_e( 'بررسی‌نشده', 'ashpazbashi' ); ?></option>
					</select>
				</div>

				<div class="ashp-field">
					<button class="ashp-btn ashp-btn--primary" type="submit"><?php esc_html_e( 'فیلتر', 'ashpazbashi' ); ?></button>
				</div>
			</form>
		</div>

		<?php if ( $rows ) : ?>
			<div class="ashp-table-wrap">
				<table class="ashp-table">
					<thead>
						<tr>
							<th style="width:56px">#</th>
							<th><?php esc_html_e( 'نام غذا', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'دسته', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'زمان', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'مواد', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'حلال', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'وضعیت', 'ashpazbashi' ); ?></th>
							<th style="width:170px"><?php esc_html_e( 'کارها', 'ashpazbashi' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						foreach ( (array) $rows as $r ) :
							$rec  = ASHP_DB::format_row( $r );
							$ings = ASHP_DB::recipe_ingredient_count( $rec['id'] );
							$halal_link = wp_nonce_url(
								admin_url( 'admin-post.php?action=ashp_toggle_recipe&field=is_halal&id=' . (int) $r['id'] . '&back=' . rawurlencode( self::url( 'recipes' ) ) ),
								'ashp_toggle_' . (int) $r['id']
							);
							$active_link = wp_nonce_url(
								admin_url( 'admin-post.php?action=ashp_toggle_recipe&field=is_active&id=' . (int) $r['id'] . '&back=' . rawurlencode( self::url( 'recipes' ) ) ),
								'ashp_toggle_' . (int) $r['id']
							);
							$del_link = wp_nonce_url(
								admin_url( 'admin-post.php?action=ashp_delete_recipe&id=' . (int) $r['id'] . '&back=' . rawurlencode( self::url( 'recipes' ) ) ),
								'ashp_delete_' . (int) $r['id']
							);
							?>
							<tr>
								<td><?php echo esc_html( number_format_i18n( $rec['id'] ) ); ?></td>
								<td>
									<a class="ashp-rowtitle" href="<?php echo esc_url( self::url( 'recipe-new', array( 'id' => $rec['id'] ) ) ); ?>">
										<?php echo esc_html( $rec['name'] ); ?>
									</a>
									<span class="ashp-sub"><?php echo esc_html( $rec['slug'] ); ?> · <?php echo esc_html( $rec['source_dataset'] ); ?></span>
								</td>
								<td>
									<?php echo esc_html( ASHP_DB::category_label( $rec['category'] ) ); ?>
									<span class="ashp-sub"><?php echo esc_html( ASHP_DB::subcategory_label( $rec['category'], $rec['subcategory'] ) ); ?></span>
								</td>
								<td><?php echo esc_html( '' !== ASHP_Front::time_label( ASHP_Front::total_time( $rec ) ) ? ASHP_Front::time_label( ASHP_Front::total_time( $rec ) ) : '—' ); ?></td>
								<td><?php echo esc_html( number_format_i18n( $ings ) ); ?></td>
								<td>
									<a href="<?php echo esc_url( $halal_link ); ?>" title="<?php esc_attr_e( 'تغییر وضعیت حلال', 'ashpazbashi' ); ?>">
										<span class="ashp-tag <?php echo (int) $r['is_halal'] ? 'ashp-tag--ok' : 'ashp-tag--off'; ?>">
											<?php echo (int) $r['is_halal'] ? '☪ ' . esc_html__( 'حلال', 'ashpazbashi' ) : esc_html__( 'بررسی‌نشده', 'ashpazbashi' ); ?>
										</span>
									</a>
								</td>
								<td>
									<a href="<?php echo esc_url( $active_link ); ?>">
										<span class="ashp-tag <?php echo (int) $r['is_active'] ? 'ashp-tag--neon' : 'ashp-tag--off'; ?>">
											<?php echo (int) $r['is_active'] ? esc_html__( 'فعال', 'ashpazbashi' ) : esc_html__( 'غیرفعال', 'ashpazbashi' ); ?>
										</span>
									</a>
								</td>
								<td>
									<a class="ashp-btn ashp-btn--sm" href="<?php echo esc_url( self::url( 'recipe-new', array( 'id' => $rec['id'] ) ) ); ?>"><?php esc_html_e( 'ویرایش', 'ashpazbashi' ); ?></a>
									<a class="ashp-btn ashp-btn--sm" href="<?php echo esc_url( ASHP_DB::recipe_url( $rec ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'نمایش', 'ashpazbashi' ); ?></a>
									<a class="ashp-btn ashp-btn--sm ashp-btn--danger" href="<?php echo esc_url( $del_link ); ?>"
										data-ashp-confirm="<?php esc_attr_e( 'این غذا و مواد اولیهٔ آن حذف شود؟', 'ashpazbashi' ); ?>"><?php esc_html_e( 'حذف', 'ashpazbashi' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<?php if ( $pages > 1 ) : ?>
				<div class="ashp-pager">
					<?php
					$base = add_query_arg( array(
						'page'  => self::SLUG . '-recipes',
						'q'     => $q,
						'cat'   => $cat,
						'sub'   => $sub,
						'state' => $state,
						'halal' => $halal,
					), admin_url( 'admin.php' ) );
					$from = max( 1, $paged - 3 );
					$to   = min( $pages, $paged + 3 );
					if ( $paged > 1 ) {
						echo '<a href="' . esc_url( add_query_arg( 'paged', $paged - 1, $base ) ) . '">‹</a>';
					}
					for ( $i = $from; $i <= $to; $i++ ) {
						if ( $i === $paged ) {
							echo '<span class="is-current">' . esc_html( number_format_i18n( $i ) ) . '</span>';
						} else {
							echo '<a href="' . esc_url( add_query_arg( 'paged', $i, $base ) ) . '">' . esc_html( number_format_i18n( $i ) ) . '</a>';
						}
					}
					if ( $paged < $pages ) {
						echo '<a href="' . esc_url( add_query_arg( 'paged', $paged + 1, $base ) ) . '">›</a>';
					}
					?>
				</div>
			<?php endif; ?>

		<?php else : ?>
			<div class="ashp-empty">
				<h3><?php esc_html_e( 'غذایی با این فیلترها پیدا نشد', 'ashpazbashi' ); ?></h3>
				<p><?php esc_html_e( 'فیلترها را پاک کنید یا یک غذای تازه اضافه کنید.', 'ashpazbashi' ); ?></p>
				<a class="ashp-btn ashp-btn--primary" href="<?php echo esc_url( self::url( 'recipe-new' ) ); ?>">➕ <?php esc_html_e( 'افزودن غذا', 'ashpazbashi' ); ?></a>
			</div>
		<?php endif; ?>

		<?php
		self::end();
	}

	/* =====================================================================
	 * افزودن / ویرایش غذا
	 * ================================================================== */

	public static function page_recipe_edit() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$recipe = $id ? ASHP_DB::get( $id ) : null;
		$ings   = $recipe ? ASHP_DB::recipe_ingredients( $recipe['id'] ) : array();

		$d = $recipe ? $recipe : array(
			'name' => '', 'slug' => '', 'category' => 'iranian-formal', 'subcategory' => 'khoresh',
			'cuisine' => 'ایرانی', 'meal' => '', 'suitable_for' => '', 'servings' => '',
			'prep_time_min' => '', 'cook_time_min' => '', 'difficulty' => '', 'cooking_method' => '',
			'instructions' => '', 'instructions_status' => 'none', 'calories_kcal' => '', 'image_url' => '',
			'is_halal' => 1, 'halal_note' => '',
		);

		$difficulties = array( 'مبتدی', 'متوسط', 'پیشرفته', 'حرفه ای' );
		$methods      = array( 'پختن', 'جوشاندن', 'سرخ کردن ساده', 'سرخ کردن عمیق', 'کباب کردن در فر',
			'گریل کردن', 'باربیکیو کردن', 'بخارپز کردن', 'آبپز کردن', 'با سس پختن', 'ترکیب کردن', 'مایکرویو' );
		$meals        = array( 'صبحانه', 'ناهار', 'عصرانه', 'شام', 'میان‌وعده' );

		$all_ing = ASHP_DB::all_ingredient_names();

		self::hero( 'recipe-new' );
		self::notice();
		?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="ashp_save_recipe">
			<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
			<?php wp_nonce_field( 'ashp_save_recipe' ); ?>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2>
						<i><?php echo $id ? '✏️' : '➕'; ?></i>
						<?php echo $id ? esc_html__( 'ویرایش غذا', 'ashpazbashi' ) : esc_html__( 'افزودن غذای تازه', 'ashpazbashi' ); ?>
					</h2>
					<p class="ashp-panel__hint"><?php esc_html_e( 'اطلاعات پایه و دسته‌بندی', 'ashpazbashi' ); ?></p>
				</div>

				<div class="ashp-grid2">
					<div class="ashp-field">
						<label for="ashp-name"><?php esc_html_e( 'نام غذا', 'ashpazbashi' ); ?> <span class="req">*</span></label>
						<input type="text" id="ashp-name" name="name" value="<?php echo esc_attr( $d['name'] ); ?>" placeholder="<?php esc_attr_e( 'مثلاً: خورش قیمه بادمجان', 'ashpazbashi' ); ?>" required>
					</div>

					<div class="ashp-field">
						<label for="ashp-slug"><?php esc_html_e( 'نشانی صفحه (slug)', 'ashpazbashi' ); ?></label>
						<input type="text" id="ashp-slug" name="slug" value="<?php echo esc_attr( $d['slug'] ); ?>" placeholder="<?php esc_attr_e( 'خالی بگذارید تا خودکار ساخته شود', 'ashpazbashi' ); ?>">
						<span class="ashp-help"><?php esc_html_e( 'آدرس نهایی: /recipes/نشانی/', 'ashpazbashi' ); ?></span>
					</div>

					<div class="ashp-field">
						<label for="ashp-cat"><?php esc_html_e( 'دستهٔ اصلی', 'ashpazbashi' ); ?></label>
						<select id="ashp-cat" name="category">
							<?php foreach ( ASHP_DB::taxonomy() as $slug => $info ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $d['category'], $slug ); ?>>
									<?php echo esc_html( $info['emoji'] . ' ' . $info['fa'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="ashp-field">
						<label for="ashp-sub"><?php esc_html_e( 'زیردسته', 'ashpazbashi' ); ?></label>
						<select id="ashp-sub" name="subcategory" data-current="<?php echo esc_attr( $d['subcategory'] ); ?>"></select>
					</div>

					<div class="ashp-field">
						<label for="ashp-cuisine"><?php esc_html_e( 'آشپزی', 'ashpazbashi' ); ?></label>
						<input type="text" id="ashp-cuisine" name="cuisine" value="<?php echo esc_attr( $d['cuisine'] ); ?>" placeholder="<?php esc_attr_e( 'ایرانی، ایتالیایی، ...', 'ashpazbashi' ); ?>">
					</div>

					<div class="ashp-field">
						<label for="ashp-meal"><?php esc_html_e( 'وعدهٔ غذایی', 'ashpazbashi' ); ?></label>
						<select id="ashp-meal" name="meal">
							<option value=""><?php esc_html_e( '— تعیین نشده —', 'ashpazbashi' ); ?></option>
							<?php foreach ( $meals as $m ) : ?>
								<option value="<?php echo esc_attr( $m ); ?>" <?php selected( $d['meal'], $m ); ?>><?php echo esc_html( $m ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>⏱</i> <?php esc_html_e( 'زمان، سختی و ارزش غذایی', 'ashpazbashi' ); ?></h2>
				</div>
				<div class="ashp-grid3">
					<div class="ashp-field">
						<label for="ashp-prep"><?php esc_html_e( 'زمان آماده‌سازی (دقیقه)', 'ashpazbashi' ); ?></label>
						<input type="number" id="ashp-prep" name="prep_time_min" min="0" step="1" value="<?php echo esc_attr( $d['prep_time_min'] ); ?>">
					</div>
					<div class="ashp-field">
						<label for="ashp-cook"><?php esc_html_e( 'زمان پخت (دقیقه)', 'ashpazbashi' ); ?></label>
						<input type="number" id="ashp-cook" name="cook_time_min" min="0" step="1" value="<?php echo esc_attr( $d['cook_time_min'] ); ?>">
					</div>
					<div class="ashp-field">
						<label for="ashp-serv"><?php esc_html_e( 'تعداد نفرات', 'ashpazbashi' ); ?></label>
						<input type="number" id="ashp-serv" name="servings" min="0" step="1" value="<?php echo esc_attr( $d['servings'] ); ?>">
					</div>
					<div class="ashp-field">
						<label for="ashp-diff"><?php esc_html_e( 'سطح مهارت', 'ashpazbashi' ); ?></label>
						<select id="ashp-diff" name="difficulty">
							<option value=""><?php esc_html_e( '— تعیین نشده —', 'ashpazbashi' ); ?></option>
							<?php foreach ( $difficulties as $x ) : ?>
								<option value="<?php echo esc_attr( $x ); ?>" <?php selected( $d['difficulty'], $x ); ?>><?php echo esc_html( $x ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ashp-field">
						<label for="ashp-method"><?php esc_html_e( 'روش پخت', 'ashpazbashi' ); ?></label>
						<select id="ashp-method" name="cooking_method">
							<option value=""><?php esc_html_e( '— تعیین نشده —', 'ashpazbashi' ); ?></option>
							<?php foreach ( $methods as $x ) : ?>
								<option value="<?php echo esc_attr( $x ); ?>" <?php selected( $d['cooking_method'], $x ); ?>><?php echo esc_html( $x ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ashp-field">
						<label for="ashp-cal"><?php esc_html_e( 'کالری (هر وعده)', 'ashpazbashi' ); ?></label>
						<input type="number" id="ashp-cal" name="calories_kcal" min="0" step="1" value="<?php echo esc_attr( $d['calories_kcal'] ); ?>">
					</div>
				</div>

				<div class="ashp-field">
					<label for="ashp-img"><?php esc_html_e( 'نشانی تصویر غذا', 'ashpazbashi' ); ?></label>
					<input type="url" id="ashp-img" name="image_url" value="<?php echo esc_attr( $d['image_url'] ); ?>" placeholder="https://…" dir="ltr">
					<span class="ashp-help"><?php esc_html_e( 'اختیاری. می‌توانید از کتابخانهٔ رسانه هم نشانی بردارید.', 'ashpazbashi' ); ?></span>
				</div>
			</div>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>🧂</i> <?php esc_html_e( 'مواد اولیه', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint">
						<span id="ashp-ing-count">۰</span> <?php esc_html_e( 'ردیف', 'ashpazbashi' ); ?>
						— <?php esc_html_e( 'ترتیب ردیف‌ها همان ترتیب نمایش در سایت است.', 'ashpazbashi' ); ?>
					</p>
				</div>

				<div class="ashp-ings" id="ashp-ing-rows"></div>

				<template id="ashp-ing-template">
					<div class="ashp-ing-row">
						<span class="ashp-ing-row__n">۱</span>
						<div class="ashp-field">
							<input type="text" name="ing_name[]" list="ashp-ing-list" placeholder="<?php esc_attr_e( 'نام مادهٔ اولیه', 'ashpazbashi' ); ?>">
						</div>
						<div class="ashp-field">
							<input type="number" name="ing_value[]" min="0" step="0.01" placeholder="<?php esc_attr_e( 'مقدار', 'ashpazbashi' ); ?>">
						</div>
						<div class="ashp-field">
							<input type="text" name="ing_unit[]" list="ashp-unit-list" placeholder="<?php esc_attr_e( 'واحد', 'ashpazbashi' ); ?>">
						</div>
						<label class="ashp-mainmark">
							<input type="checkbox" name="ing_main[]" value="1">
							<?php esc_html_e( 'اصلی', 'ashpazbashi' ); ?>
						</label>
						<button type="button" class="ashp-ing-remove" aria-label="<?php esc_attr_e( 'حذف ردیف', 'ashpazbashi' ); ?>">✕</button>
					</div>
				</template>

				<datalist id="ashp-ing-list">
					<?php foreach ( $all_ing as $ing_name ) : ?>
						<option value="<?php echo esc_attr( $ing_name ); ?>"></option>
					<?php endforeach; ?>
				</datalist>
				<datalist id="ashp-unit-list">
					<?php foreach ( ASHP_DB::common_units() as $u ) : ?>
						<option value="<?php echo esc_attr( $u ); ?>"></option>
					<?php endforeach; ?>
				</datalist>

				<p style="margin:16px 0 0">
					<button type="button" class="ashp-btn ashp-btn--pink" id="ashp-ing-add">➕ <?php esc_html_e( 'افزودن ردیف ماده', 'ashpazbashi' ); ?></button>
				</p>

				<?php if ( $ings ) : ?>
					<script type="application/json" id="ashp-ing-data">
						<?php
						echo wp_json_encode( array_map( function ( $i ) {
							return array(
								'name' => $i['name'],
								'value' => null !== $i['amount_value'] ? $i['amount_value'] : '',
								'unit' => $i['unit'],
								'main' => (int) $i['is_main'],
							);
						}, $ings ), JSON_UNESCAPED_UNICODE );
						?>
					</script>
				<?php endif; ?>
			</div>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>📝</i> <?php esc_html_e( 'مراحل پخت', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint"><?php esc_html_e( 'هر گام را در یک خط جدا بنویسید.', 'ashpazbashi' ); ?></p>
				</div>
				<div class="ashp-field">
					<textarea name="instructions" rows="12" placeholder="<?php esc_attr_e( "پیاز را نگینی خرد کنید و با روغن تفت دهید.\nگوشت را اضافه کنید و تفت دهید تا رنگش عوض شود.", 'ashpazbashi' ); ?>"><?php echo esc_textarea( $d['instructions'] ); ?></textarea>
				</div>
			</div>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>☪</i> <?php esc_html_e( 'حلال و وضعیت نمایش', 'ashpazbashi' ); ?></h2>
				</div>
				<div class="ashp-grid2">
					<div class="ashp-field">
						<label class="ashp-switch">
							<input type="checkbox" name="is_halal" value="1" <?php checked( (int) $d['is_halal'], 1 ); ?>>
							<span class="ashp-switch__ui"></span>
							<?php esc_html_e( 'این غذا حلال است', 'ashpazbashi' ); ?>
						</label>
						<span class="ashp-help"><?php esc_html_e( 'با برداشتن این تیک، برچسب «بررسی‌نشده» روی غذا می‌خورد.', 'ashpazbashi' ); ?></span>
					</div>
					<div class="ashp-field">
						<label for="ashp-hnote"><?php esc_html_e( 'یادداشت حلال', 'ashpazbashi' ); ?></label>
						<input type="text" id="ashp-hnote" name="halal_note" value="<?php echo esc_attr( $d['halal_note'] ); ?>" placeholder="<?php esc_attr_e( 'مثلاً: ژلاتین را از منبع حلال تهیه کنید.', 'ashpazbashi' ); ?>">
						<span class="ashp-help"><?php esc_html_e( 'اختیاری. زیر مواد اولیه به کاربر نشان داده می‌شود.', 'ashpazbashi' ); ?></span>
					</div>
				</div>
			</div>

			<div class="ashp-panel">
				<div class="ashp-actions">
					<button type="submit" class="ashp-btn ashp-btn--primary">💾 <?php echo $id ? esc_html__( 'ذخیرهٔ تغییرات', 'ashpazbashi' ) : esc_html__( 'افزودن غذا', 'ashpazbashi' ); ?></button>
					<a class="ashp-btn" href="<?php echo esc_url( self::url( 'recipes' ) ); ?>"><?php esc_html_e( 'بازگشت به فهرست', 'ashpazbashi' ); ?></a>
					<?php if ( $id ) : ?>
						<a class="ashp-btn" href="<?php echo esc_url( ASHP_DB::recipe_url( $d ) ); ?>" target="_blank" rel="noopener">👁 <?php esc_html_e( 'دیدن در سایت', 'ashpazbashi' ); ?></a>
						<?php
						$del = wp_nonce_url(
							admin_url( 'admin-post.php?action=ashp_delete_recipe&id=' . (int) $id . '&back=' . rawurlencode( self::url( 'recipes' ) ) ),
							'ashp_delete_' . (int) $id
						);
						?>
						<a class="ashp-btn ashp-btn--danger" href="<?php echo esc_url( $del ); ?>"
							data-ashp-confirm="<?php esc_attr_e( 'این غذا حذف شود؟', 'ashpazbashi' ); ?>">🗑 <?php esc_html_e( 'حذف غذا', 'ashpazbashi' ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</form>

		<?php
		self::end();
	}

	/* =====================================================================
	 * مواد اولیه
	 * ================================================================== */

	public static function page_ingredients() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		global $wpdb;
		$ing = ASHP_DB::t( 'ingredients' );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$q       = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$group   = isset( $_GET['group'] ) ? sanitize_key( wp_unslash( $_GET['group'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$edit_id = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
		// phpcs:enable

		$per   = 40;
		$where = array( '1=1' );
		$args  = array();
		if ( '' !== $q ) {
			$where[] = 'name LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( $q ) . '%';
		}
		if ( '' !== $group ) {
			$where[] = 'group_key = %s';
			$args[]  = $group;
		}
		$where_sql = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM $ing WHERE $where_sql";
		$total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		$sql   = "SELECT * FROM $ing WHERE $where_sql ORDER BY recipes_count DESC, name ASC LIMIT %d OFFSET %d";
		$rows  = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( $per, ( $paged - 1 ) * $per ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$pages = max( 1, (int) ceil( $total / $per ) );

		$editing = null;
		if ( $edit_id ) {
			$editing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ing WHERE id = %d", $edit_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		$defs = ASHP_DB::ingredient_groups_def();

		self::hero( 'ingredients' );
		self::notice();
		?>

		<div class="ashp-grid2">
			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i><?php echo $editing ? '✏️' : '➕'; ?></i> <?php echo $editing ? esc_html__( 'ویرایش مادهٔ اولیه', 'ashpazbashi' ) : esc_html__( 'افزودن مادهٔ اولیه', 'ashpazbashi' ); ?></h2>
				</div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="ashp_save_ingredient">
					<input type="hidden" name="id" value="<?php echo esc_attr( $editing ? (int) $editing['id'] : 0 ); ?>">
					<?php wp_nonce_field( 'ashp_save_ingredient' ); ?>

					<div class="ashp-field">
						<label for="ashp-ing-name"><?php esc_html_e( 'نام ماده', 'ashpazbashi' ); ?> <span class="req">*</span></label>
						<input type="text" id="ashp-ing-name" name="ing_name" value="<?php echo esc_attr( $editing ? $editing['name'] : '' ); ?>" required>
					</div>
					<div class="ashp-field">
						<label for="ashp-ing-group"><?php esc_html_e( 'گروه', 'ashpazbashi' ); ?></label>
						<select id="ashp-ing-group" name="group_key">
							<?php foreach ( $defs as $key => $def ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $editing ? $editing['group_key'] : 'other', $key ); ?>>
									<?php echo esc_html( $def['emoji'] . ' ' . $def['label'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="ashp-actions">
						<button type="submit" class="ashp-btn ashp-btn--primary">💾 <?php esc_html_e( 'ذخیره', 'ashpazbashi' ); ?></button>
						<?php if ( $editing ) : ?>
							<a class="ashp-btn" href="<?php echo esc_url( self::url( 'ingredients' ) ); ?>"><?php esc_html_e( 'انصراف', 'ashpazbashi' ); ?></a>
						<?php endif; ?>
					</div>
				</form>
			</div>

			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>📊</i> <?php esc_html_e( 'وضعیت کلی', 'ashpazbashi' ); ?></h2>
				</div>
				<div class="ashp-bars">
					<?php
					$by_group = $wpdb->get_results( "SELECT group_key, COUNT(*) AS n FROM $ing GROUP BY group_key ORDER BY n DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
					$gmax     = 0;
					foreach ( (array) $by_group as $g ) {
						$gmax = max( $gmax, (int) $g['n'] );
					}
					foreach ( (array) $by_group as $g ) :
						?>
						<div class="ashp-bar">
							<span class="ashp-bar__label"><?php echo esc_html( isset( $defs[ $g['group_key'] ] ) ? $defs[ $g['group_key'] ]['label'] : $g['group_key'] ); ?></span>
							<span class="ashp-bar__track"><span class="ashp-bar__fill" style="width:<?php echo esc_attr( $gmax ? round( 100 * (int) $g['n'] / $gmax ) : 0 ); ?>%"></span></span>
							<span class="ashp-bar__n"><?php echo esc_html( number_format_i18n( (int) $g['n'] ) ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

		<div class="ashp-panel">
			<div class="ashp-panel__head">
				<h2><i>🧂</i> <?php esc_html_e( 'فهرست مواد اولیه', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint"><?php echo esc_html( sprintf( __( '%s ماده', 'ashpazbashi' ), number_format_i18n( $total ) ) ); ?></p>
			</div>

			<form class="ashp-filters" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG . '-ingredients' ); ?>">
				<div class="ashp-field">
					<label for="ashp-iq"><?php esc_html_e( 'جست‌وجو', 'ashpazbashi' ); ?></label>
					<input type="search" id="ashp-iq" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="<?php esc_attr_e( 'نام ماده…', 'ashpazbashi' ); ?>">
				</div>
				<div class="ashp-field">
					<label for="ashp-ig"><?php esc_html_e( 'گروه', 'ashpazbashi' ); ?></label>
					<select id="ashp-ig" name="group">
						<option value=""><?php esc_html_e( 'همه', 'ashpazbashi' ); ?></option>
						<?php foreach ( $defs as $key => $def ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $group, $key ); ?>><?php echo esc_html( $def['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="ashp-field">
					<button class="ashp-btn ashp-btn--primary" type="submit"><?php esc_html_e( 'فیلتر', 'ashpazbashi' ); ?></button>
				</div>
			</form>
		</div>

		<?php if ( $rows ) : ?>
			<div class="ashp-table-wrap">
				<table class="ashp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'نام ماده', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'گروه', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'در چند غذا', 'ashpazbashi' ); ?></th>
							<th style="width:190px"><?php esc_html_e( 'کارها', 'ashpazbashi' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( (array) $rows as $r ) : ?>
							<?php
							$del = wp_nonce_url(
								admin_url( 'admin-post.php?action=ashp_delete_ingredient&id=' . (int) $r['id'] . '&back=' . rawurlencode( self::url( 'ingredients' ) ) ),
								'ashp_del_ing_' . (int) $r['id']
							);
							?>
							<tr>
								<td>
									<a class="ashp-rowtitle" href="<?php echo esc_url( self::url( 'ingredients', array( 'edit' => (int) $r['id'] ) ) ); ?>">
										<?php echo esc_html( $r['name'] ); ?>
									</a>
									<span class="ashp-sub"><?php echo esc_html( $r['slug'] ); ?></span>
								</td>
								<td><span class="ashp-tag"><?php echo esc_html( isset( $defs[ $r['group_key'] ] ) ? $defs[ $r['group_key'] ]['label'] : $r['group_key'] ); ?></span></td>
								<td>
									<a href="<?php echo esc_url( self::url( 'recipes', array( 'q' => $r['name'] ) ) ); ?>">
										<span class="ashp-tag ashp-tag--neon"><?php echo esc_html( number_format_i18n( (int) $r['recipes_count'] ) ); ?></span>
									</a>
								</td>
								<td>
									<a class="ashp-btn ashp-btn--sm" href="<?php echo esc_url( self::url( 'ingredients', array( 'edit' => (int) $r['id'] ) ) ); ?>"><?php esc_html_e( 'ویرایش', 'ashpazbashi' ); ?></a>
									<a class="ashp-btn ashp-btn--sm" href="<?php echo esc_url( ASHP_DB::ingredient_url( $r['slug'] ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'نمایش', 'ashpazbashi' ); ?></a>
									<a class="ashp-btn ashp-btn--sm ashp-btn--danger" href="<?php echo esc_url( $del ); ?>"
										data-ashp-confirm="<?php esc_attr_e( 'این ماده حذف شود؟', 'ashpazbashi' ); ?>"><?php esc_html_e( 'حذف', 'ashpazbashi' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<?php if ( $pages > 1 ) : ?>
				<div class="ashp-pager">
					<?php
					$base = add_query_arg( array( 'page' => self::SLUG . '-ingredients', 'q' => $q, 'group' => $group ), admin_url( 'admin.php' ) );
					$from = max( 1, $paged - 3 );
					$to   = min( $pages, $paged + 3 );
					if ( $paged > 1 ) {
						echo '<a href="' . esc_url( add_query_arg( 'paged', $paged - 1, $base ) ) . '">‹</a>';
					}
					for ( $i = $from; $i <= $to; $i++ ) {
						echo $i === $paged
							? '<span class="is-current">' . esc_html( number_format_i18n( $i ) ) . '</span>'
							: '<a href="' . esc_url( add_query_arg( 'paged', $i, $base ) ) . '">' . esc_html( number_format_i18n( $i ) ) . '</a>';
					}
					if ( $paged < $pages ) {
						echo '<a href="' . esc_url( add_query_arg( 'paged', $paged + 1, $base ) ) . '">›</a>';
					}
					?>
				</div>
			<?php endif; ?>
		<?php else : ?>
			<div class="ashp-empty"><h3><?php esc_html_e( 'ماده‌ای پیدا نشد', 'ashpazbashi' ); ?></h3></div>
		<?php endif; ?>

		<?php
		self::end();
	}

	/* =====================================================================
	 * دسته‌بندی‌ها
	 * ================================================================== */

	public static function page_categories() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		self::hero( 'categories' );
		self::notice();
		?>
		<div class="ashp-msg">
			<?php esc_html_e( 'دسته‌بندی‌ها ساختار ثابت آشپزباشی هستند و آدرس‌های سایت (/food/ و /sweets/ و دسته‌ها) بر پایهٔ آن‌ها ساخته می‌شود. برای جابه‌جا کردن یک غذا، از صفحهٔ ویرایش همان غذا دستهٔ تازه را انتخاب کنید.', 'ashpazbashi' ); ?>
		</div>

		<?php foreach ( ASHP_DB::taxonomy() as $slug => $info ) : ?>
			<?php
			$subs = ASHP_DB::subcategory_cards( array( $slug ) );
			$subs = $subs ? $subs[0]['subs'] : array();
			?>
			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i><?php echo esc_html( $info['emoji'] ); ?></i> <?php echo esc_html( $info['fa'] ); ?></h2>
					<p class="ashp-panel__hint">
						<code><?php echo esc_html( $slug ); ?></code> ·
						<?php echo esc_html( sprintf( __( '%s غذا', 'ashpazbashi' ), number_format_i18n( ASHP_DB::category_count( $slug ) ) ) ); ?>
						· <a href="<?php echo esc_url( ASHP_DB::category_url( $slug ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'نمایش در سایت', 'ashpazbashi' ); ?></a>
					</p>
				</div>
				<div class="ashp-actions">
					<?php if ( $subs ) : ?>
						<?php foreach ( $subs as $s ) : ?>
							<a class="ashp-btn ashp-btn--sm" href="<?php echo esc_url( self::url( 'recipes', array( 'cat' => $slug, 'sub' => '' ) ) ); ?>">
								<?php echo esc_html( $s['label'] ); ?> <span class="ashp-tag ashp-tag--neon"><?php echo esc_html( number_format_i18n( $s['count'] ) ); ?></span>
							</a>
						<?php endforeach; ?>
					<?php else : ?>
						<span class="ashp-help"><?php esc_html_e( 'زیردسته‌ای ثبت نشده است.', 'ashpazbashi' ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
		<?php
		self::end();
	}

	/* =====================================================================
	 * داده‌ها
	 * ================================================================== */

	public static function page_data() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$files = ASHP_Importer::data_files_status();
		$last  = get_option( 'ashp_last_import' );

		self::hero( 'data' );
		self::notice();
		?>

		<div class="ashp-msg">
			<strong><?php esc_html_e( 'برای نصب سریع:', 'ashpazbashi' ); ?></strong>
			<?php esc_html_e( 'کافی است دکمهٔ «ورود داده» را بزنید. ۵٬۲۵۱ غذا با مواد اولیه و مراحل پخت به سایت اضافه می‌شود.', 'ashpazbashi' ); ?>
		</div>

		<?php
		$ashp_found = 0;
		foreach ( (array) $files as $fi ) {
			if ( ! empty( $fi['exists'] ) ) {
				$ashp_found++;
			}
		}
		?>
		<?php if ( $ashp_found < count( (array) $files ) ) : ?>
			<div class="ashp-msg ashp-msg--warn">
				<strong><?php esc_html_e( 'فایل‌های داده پیدا نشدند.', 'ashpazbashi' ); ?></strong>
				<?php esc_html_e( 'جست‌وجو در این مسیر انجام شد:', 'ashpazbashi' ); ?>
				<code><?php echo esc_html( ASHP_Importer::data_dir_label() ); ?></code>
				<br>
				<?php esc_html_e( 'پوشهٔ data با سه فایل recipes.csv و ingredients.csv و recipe_ingredients.csv باید همراه افزونه نصب شده باشد. پوشهٔ افزونه را از طریق FTP بررسی کنید.', 'ashpazbashi' ); ?>
			</div>
		<?php endif; ?>

		<div class="ashp-panel">
			<div class="ashp-panel__head">
				<h2><i>📦</i> <?php esc_html_e( 'ورود دادهٔ آماده', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint">
					<?php
					printf(
						/* translators: 1: found count, 2: total count, 3: path */
						esc_html__( '%1$s از %2$s فایل آماده — مسیر: %3$s', 'ashpazbashi' ),
						esc_html( number_format_i18n( $ashp_found ) ),
						esc_html( number_format_i18n( count( (array) $files ) ) ),
						esc_html( ASHP_Importer::data_dir_label() )
					);
					?>
				</p>
			</div>

			<div class="ashp-table-wrap" style="margin-bottom:18px">
				<table class="ashp-table">
					<thead><tr>
						<th><?php esc_html_e( 'فایل', 'ashpazbashi' ); ?></th>
						<th><?php esc_html_e( 'وضعیت', 'ashpazbashi' ); ?></th>
						<th><?php esc_html_e( 'حجم', 'ashpazbashi' ); ?></th>
					</tr></thead>
					<tbody>
						<?php foreach ( $files as $name => $info ) : ?>
							<tr>
								<td><code><?php echo esc_html( $name ); ?></code></td>
								<td>
									<?php if ( $info['exists'] ) : ?>
										<span class="ashp-tag ashp-tag--ok"><?php esc_html_e( 'آماده', 'ashpazbashi' ); ?></span>
									<?php else : ?>
										<span class="ashp-tag ashp-tag--off"><?php esc_html_e( 'یافت نشد', 'ashpazbashi' ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $info['exists'] ? size_format( $info['size'] ) : '—' ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="ashp-actions">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
					<input type="hidden" name="action" value="ashp_import">
					<?php wp_nonce_field( 'ashp_import' ); ?>
					<button type="submit" class="ashp-btn ashp-btn--primary"
						data-ashp-confirm="<?php esc_attr_e( 'جدول‌ها خالی و از نو پر می‌شوند. مطمئن هستید؟', 'ashpazbashi' ); ?>">
						📥 <?php esc_html_e( 'ورود داده', 'ashpazbashi' ); ?>
					</button>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
					<input type="hidden" name="action" value="ashp_recount">
					<?php wp_nonce_field( 'ashp_recount' ); ?>
					<button type="submit" class="ashp-btn">🔄 <?php esc_html_e( 'بازشماری مواد اولیه', 'ashpazbashi' ); ?></button>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0">
					<input type="hidden" name="action" value="ashp_export">
					<?php wp_nonce_field( 'ashp_export' ); ?>
					<button type="submit" class="ashp-btn">⬇ <?php esc_html_e( 'دریافت پشتیبان CSV', 'ashpazbashi' ); ?></button>
				</form>
			</div>
		</div>

		<?php if ( is_array( $last ) ) : ?>
			<div class="ashp-panel">
				<div class="ashp-panel__head">
					<h2><i>🕘</i> <?php esc_html_e( 'گزارش آخرین ورود', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint"><?php echo esc_html( isset( $last['time'] ) ? $last['time'] : '' ); ?></p>
				</div>
				<div class="ashp-cards">
					<?php
					self::stat_card( isset( $last['recipes'] ) ? $last['recipes'] : 0, __( 'غذا', 'ashpazbashi' ), 'ok' );
					self::stat_card( isset( $last['ingredients'] ) ? $last['ingredients'] : 0, __( 'مادهٔ اولیه', 'ashpazbashi' ), 'pink' );
					self::stat_card( isset( $last['relations'] ) ? $last['relations'] : 0, __( 'ارتباط', 'ashpazbashi' ) );
					?>
				</div>
				<?php if ( ! empty( $last['errors'] ) ) : ?>
					<div class="ashp-msg ashp-msg--warn">
						<strong><?php esc_html_e( 'هشدارها:', 'ashpazbashi' ); ?></strong>
						<?php echo esc_html( implode( ' | ', (array) $last['errors'] ) ); ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
		self::end();
	}

	/* =====================================================================
	 * پردازش‌ها
	 * ================================================================== */

	private static function guard( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'ashpazbashi' ) );
		}
		check_admin_referer( $action );
	}

	private static function back( $key, $msg, $text = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw  = isset( $_REQUEST['back'] ) ? esc_url_raw( wp_unslash( $_REQUEST['back'] ) ) : self::url( 'dashboard' );
		$args = array( 'ashp_msg' => $msg );
		if ( '' !== $text ) {
			$args['ashp_text'] = rawurlencode( $text );
		}
		wp_safe_redirect( add_query_arg( $args, $raw ) );
		exit;
	}

	/** ذخیرهٔ غذا */
	public static function handle_save_recipe() {
		self::guard( 'ashp_save_recipe' );
		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			wp_safe_redirect( self::url( 'recipe-new', array( 'id' => $id, 'ashp_msg' => 'noname' ) ) );
			exit;
		}

		$category = isset( $_POST['category'] ) ? sanitize_title( wp_unslash( $_POST['category'] ) ) : 'iranian-formal';
		$subcat   = isset( $_POST['subcategory'] ) ? sanitize_title( wp_unslash( $_POST['subcategory'] ) ) : '';
		if ( ! isset( ASHP_DB::taxonomy()[ $category ] ) ) {
			$category = 'iranian-formal';
		}
		$valid_subs = ASHP_DB::subcategories( $category );
		if ( '' !== $subcat && ! isset( $valid_subs[ $subcat ] ) ) {
			$subcat = '';
		}

		$num = function ( $key ) {
			return ( isset( $_POST[ $key ] ) && '' !== $_POST[ $key ] ) ? (float) $_POST[ $key ] : null;
		};

		$data = array(
			'name'                => $name,
			'category'            => $category,
			'subcategory'         => $subcat,
			'cuisine'             => isset( $_POST['cuisine'] ) ? sanitize_text_field( wp_unslash( $_POST['cuisine'] ) ) : '',
			'meal'                => isset( $_POST['meal'] ) ? sanitize_text_field( wp_unslash( $_POST['meal'] ) ) : '',
			'servings'            => $num( 'servings' ),
			'prep_time_min'       => $num( 'prep_time_min' ),
			'cook_time_min'       => $num( 'cook_time_min' ),
			'difficulty'          => isset( $_POST['difficulty'] ) ? sanitize_text_field( wp_unslash( $_POST['difficulty'] ) ) : '',
			'cooking_method'      => isset( $_POST['cooking_method'] ) ? sanitize_text_field( wp_unslash( $_POST['cooking_method'] ) ) : '',
			'instructions'        => isset( $_POST['instructions'] ) ? sanitize_textarea_field( wp_unslash( $_POST['instructions'] ) ) : '',
			'instructions_status' => 'source',
			'calories_kcal'       => $num( 'calories_kcal' ),
			'image_url'           => isset( $_POST['image_url'] ) ? esc_url_raw( wp_unslash( $_POST['image_url'] ) ) : '',
			'is_halal'            => empty( $_POST['is_halal'] ) ? 0 : 1,
			'halal_note'          => isset( $_POST['halal_note'] ) ? sanitize_text_field( wp_unslash( $_POST['halal_note'] ) ) : '',
			'is_active'           => 1,
		);
		// phpcs:enable

		if ( '' === trim( (string) $data['instructions'] ) ) {
			$data['instructions_status'] = 'none';
		}

		$slug_in = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';
		$slug    = ASHP_DB::make_slug( '' !== $slug_in ? $slug_in : $name, $id );

		if ( $id ) {
			$wpdb->update( ASHP_DB::t( 'recipes' ), $data, array( 'id' => $id ), null, array( '%d' ) );
			$wpdb->update( ASHP_DB::t( 'recipes' ), array( 'slug' => $slug ), array( 'id' => $id ), array( '%s' ), array( '%d' ) );
		} else {
			$data['slug']          = $slug;
			$data['source_dataset'] = 'admin';
			$data['completeness']   = '';
			$data['created_at']     = current_time( 'mysql' );
			$wpdb->insert( ASHP_DB::t( 'recipes' ), $data );
			$id = (int) $wpdb->insert_id;
		}

		// --- مواد اولیه ---
		$names  = isset( $_POST['ing_name'] ) ? (array) wp_unslash( $_POST['ing_name'] ) : array();
		$values = isset( $_POST['ing_value'] ) ? (array) wp_unslash( $_POST['ing_value'] ) : array();
		$units  = isset( $_POST['ing_unit'] ) ? (array) wp_unslash( $_POST['ing_unit'] ) : array();
		$mains  = isset( $_POST['ing_main'] ) ? (array) wp_unslash( $_POST['ing_main'] ) : array();

		$wpdb->delete( ASHP_DB::t( 'recipe_ingredients' ), array( 'recipe_id' => $id ), array( '%d' ) );

		$order = 0;
		foreach ( $names as $i => $raw ) {
			$nm = sanitize_text_field( $raw );
			if ( '' === trim( $nm ) ) {
				continue;
			}
			$ing_id = ASHP_DB::ensure_ingredient( $nm );
			if ( ! $ing_id ) {
				continue;
			}
			$val  = ( isset( $values[ $i ] ) && '' !== $values[ $i ] ) ? (float) $values[ $i ] : null;
			$unit = isset( $units[ $i ] ) ? sanitize_text_field( $units[ $i ] ) : '';
			$main = ! empty( $mains[ $i ] ) ? 1 : 0;

			$wpdb->insert( ASHP_DB::t( 'recipe_ingredients' ), array(
				'recipe_id'      => $id,
				'ingredient_id'  => $ing_id,
				'amount_value'   => $val,
				'amount_text'    => null !== $val ? trim( ASHP_Front::format_number( $val ) . ' ' . $unit ) : '',
				'unit'           => $unit,
				'is_main'        => $main,
				'amount_is_free' => ( null === $val && '' === $unit ) ? 1 : 0,
				'sort_order'     => $order,
			) );
			$order++;
		}

		ASHP_Importer::refresh_ingredient_counts();
		ASHP_DB::flush_cache();

		$back = self::url( 'recipe-new', array( 'id' => $id ) );
		wp_safe_redirect( add_query_arg( array( 'ashp_msg' => 'saved', 'set' => '1' ), $back ) );
		exit;
	}

	/** حذف غذا */
	public static function handle_delete_recipe() {
		global $wpdb;
		$id = isset( $_REQUEST['id'] ) ? (int) $_REQUEST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::guard( 'ashp_delete_' . $id );

		$wpdb->delete( ASHP_DB::t( 'recipe_ingredients' ), array( 'recipe_id' => $id ), array( '%d' ) );
		$wpdb->delete( ASHP_DB::t( 'recipes' ), array( 'id' => $id ), array( '%d' ) );
		ASHP_Importer::refresh_ingredient_counts();
		ASHP_DB::flush_cache();

		self::back( 'recipes', 'deleted' );
	}

	/** تغییر وضعیت فعال/حلال */
	public static function handle_toggle_recipe() {
		global $wpdb;
		$id    = isset( $_REQUEST['id'] ) ? (int) $_REQUEST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$field = isset( $_REQUEST['field'] ) ? sanitize_key( wp_unslash( $_REQUEST['field'] ) ) : 'is_active'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::guard( 'ashp_toggle_' . $id );

		if ( ! in_array( $field, array( 'is_active', 'is_halal' ), true ) ) {
			$field = 'is_active';
		}
		$table = ASHP_DB::t( 'recipes' );
		$cur   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT $field FROM $table WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->update( $table, array( $field => $cur ? 0 : 1 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );

		ASHP_DB::flush_cache();
		self::back( 'recipes', 'saved' );
	}

	/** ذخیرهٔ مادهٔ اولیه */
	public static function handle_save_ingredient() {
		self::guard( 'ashp_save_ingredient' );
		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$name = isset( $_POST['ing_name'] ) ? sanitize_text_field( wp_unslash( $_POST['ing_name'] ) ) : '';
		$grp  = isset( $_POST['group_key'] ) ? sanitize_key( wp_unslash( $_POST['group_key'] ) ) : 'other';
		// phpcs:enable

		if ( '' === $name ) {
			self::back( 'ingredients', 'error' );
		}
		$defs = ASHP_DB::ingredient_groups_def();
		if ( ! isset( $defs[ $grp ] ) ) {
			$grp = 'other';
		}

		$norm = ASHP_DB::normalize_key( $name );
		$data = array(
			'name'            => $name,
			'normalized_name' => $norm,
			'group_key'       => $grp,
			'slug'            => ASHP_DB::make_ingredient_slug( $name, $id ),
		);

		if ( $id ) {
			$wpdb->update( ASHP_DB::t( 'ingredients' ), $data, array( 'id' => $id ) );
		} else {
			$data['recipes_count'] = 0;
			$wpdb->insert( ASHP_DB::t( 'ingredients' ), $data );
		}

		ASHP_DB::flush_cache();
		self::back( 'ingredients', 'saved' );
	}

	/** حذف مادهٔ اولیه */
	public static function handle_delete_ingredient() {
		global $wpdb;
		$id = isset( $_REQUEST['id'] ) ? (int) $_REQUEST['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::guard( 'ashp_del_ing_' . $id );

		$used = (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM ' . ASHP_DB::t( 'recipe_ingredients' ) . ' WHERE ingredient_id = %d', $id ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
		if ( $used > 0 ) {
			self::back( 'ingredients', 'inuse', (string) $used );
		}

		$wpdb->delete( ASHP_DB::t( 'ingredients' ), array( 'id' => $id ), array( '%d' ) );
		ASHP_DB::flush_cache();
		self::back( 'ingredients', 'deleted' );
	}

	/** ورود داده */
	public static function handle_import() {
		self::guard( 'ashp_import' );
		$report = ASHP_Importer::run( true );
		self::back( 'data', 'imported', number_format_i18n( $report['recipes'] ) . ' غذا' );
	}

	/** بازشماری */
	public static function handle_recount() {
		self::guard( 'ashp_recount' );
		ASHP_Importer::refresh_ingredient_counts();
		self::back( 'data', 'recount' );
	}

	/** دریافت پشتیبان CSV */
	public static function handle_export() {
		self::guard( 'ashp_export' );
		global $wpdb;

		$recipes = $wpdb->get_results( 'SELECT * FROM ' . ASHP_DB::t( 'recipes' ) . ' ORDER BY id ASC', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=ashpazbashi-recipes-' . gmdate( 'Y-m-d' ) . '.csv' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // BOM برای اکسل

		if ( $recipes ) {
			fputcsv( $out, array_keys( $recipes[0] ) );
			foreach ( $recipes as $r ) {
				fputcsv( $out, array_values( $r ) );
			}
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/** برگهٔ تست سلامت */
	public static function page_health() {
		ASHP_Health::page();
	}

	/** بازسازی قواعد مسیر */
	public static function handle_flush_rules() {
		self::guard( 'ashp_flush' );
		ASHP_Router::register_rules();
		flush_rewrite_rules( true );
		self::back( 'flushed', __( 'قواعد مسیر از نو ساخته شد.', 'ashpazbashi' ) );
	}

	/** بازسازی جدول‌ها با dbDelta */
	public static function handle_rebuild_tables() {
		self::guard( 'ashp_rebuild' );
		ashp_core_install();
		self::back( 'rebuilt', __( 'جدول‌ها بررسی و در صورت نیاز اصلاح شدند.', 'ashpazbashi' ) );
	}


	/** برگهٔ ویرایش صفحه‌های ثابت سایت */
	public static function page_pages() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$pages = ASHP_DB::pages();
		self::hero( 'pages' );
		self::notice();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ashp-form">
			<input type="hidden" name="action" value="ashp_save_pages">
			<?php wp_nonce_field( 'ashp_pages' ); ?>

			<?php foreach ( $pages as $key => $label ) : ?>
				<div class="ashp-panel">
					<div class="ashp-panel__head">
						<h2><i>📄</i> <?php echo esc_html( $label ); ?></h2>
						<span class="ashp-muted"><?php echo esc_html( 'ashp_pages[' . $key . ']' ); ?></span>
					</div>
					<div class="ashp-panel__body">
						<?php
						$content = ASHP_DB::page_content( $key );
						if ( function_exists( 'wp_editor' ) ) {
							wp_editor( $content, 'ashp_page_' . $key, array(
								'textarea_name' => 'ashp_pages[' . $key . ']',
								'textarea_rows' => 12,
								'media_buttons' => false,
								'teeny'         => false,
							) );
						} else {
							?>
							<textarea class="ashp-input" name="ashp_pages[<?php echo esc_attr( $key ); ?>]" rows="10"><?php echo esc_textarea( $content ); ?></textarea>
							<?php
						}
						?>
					</div>
				</div>
			<?php endforeach; ?>

			<div class="ashp-actions">
				<button type="submit" class="ashp-btn ashp-btn--primary"><?php esc_html_e( 'ذخیرهٔ صفحه‌ها', 'ashpazbashi' ); ?></button>
				<span class="ashp-muted"><?php esc_html_e( 'این متن‌ها جای متن پیش‌فرض قالب را می‌گیرند.', 'ashpazbashi' ); ?></span>
			</div>
		</form>
		</div>
		<?php
	}

	/** ذخیرهٔ صفحه‌های ثابت */
	public static function handle_save_pages() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی ندارید.', 'ashpazbashi' ) );
		}
		check_admin_referer( 'ashp_pages' );

		$raw = isset( $_POST['ashp_pages'] ) ? (array) wp_unslash( $_POST['ashp_pages'] ) : array();
		foreach ( array_keys( ASHP_DB::pages() ) as $key ) {
			$html = isset( $raw[ $key ] ) ? (string) $raw[ $key ] : '';
			ASHP_DB::save_page_content( $key, wp_kses_post( $html ) );
		}
		self::back( 'pagesaved' );
	}
}

ASHP_Admin::init();


}
