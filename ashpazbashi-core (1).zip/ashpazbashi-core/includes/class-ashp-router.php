<?php
/**
 * مسیرها و بارگذاری قالب‌های اختصاصی آشپزباشی.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Router' ) ) {

class ASHP_Router {

	/* پیشوند ashpq_ عمداً با نام متغیرهای قالب یکی نیست؛ وردپرس همهٔ
	   query varها را به فضای گلوبال منتقل می‌کند. */
	const VAR_LIST   = 'ashpq_list';
	const VAR_CAT    = 'ashpq_cat';
	const VAR_SUB    = 'ashpq_sub';
	const VAR_RECIPE = 'ashpq_recipe';
	const VAR_ING    = 'ashpq_ing';
	const VAR_HUB    = 'ashpq_hub';

	/** ثبت متغیرهای درخواست */
	public static function register_query_vars() {
		add_rewrite_tag( '%' . self::VAR_LIST . '%', '([a-z0-9_-]+)' );
		add_rewrite_tag( '%' . self::VAR_CAT . '%', '([a-z0-9_-]+)' );
		add_rewrite_tag( '%' . self::VAR_SUB . '%', '([a-z0-9_-]+)' );
		add_rewrite_tag( '%' . self::VAR_RECIPE . '%', '([^&]+)' );
		add_rewrite_tag( '%' . self::VAR_ING . '%', '([^&]+)' );
		add_rewrite_tag( '%' . self::VAR_HUB . '%', '([a-z0-9_-]+)' );
	}

	/** ثبت قواعد بازنویسی */
	public static function register_rules() {
		/* فهرست همهٔ دستورها */
		add_rewrite_rule( '^recipes/?$', 'index.php?' . self::VAR_LIST . '=all', 'top' );

		/* یک دستور پخت */
		add_rewrite_rule( '^recipes/([^/]+)/?$', 'index.php?' . self::VAR_RECIPE . '=$matches[1]', 'top' );

		/* صفحهٔ انتخاب مواد اولیه */
		add_rewrite_rule( '^ingredients/?$', 'index.php?' . self::VAR_LIST . '=picker', 'top' );

		/* دو بخش اصلی: غذاها و مواد اولیه — نوشیدنی‌ها و دسرها */
		add_rewrite_rule( '^food/?$', 'index.php?' . self::VAR_HUB . '=food', 'top' );
		add_rewrite_rule( '^party/?$', 'index.php?' . self::VAR_HUB . '=party', 'top' );
		add_rewrite_rule( '^kids/?$', 'index.php?' . self::VAR_HUB . '=kids', 'top' );
		add_rewrite_rule( '^sweets/?$', 'index.php?' . self::VAR_HUB . '=sweets', 'top' );
		add_rewrite_rule( '^drinks/?$', 'index.php?' . self::VAR_HUB . '=sweets', 'top' ); // نام دیگر بخش دسر و نوشیدنی

		/* یک مادهٔ اولیه */
		add_rewrite_rule(
			'^ingredients/([^/]+)/?$',
			'index.php?' . self::VAR_LIST . '=ingredient&' . self::VAR_ING . '=$matches[1]',
			'top'
		);

		/* دسته‌ها و زیردسته‌ها — فقط اسلاگ‌های شناخته‌شده تا با برگه‌های وردپرس تضاد نکند */
		foreach ( ASHP_DB::taxonomy() as $cat => $info ) {
			add_rewrite_rule(
				'^' . preg_quote( $cat, '/' ) . '/?$',
				'index.php?' . self::VAR_LIST . '=category&' . self::VAR_CAT . '=' . $cat,
				'top'
			);
			foreach ( array_keys( $info['subs'] ) as $sub ) {
				add_rewrite_rule(
					'^' . preg_quote( $cat, '/' ) . '/' . preg_quote( $sub, '/' ) . '/?$',
					'index.php?' . self::VAR_LIST . '=category&' . self::VAR_CAT . '=' . $cat . '&' . self::VAR_SUB . '=' . $sub,
					'top'
				);
			}
		}
	}

	/** مقدار یک متغیر درخواست */
	public static function current_var( $var ) {
		$value = get_query_var( $var );

		if ( '' === $value || null === $value ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$value = isset( $_GET[ $var ] ) ? wp_unslash( $_GET[ $var ] ) : '';
		}

		if ( ! is_string( $value ) ) {
			return '';
		}

		$value = trim( $value );

		/* مسیرهای فارسی در نشانی اینترنتی رمزگذاری می‌شوند
		   (مثلاً %D8%A2%D8%B4). وردپرس مقدار خام را می‌دهد، پس تا زمانی که
		   درصدی در رشته هست، بازگشایی می‌کنیم تا با اسلاگ دیتابیس بخواند. */
		$guard = 0;
		while ( false !== strpos( $value, '%' ) && $guard < 5 ) {
			$decoded = urldecode( $value );
			if ( $decoded === $value ) {
				break;
			}
			$value = $decoded;
			$guard++;
		}

		return $value;
	}

	/* ---------------------------------------------------------------------
	 * تشخیص نوع صفحه
	 * ------------------------------------------------------------------ */

	public static function is_recipe_page() {
		return ( '' !== self::current_var( self::VAR_RECIPE ) );
	}

	public static function is_ingredient_page() {
		return ( '' !== self::current_var( self::VAR_ING ) );
	}

	public static function is_picker_page() {
		return ( 'picker' === self::current_var( self::VAR_LIST ) );
	}

	public static function is_hub_page() {
		return ( '' !== self::current_var( self::VAR_HUB ) );
	}

	/** عنوان بخش جاری */
	public static function hub_title() {
		$hub = self::current_var( self::VAR_HUB );
		if ( 'food' === $hub ) {
			return __( 'غذاها و مواد اولیه', 'ashpazbashi' );
		}
		if ( 'sweets' === $hub ) {
			return __( 'نوشیدنی‌ها و دسرها', 'ashpazbashi' );
		}
		if ( 'party' === $hub ) {
			return __( 'فود پارتی', 'ashpazbashi' );
		}
		if ( 'kids' === $hub ) {
			return __( 'غذای کودکان', 'ashpazbashi' );
		}
		if ( 'drinks' === $hub ) {
			return __( 'نوشیدنی‌ها', 'ashpazbashi' );
		}
		return __( 'آشپزباشی', 'ashpazbashi' );
	}

	/** آدرس بخش‌ها */
	public static function hub_url( $hub ) {
		return home_url( user_trailingslashit( $hub ) );
	}

	public static function is_list_page() {
		$list = self::current_var( self::VAR_LIST );
		return ( 'all' === $list || 'category' === $list );
	}

	public static function is_ashp_page() {
		return ( self::is_recipe_page() || self::is_ingredient_page() || self::is_picker_page()
			|| self::is_list_page() || self::is_hub_page() );
	}

	/** آدرس قالب در پوشهٔ قالب فعال */
	private static function theme_template( $file ) {
		$path = locate_template( $file );
		if ( $path ) {
			return $path;
		}
		/* اگر قالب دیگری فعال بود، از قالب پیش‌فرض داخلی افزونه استفاده کن */
		$fallback = ASHP_CORE_DIR . 'templates/' . $file;
		return file_exists( $fallback ) ? $fallback : '';
	}

	/** جلوگیری از ۴۰۴ شدن مسیرهای مجازی */
	public static function prevent_404() {
		if ( ! self::is_ashp_page() ) {
			return;
		}
		global $wp_query;
		if ( ! $wp_query ) {
			return;
		}
		$wp_query->is_404      = false;
		$wp_query->is_home     = false;
		$wp_query->is_archive  = false;
		$wp_query->is_category = false;

		if ( self::is_recipe_page() || self::is_ingredient_page() ) {
			$wp_query->is_singular = true;
			$wp_query->is_single   = true;
		}

		status_header( 200 );
	}

	/** بارگذاری قالب مناسب */
	public static function template_include( $template ) {
		if ( is_404() && self::is_ashp_page() ) {
			self::prevent_404();
		}

		if ( self::is_recipe_page() ) {
			$found = self::theme_template( 'ashp-recipe.php' );
			return $found ? $found : $template;
		}

		if ( self::is_ingredient_page() ) {
			$found = self::theme_template( 'ashp-ingredient.php' );
			return $found ? $found : $template;
		}

		if ( self::is_picker_page() ) {
			$found = self::theme_template( 'ashp-ingredients.php' );
			return $found ? $found : $template;
		}

		if ( self::is_hub_page() ) {
			$found = self::theme_template( 'ashp-hub.php' );
			return $found ? $found : $template;
		}

		if ( self::is_list_page() ) {
			$found = self::theme_template( 'ashp-recipes.php' );
			return $found ? $found : $template;
		}

		return $template;
	}
}

}
