<?php
/**
 * پاسخ‌های AJAX آشپزباشی: پیشنهاد غذا بر پایهٔ مواد و جست‌وجوی زنده.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Ajax' ) ) {

class ASHP_Ajax {

	public static function init() {
		add_action( 'wp_ajax_ashp_pick', array( __CLASS__, 'pick' ) );
		add_action( 'wp_ajax_nopriv_ashp_pick', array( __CLASS__, 'pick' ) );
		add_action( 'wp_ajax_ashp_search', array( __CLASS__, 'search' ) );
		add_action( 'wp_ajax_nopriv_ashp_search', array( __CLASS__, 'search' ) );
	}

	/** بررسی nonce */
	private static function guard() {
		if ( ! check_ajax_referer( 'ashp_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'msg' => __( 'نشست منقضی شده است. صفحه را دوباره باز کن.', 'ashpazbashi' ) ), 403 );
		}
	}

	/** محدودیت نرخ سبک بر پایهٔ IP */
	private static function rate_limited( $bucket, $seconds = 2 ) {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$key = 'ashp_rl_' . $bucket . '_' . md5( $ip );
		if ( get_transient( $key ) ) {
			return true;
		}
		set_transient( $key, 1, max( 1, (int) $seconds ) );
		return false;
	}

	/**
	 * پیشنهاد غذا بر پایهٔ مواد انتخاب‌شده.
	 */
	public static function pick() {
		self::guard();

		if ( self::rate_limited( 'pick', 2 ) ) {
			wp_send_json_error( array( 'msg' => __( 'کمی صبر کن و دوباره تلاش کن.', 'ashpazbashi' ) ), 429 );
		}

		$raw = isset( $_POST['ing'] ) ? (array) wp_unslash( $_POST['ing'] ) : array();
		$raw = ASHP_DB::clean_slugs( $raw, 40 );

		if ( count( $raw ) < 1 ) {
			wp_send_json_success( array( 'recipes' => array() ) );
		}

		/* با ۳ ماده، حداقل ۳ اشتراک؛ با مواد بیشتر، آستانه کمی نرم‌تر می‌شود. */
		$min_match = count( $raw ) >= 6 ? 3 : min( 3, count( $raw ) );

		$rows  = ASHP_DB::pick_recipes( $raw, 48, $min_match );
		$out   = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'name'  => $row['name'],
				'match' => (int) $row['match_cnt'],
				'total' => (int) $row['total_cnt'],
				'url'   => ASHP_DB::recipe_url( $row ),
			);
		}

		wp_send_json_success( array(
			'recipes' => $out,
			'picked'  => count( $raw ),
		) );
	}

	/**
	 * جست‌وجوی زنده — پیشنهاد نام غذا و مادهٔ اولیه.
	 */
	public static function search() {
		self::guard();

		if ( self::rate_limited( 'search', 1 ) ) {
			wp_send_json_error( array( 'msg' => __( 'کمی صبر کن.', 'ashpazbashi' ) ), 429 );
		}

		$q = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : '';
		$q = trim( $q );

		if ( '' === $q || mb_strlen( $q ) < 2 ) {
			wp_send_json_success( array( 'recipes' => array(), 'ingredients' => array() ) );
		}

		$recipes = ASHP_DB::search_recipes( $q, 6 );

		global $wpdb;
		$ings = self::table_prefix_ing();
		$like = '%' . $wpdb->esc_like( $q ) . '%';
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT name, slug, recipes_count FROM $ings WHERE name LIKE %s ORDER BY recipes_count DESC LIMIT 5", // phpcs:ignore WordPress.DB.PreparedSQL
				$like
			),
			ARRAY_A
		);

		$out_r = array();
		foreach ( $recipes as $r ) {
			$out_r[] = array(
				'name' => $r['name'],
				'url'  => ASHP_DB::recipe_url( $r ),
			);
		}

		$out_i = array();
		foreach ( (array) $rows as $r ) {
			$out_i[] = array(
				'name' => (string) $r['name'],
				'n'    => (int) $r['recipes_count'],
				'url'  => ASHP_DB::ingredient_url( (string) $r['slug'] ),
			);
		}

		wp_send_json_success( array(
			'recipes'     => $out_r,
			'ingredients' => $out_i,
		) );
	}

	private static function table_prefix_ing() {
		return ASHP_DB::t( 'ingredients' );
	}
}

ASHP_Ajax::init();

}
