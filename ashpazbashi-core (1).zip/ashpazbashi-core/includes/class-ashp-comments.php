<?php
/**
 * نظرات و امتیازدهی دستورهای پخت.
 *
 * هر دستور پخت یک کادر نظر با امتیاز ستاره‌ای دارد. نظرها ابتدا در وضعیت
 * «در انتظار» ذخیره می‌شوند و تا وقتی مدیر آن‌ها را تأیید نکند روی سایت
 * نمایش داده نمی‌شوند.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Comments' ) ) {

class ASHP_Comments {

	const VERSION        = '1.0.0';
	const STATUS_PENDING = 'pending';
	const STATUS_APPROVED = 'approved';
	const STATUS_REJECTED = 'rejected';

	/* ------------------------------------------------------------------
	 * تبدیل اعداد به رقم‌های فارسی
	 *
	 * نکتهٔ مهم: number_format_i18n() در وردپرس رقم‌ها را به فارسی تبدیل
	 * نمی‌کند و فقط جداکنندهٔ اعشار/هزارگان را از زبان سایت می‌گیرد.
	 * به همین دلیل امتیاز به شکل «5٫0» (رقم لاتین) کنار متن فارسی
	 * «از ۵» نمایش داده می‌شد. این سه تابع آن ناهماهنگی را رفع می‌کنند.
	 * ------------------------------------------------------------------ */

	/** تبدیل رقم‌های لاتین یک رشته به رقم‌های فارسی. */
	public static function to_fa_digits( $text ) {
		return strtr(
			(string) $text,
			array(
				'0' => '۰',
				'1' => '۱',
				'2' => '۲',
				'3' => '۳',
				'4' => '۴',
				'5' => '۵',
				'6' => '۶',
				'7' => '۷',
				'8' => '۸',
				'9' => '۹',
			)
		);
	}

	/** عدد اعشاری فارسی برای امتیاز: ۴٫۵ */
	public static function fa_rating( $value, $decimals = 1 ) {
		$s = number_format( (float) $value, (int) $decimals, '.', '' );
		$s = str_replace( '.', '٫', $s );
		return self::to_fa_digits( $s );
	}

	/** عدد صحیح فارسی با جداکنندهٔ هزارگان: ۱٬۲۴۵ */
	public static function fa_count( $value ) {
		$s = number_format_i18n( (int) $value );
		// جداکنندهٔ هزارگان هر چه بود، به شکل فارسی یکدست می‌شود.
		$s = str_replace( array( ',', '٬' ), '٬', $s );
		return self::to_fa_digits( $s );
	}

	/** نام جدول نظرات. */
	public static function table() {
		return ashp_core_table( 'comments' );
	}

	/** ساخت جدول. */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		$sql = "CREATE TABLE $table (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			recipe_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			recipe_slug VARCHAR(255) NOT NULL DEFAULT '',
			author_name VARCHAR(120) NOT NULL DEFAULT '',
			author_email VARCHAR(190) NOT NULL DEFAULT '',
			rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
			body TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			ip_hash CHAR(32) NOT NULL DEFAULT '',
			created_at DATETIME NULL DEFAULT NULL,
			approved_at DATETIME NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY ashp_r_status (recipe_id, status),
			KEY ashp_status (status, created_at)
		) $charset;";

		dbDelta( $sql );
		update_option( 'ashp_comments_ver', self::VERSION, false );
	}

	/**
	 * ساخت جدول روی سایت‌های موجود.
	 *
	 * بدون این، جدول فقط هنگام فعال‌سازی ساخته می‌شود و کاربری که فقط
	 * فایل‌ها را جایگزین می‌کند هرگز آن را نمی‌بیند.
	 */
	public static function maybe_install() {
		if ( get_option( 'ashp_comments_ver' ) !== self::VERSION ) {
			self::install();
		}
	}

	/* ---------------------------------------------------------------------
	 * داده
	 * ------------------------------------------------------------------ */

	/** ثبت یک نظر تازه. */
	public static function add( $recipe_id, $recipe_slug, $name, $email, $rating, $body ) {
		global $wpdb;

		$rating = max( 0, min( 5, (int) $rating ) );
		$ip     = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		$ok = $wpdb->insert(
			self::table(),
			array(
				'recipe_id'    => (int) $recipe_id,
				'recipe_slug'  => (string) $recipe_slug,
				'author_name'  => (string) $name,
				'author_email' => (string) $email,
				'rating'       => $rating,
				'body'         => (string) $body,
				'status'       => self::STATUS_PENDING,
				'ip_hash'      => $ip ? md5( $ip . wp_salt( 'auth' ) ) : '',
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		return $ok ? (int) $wpdb->insert_id : false;
	}

	/** آیا این بازدیدکننده همین اواخر نظر نداده است؟ */
	public static function is_rate_limited( $recipe_id ) {
		global $wpdb;
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		if ( '' === $ip ) {
			return false;
		}
		$hash  = md5( $ip . wp_salt( 'auth' ) );
		$table = self::table();
		$count = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table WHERE ip_hash = %s AND created_at > %s",
				$hash,
				gmdate( 'Y-m-d H:i:s', time() - 300 )
			)
		);
		return ( $count >= 3 );
	}

	/** نظرهای یک دستور پخت. */
	public static function list_for_recipe( $recipe_id, $status = self::STATUS_APPROVED, $limit = 100 ) {
		global $wpdb;
		$table = self::table();

		if ( '' === $status ) {
			return $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL
				$wpdb->prepare( "SELECT * FROM $table WHERE recipe_id = %d ORDER BY created_at DESC LIMIT %d", $recipe_id, $limit ),
				ARRAY_A
			);
		}

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare(
				"SELECT * FROM $table WHERE recipe_id = %d AND status = %s ORDER BY created_at DESC LIMIT %d",
				$recipe_id,
				$status,
				$limit
			),
			ARRAY_A
		);
	}

	/** میانگین امتیاز و تعداد نظر تأییدشده. */
	public static function stats( $recipe_id ) {
		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare(
				"SELECT COUNT(*) AS cnt, AVG(rating) AS avg_rating
				 FROM $table
				 WHERE recipe_id = %d AND status = %s AND rating > 0",
				$recipe_id,
				self::STATUS_APPROVED
			),
			ARRAY_A
		);

		$cnt = isset( $row['cnt'] ) ? (int) $row['cnt'] : 0;
		$avg = ( $cnt > 0 && isset( $row['avg_rating'] ) ) ? round( (float) $row['avg_rating'], 1 ) : 0.0;

		return array( 'count' => $cnt, 'average' => $avg );
	}

	/** تغییر وضعیت یک نظر. */
	public static function set_status( $id, $status ) {
		global $wpdb;
		if ( ! in_array( $status, array( self::STATUS_PENDING, self::STATUS_APPROVED, self::STATUS_REJECTED ), true ) ) {
			return false;
		}
		return (bool) $wpdb->update(
			self::table(),
			array(
				'status'      => $status,
				'approved_at' => ( self::STATUS_APPROVED === $status ) ? current_time( 'mysql' ) : null,
			),
			array( 'id' => (int) $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/** حذف یک نظر. */
	public static function delete( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( self::table(), array( 'id' => (int) $id ), array( '%d' ) );
	}

	/** فهرست نظرها برای پیشخوان. */
	public static function admin_list( $status = '', $limit = 200 ) {
		global $wpdb;
		$table = self::table();
		if ( '' === $status ) {
			return $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL
				$wpdb->prepare( "SELECT * FROM $table ORDER BY created_at DESC LIMIT %d", $limit ),
				ARRAY_A
			);
		}
		return $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare( "SELECT * FROM $table WHERE status = %s ORDER BY created_at DESC LIMIT %d", $status, $limit ),
			ARRAY_A
		);
	}

	public static function count_by_status( $status ) {
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL
			$wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", $status )
		);
	}

	/* ---------------------------------------------------------------------
	 * نمایش ستاره‌ها
	 * ------------------------------------------------------------------ */

	/** ستاره‌های نمایشی (فقط خواندنی). */
	public static function stars_html( $value, $count = 0 ) {
		$value = (float) $value;
		$out   = '<span class="ashp-stars-static" dir="ltr" aria-label="' .
			esc_attr( sprintf( '%s از ۵', self::fa_rating( $value ) ) ) . '">';
		for ( $i = 1; $i <= 5; $i++ ) {
			$cls   = ( $value >= $i - 0.25 ) ? 'is-on' : ( ( $value >= $i - 0.75 ) ? 'is-half' : '' );
			$out  .= '<span class="ashp-star ' . esc_attr( $cls ) . '">★</span>';
		}
		$out .= '</span>';
		return $out;
	}

	/* ---------------------------------------------------------------------
	 * پردازش فرم
	 * ------------------------------------------------------------------ */

	/** شناسهٔ کوتاه بازدیدکننده، برای نگه‌داشتن پیام نتیجه. */
	public static function visitor_key() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'anon';
		return md5( $ip . wp_salt( 'nonce' ) );
	}

	public static function flash_key() {
		return 'ashp_cflash_' . self::visitor_key();
	}

	/**
	 * پردازش ارسال فرم پیش از هر خروجی.
	 *
	 * اگر پردازش را داخل قالب انجام دهیم، هدرها ارسال شده‌اند و نمی‌توان
	 * ریدایرکت کرد؛ در نتیجه رفرش صفحه، نظر تکراری ثبت می‌کرد.
	 */
	public static function maybe_handle_submit() {
		if ( ! isset( $_POST['ashp_comment_submit'] ) ) {
			return;
		}
		if ( ! ( class_exists( 'ASHP_Router' ) && ASHP_Router::is_recipe_page() ) ) {
			return;
		}

		$result = self::handle_post();

		if ( is_array( $result ) ) {
			set_transient( self::flash_key(), $result, 120 );
		}

		$recipe = ASHP_DB::current_recipe();
		$url    = $recipe ? ASHP_DB::recipe_url( $recipe ) : home_url( '/' );

		wp_safe_redirect( $url . '#ashp-reviews' );
		exit;
	}

	public static function handle_post() {
		if ( ! isset( $_POST['ashp_comment_submit'] ) ) {
			return null;
		}
		if ( ! isset( $_POST['ashp_comment_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ashp_comment_nonce'] ) ), 'ashp_add_comment' ) ) {
			return array( 'type' => 'error', 'message' => 'نشست منقضی شده است. لطفاً صفحه را دوباره باز کنید.' );
		}

		// تلهٔ ربات‌ها
		if ( ! empty( $_POST['ashp_website'] ) ) {
			return array( 'type' => 'error', 'message' => 'ارسال ناموفق بود.' );
		}

		$recipe_id = isset( $_POST['ashp_recipe_id'] ) ? (int) $_POST['ashp_recipe_id'] : 0;
		$name      = isset( $_POST['ashp_name'] ) ? sanitize_text_field( wp_unslash( $_POST['ashp_name'] ) ) : '';
		$email     = isset( $_POST['ashp_email'] ) ? sanitize_email( wp_unslash( $_POST['ashp_email'] ) ) : '';
		$rating    = isset( $_POST['ashp_rating'] ) ? (int) $_POST['ashp_rating'] : 0;
		$body      = isset( $_POST['ashp_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ashp_body'] ) ) : '';

		if ( $recipe_id <= 0 ) {
			return array( 'type' => 'error', 'message' => 'دستور پخت شناسایی نشد.' );
		}
		if ( '' === $name ) {
			return array( 'type' => 'error', 'message' => 'لطفاً نام خود را بنویسید.' );
		}
		if ( $rating < 1 || $rating > 5 ) {
			return array( 'type' => 'error', 'message' => 'لطفاً به غذا امتیاز بدهید (از ۱ تا ۵ ستاره).' );
		}
		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $body, 'UTF-8' ) < 5 : strlen( $body ) < 5 ) {
			return array( 'type' => 'error', 'message' => 'متن نظر خیلی کوتاه است.' );
		}

		if ( self::is_rate_limited( $recipe_id ) ) {
			return array( 'type' => 'error', 'message' => 'تعداد نظرهای شما زیاد بوده است. چند دقیقه بعد دوباره تلاش کنید.' );
		}

		$slug = '';
		if ( class_exists( 'ASHP_DB' ) && method_exists( 'ASHP_DB', 'current_recipe' ) ) {
			$r = ASHP_DB::current_recipe();
			if ( $r && isset( $r['slug'] ) ) {
				$slug = (string) $r['slug'];
			}
		}

		$id = self::add( $recipe_id, $slug, $name, $email, $rating, $body );

		if ( ! $id ) {
			return array( 'type' => 'error', 'message' => 'ثبت نظر ناموفق بود. لطفاً دوباره تلاش کنید.' );
		}

		return array(
			'type'    => 'success',
			'message' => 'ممنون! نظر شما ثبت شد و پس از تأیید مدیر نمایش داده می‌شود.',
		);
	}

	/* ---------------------------------------------------------------------
	 * نمایش در صفحهٔ دستور پخت
	 * ------------------------------------------------------------------ */

	public static function render( $recipe ) {
		if ( ! is_array( $recipe ) || empty( $recipe['id'] ) ) {
			return;
		}

		$recipe_id = (int) $recipe['id'];
		$stats     = self::stats( $recipe_id );
		$comments  = self::list_for_recipe( $recipe_id, self::STATUS_APPROVED );

		// پیام نتیجهٔ ارسال، که پیش از رندر در template_redirect ذخیره شده است.
		$flash = get_transient( self::flash_key() );
		if ( $flash ) {
			delete_transient( self::flash_key() );
		}
		?>
		<section class="ashp-section ashp-reviews" id="ashp-reviews">
			<header class="ashp-section__head">
				<h2 class="ashp-section__title">نظرها و امتیاز</h2>
			</header>

			<div class="ashp-reviews__summary">
				<?php if ( $stats['count'] > 0 ) : ?>
					<div class="ashp-reviews__avg">
						<strong><?php echo esc_html( self::fa_rating( $stats['average'] ) ); ?></strong>
						<span class="ashp-reviews__avg-of">از ۵</span>
					</div>
					<div class="ashp-reviews__avg-meta">
						<?php echo self::stars_html( $stats['average'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<span class="ashp-reviews__count">
							<?php echo esc_html( sprintf( '%s نظر', self::fa_count( $stats['count'] ) ) ); ?>
						</span>
					</div>
				<?php else : ?>
					<p class="ashp-reviews__empty">هنوز کسی به این غذا امتیاز نداده. اولین نفر باشید!</p>
				<?php endif; ?>
			</div>

			<?php if ( is_array( $flash ) ) : ?>
				<div class="ashp-reviews__notice ashp-reviews__notice--<?php echo esc_attr( $flash['type'] ); ?>">
					<?php echo esc_html( $flash['message'] ); ?>
				</div>
			<?php endif; ?>

			<form class="ashp-review-form" method="post" action="#ashp-reviews">
				<?php wp_nonce_field( 'ashp_add_comment', 'ashp_comment_nonce' ); ?>
				<input type="hidden" name="ashp_recipe_id" value="<?php echo esc_attr( $recipe_id ); ?>">
				<input type="hidden" name="ashp_comment_submit" value="1">

				<p class="ashp-field" style="position:absolute;left:-9999px" aria-hidden="true">
					<label for="ashp_website">وب‌سایت</label>
					<input type="text" id="ashp_website" name="ashp_website" value="" tabindex="-1" autocomplete="off">
				</p>

				<div class="ashp-field">
					<span class="ashp-field__label">امتیاز شما به این غذا</span>
					<div class="ashp-rating-input" dir="ltr">
						<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
							<input type="radio" id="ashp-star-<?php echo (int) $i; ?>" name="ashp_rating" value="<?php echo (int) $i; ?>" required>
							<label for="ashp-star-<?php echo (int) $i; ?>" title="<?php echo esc_attr( self::to_fa_digits( $i ) . ' ستاره' ); ?>">★</label>
						<?php endfor; ?>
					</div>
				</div>

				<div class="ashp-field">
					<label class="ashp-field__label" for="ashp_name">نام شما</label>
					<input type="text" id="ashp_name" name="ashp_name" required maxlength="60"
						placeholder="مثلاً: مریم">
				</div>

				<div class="ashp-field">
					<label class="ashp-field__label" for="ashp_body">نظر شما دربارهٔ این غذا</label>
					<textarea id="ashp_body" name="ashp_body" rows="4" required maxlength="1200"
						placeholder="طعمش چطور شد؟ چه تغییری دادید که بهتر شد؟"></textarea>
				</div>

				<p class="ashp-review-form__hint">
					نظر شما پس از تأیید مدیر نمایش داده می‌شود.
				</p>

				<button type="submit" class="ashp-btn ashp-btn--primary">ثبت نظر</button>
			</form>

			<?php if ( $comments ) : ?>
				<ul class="ashp-review-list">
					<?php foreach ( $comments as $c ) : ?>
						<li class="ashp-review">
							<div class="ashp-review__head">
								<span class="ashp-review__name"><?php echo esc_html( $c['author_name'] ); ?></span>
								<?php echo self::stars_html( (float) $c['rating'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<span class="ashp-review__date">
									<?php echo esc_html( date_i18n( 'j F Y', strtotime( (string) $c['created_at'] ) ) ); ?>
								</span>
							</div>
							<div class="ashp-review__body"><?php echo wpautop( esc_html( $c['body'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * پیشخوان: مدیریت نظرها
	 * ------------------------------------------------------------------ */

	public static function admin_menu() {
		// زیرمنوی «نظرها» زیر منوی اصلی «آشپزباشی» در پیشخوان.
		$parent = class_exists( 'ASHP_Admin' ) ? ASHP_Admin::SLUG : 'options-general.php';

		add_submenu_page(
			$parent,
			'نظرها و امتیازها',
			'نظرها' . ( self::count_by_status( self::STATUS_PENDING ) ? ' <span class="update-plugins count-' . self::count_by_status( self::STATUS_PENDING ) . '"><span class="update-count">' . self::count_by_status( self::STATUS_PENDING ) . '</span></span>' : '' ),
			'manage_options',
			'ashp-comments',
			array( __CLASS__, 'admin_page' )
		);
	}

	public static function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		// پردازش اقدام‌ها
		if ( isset( $_GET['ashp_action'], $_GET['ashp_id'] ) && isset( $_GET['_wpnonce'] ) ) {
			$id     = (int) $_GET['ashp_id'];
			$action = sanitize_key( wp_unslash( $_GET['ashp_action'] ) );
			if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ashp_comment_' . $id ) ) {
				if ( 'approve' === $action ) {
					self::set_status( $id, self::STATUS_APPROVED );
				} elseif ( 'reject' === $action ) {
					self::set_status( $id, self::STATUS_REJECTED );
				} elseif ( 'delete' === $action ) {
					self::delete( $id );
				}
				echo '<div class="notice notice-success"><p>انجام شد.</p></div>';
			}
		}

		$filter = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : self::STATUS_PENDING;
		$rows   = self::admin_list( $filter );
		$base   = admin_url( 'admin.php?page=ashp-comments' );

		$tabs = array(
			self::STATUS_PENDING  => 'در انتظار',
			self::STATUS_APPROVED => 'تأییدشده',
			self::STATUS_REJECTED => 'ردشده',
			''                    => 'همه',
		);
		?>
		<div class="wrap" dir="rtl">
			<h1>نظرها و امتیازها</h1>
			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="nav-tab <?php echo ( $filter === $key ) ? 'nav-tab-active' : ''; ?>"
						href="<?php echo esc_url( $base . ( '' !== $key ? '&status=' . $key : '' ) ); ?>">
						<?php echo esc_html( $label ); ?>
						(<?php echo esc_html( self::fa_count( '' === $key ? array_sum( array( self::count_by_status( self::STATUS_PENDING ), self::count_by_status( self::STATUS_APPROVED ), self::count_by_status( self::STATUS_REJECTED ) ) ) : self::count_by_status( $key ) ) ); ?>)
					</a>
				<?php endforeach; ?>
			</h2>

			<?php if ( ! $rows ) : ?>
				<p>چیزی برای نمایش نیست.</p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th style="width:70px">امتیاز</th>
							<th style="width:130px">نام</th>
							<th>نظر</th>
							<th style="width:150px">غذا</th>
							<th style="width:130px">تاریخ</th>
							<th style="width:210px">اقدام</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $rows as $c ) : ?>
						<?php
						$recipe_url = '';
						if ( class_exists( 'ASHP_DB' ) && method_exists( 'ASHP_DB', 'recipe_url' ) && ! empty( $c['recipe_slug'] ) ) {
							$recipe_url = ASHP_DB::recipe_url( $c['recipe_slug'] );
						}
						$n_ap = wp_nonce_url( $base . '&ashp_action=approve&ashp_id=' . (int) $c['id'], 'ashp_comment_' . (int) $c['id'] );
						$n_rj = wp_nonce_url( $base . '&ashp_action=reject&ashp_id=' . (int) $c['id'], 'ashp_comment_' . (int) $c['id'] );
						$n_dl = wp_nonce_url( $base . '&ashp_action=delete&ashp_id=' . (int) $c['id'], 'ashp_comment_' . (int) $c['id'] );
						?>
						<tr>
							<td><?php echo esc_html( self::to_fa_digits( $c['rating'] ) . '/۵' ); ?></td>
							<td><strong><?php echo esc_html( $c['author_name'] ); ?></strong></td>
							<td><?php echo esc_html( wp_trim_words( (string) $c['body'], 40 ) ); ?></td>
							<td>
								<?php if ( $recipe_url ) : ?>
									<a href="<?php echo esc_url( $recipe_url ); ?>" target="_blank" rel="noopener">
										<?php echo esc_html( $c['recipe_slug'] ); ?>
									</a>
								<?php else : ?>
									<?php echo esc_html( $c['recipe_slug'] ); ?>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( (string) $c['created_at'] ); ?></td>
							<td>
								<?php if ( self::STATUS_APPROVED !== $c['status'] ) : ?>
									<a class="button button-primary" href="<?php echo esc_url( $n_ap ); ?>">تأیید</a>
								<?php endif; ?>
								<?php if ( self::STATUS_REJECTED !== $c['status'] ) : ?>
									<a class="button" href="<?php echo esc_url( $n_rj ); ?>">رد</a>
								<?php endif; ?>
								<a class="button" style="color:#b32d2e" href="<?php echo esc_url( $n_dl ); ?>"
									onclick="return confirm('این نظر برای همیشه حذف شود؟');">حذف</a>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}
}

}
