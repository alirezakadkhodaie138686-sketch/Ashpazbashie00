<?php
/**
 * برگهٔ «بستهٔ دیتابیس» — وضعیت و نصب داده‌ها.
 *
 * این برگه داخل خود افزونهٔ موتور است تا نصب دیتابیس یک مرحله و مستقل انجام
 * شود: فایل‌های داده همراه همین افزونه‌اند و از همین‌جا هم وضعیت‌شان دیده
 * می‌شود و هم با یک کلیک داخل جدول‌های وردپرس ریخته می‌شوند.
 *
 * @package Ashpazbashi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * فایل‌های دادهٔ همراه افزونه.
 *
 * @return array
 */
function ashp_dbi_files() {
	$dir  = ASHP_Importer::data_dir();
	$list = array(
		'recipes.csv'            => __( 'دستورهای پخت', 'ashpazbashi-core' ),
		'ingredients.csv'        => __( 'مواد اولیه', 'ashpazbashi-core' ),
		'recipe_ingredients.csv' => __( 'پیوند دستور و مواد', 'ashpazbashi-core' ),
	);
	$out = array();
	foreach ( $list as $name => $label ) {
		$path         = $dir . $name;
		$out[ $name ] = array(
			'label'  => $label,
			'exists' => file_exists( $path ),
			'size'   => file_exists( $path ) ? (int) filesize( $path ) : 0,
		);
	}
	return $out;
}

/**
 * وضعیت جدول‌های دیتابیس.
 *
 * @return array
 */
function ashp_dbi_counts() {
	global $wpdb;
	$list = array(
		'recipes'            => __( 'دستور', 'ashpazbashi-core' ),
		'ingredients'        => __( 'مادهٔ اولیه', 'ashpazbashi-core' ),
		'recipe_ingredients' => __( 'پیوند', 'ashpazbashi-core' ),
	);
	$out = array();
	foreach ( $list as $short => $label ) {
		$table  = ashp_core_table( $short );
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB
		$count  = 0;
		if ( $exists ) {
			$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" ); // phpcs:ignore WordPress.DB
		}
		$out[ $short ] = array(
			'label'  => $label,
			'exists' => (bool) $exists,
			'count'  => $count,
		);
	}
	return $out;
}

/** افزودن برگه به منوی آشپزباشی. */
function ashp_dbi_menu() {
	add_submenu_page(
		ASHP_Admin::SLUG,
		__( 'بستهٔ دیتابیس', 'ashpazbashi-core' ),
		__( 'بستهٔ دیتابیس', 'ashpazbashi-core' ),
		ASHP_Admin::CAP,
		'ashpazbashi-database',
		'ashp_dbi_page'
	);
}
add_action( 'admin_menu', 'ashp_dbi_menu', 21 );

/** یادداشت پس از فعال‌سازی افزونه. */
function ashp_dbi_activate_notice() {
	set_transient( 'ashp_dbi_activated', 1, 5 * MINUTE_IN_SECONDS );
}
add_action( 'activated_plugin', 'ashp_dbi_activate_notice' );

/** نمایش یادداشت راهنما. */
function ashp_dbi_notice() {
	if ( ! current_user_can( ASHP_Admin::CAP ) || ! get_transient( 'ashp_dbi_activated' ) ) {
		return;
	}
	delete_transient( 'ashp_dbi_activated' );
	printf(
		'<div class="notice notice-info is-dismissible"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
		esc_html__( 'افزونه فعال شد.', 'ashpazbashi-core' ),
		esc_html__( 'دیتابیس را از این‌جا نصب کن (یک کلیک):', 'ashpazbashi-core' ),
		esc_url( admin_url( 'admin.php?page=ashpazbashi-database' ) ),
		esc_html__( 'بستهٔ دیتابیس', 'ashpazbashi-core' )
	);
}
add_action( 'admin_notices', 'ashp_dbi_notice' );

/** برگهٔ وضعیت و نصب. */
function ashp_dbi_page() {
	if ( ! current_user_can( ASHP_Admin::CAP ) ) {
		return;
	}
	$files  = ashp_dbi_files();
	$counts = ashp_dbi_counts();
	$ready  = ( $counts['recipes']['count'] > 0 );

	$msg = isset( $_GET['ashp-dbi'] ) ? sanitize_key( wp_unslash( $_GET['ashp-dbi'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="wrap ashp-admin">
		<h1><?php esc_html_e( 'بستهٔ دیتابیس', 'ashpazbashi-core' ); ?></h1>

		<?php if ( 'done' === $msg ) : ?>
			<div class="ashp-msg ashp-msg--ok"><?php esc_html_e( 'داده‌ها با موفقیت داخل دیتابیس ریخته شد.', 'ashpazbashi-core' ); ?></div>
		<?php elseif ( 'nofile' === $msg ) : ?>
			<div class="ashp-msg ashp-msg--err"><?php esc_html_e( 'فایل‌های داده پیدا نشد؛ افزونه را کامل و دوباره نصب کن.', 'ashpazbashi-core' ); ?></div>
		<?php endif; ?>

		<div class="ashp-msg <?php echo $ready ? 'ashp-msg--ok' : 'ashp-msg--warn'; ?>">
			<?php if ( $ready ) : ?>
				<?php
				printf(
					/* translators: 1: recipes, 2: ingredients, 3: links */
					esc_html__( 'دیتابیس نصب است: %1$s دستور، %2$s مادهٔ اولیه، %3$s پیوند.', 'ashpazbashi-core' ),
					esc_html( number_format_i18n( $counts['recipes']['count'] ) ),
					esc_html( number_format_i18n( $counts['ingredients']['count'] ) ),
					esc_html( number_format_i18n( $counts['recipe_ingredients']['count'] ) )
				);
				?>
			<?php else : ?>
				<?php esc_html_e( 'دیتابیس خالی است؛ دکمهٔ نصب زیر را بزن.', 'ashpazbashi-core' ); ?>
			<?php endif; ?>
		</div>

		<h2><?php esc_html_e( 'فایل‌های داده (همراه همین افزونه)', 'ashpazbashi-core' ); ?></h2>
		<table class="widefat striped" style="max-width:820px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'فایل', 'ashpazbashi-core' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'ashpazbashi-core' ); ?></th>
					<th><?php esc_html_e( 'حجم', 'ashpazbashi-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $files as $name => $info ) : ?>
				<tr>
					<td><code><?php echo esc_html( $name ); ?></code><br><small><?php echo esc_html( $info['label'] ); ?></small></td>
					<td><?php echo $info['exists'] ? '<span style="color:#0a7c3f">&#10004; ' . esc_html__( 'موجود', 'ashpazbashi-core' ) . '</span>' : '<span style="color:#b32d2e">&#10006; ' . esc_html__( 'پیدا نشد', 'ashpazbashi-core' ) . '</span>'; ?></td>
					<td><?php echo $info['size'] ? esc_html( size_format( $info['size'] ) ) : '&mdash;'; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'جدول‌های دیتابیس', 'ashpazbashi-core' ); ?></h2>
		<table class="widefat striped" style="max-width:820px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'جدول', 'ashpazbashi-core' ); ?></th>
					<th><?php esc_html_e( 'ساخته شده؟', 'ashpazbashi-core' ); ?></th>
					<th><?php esc_html_e( 'تعداد رکورد', 'ashpazbashi-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $counts as $short => $c ) : ?>
				<tr>
					<td><code><?php echo esc_html( $short ); ?></code> — <?php echo esc_html( $c['label'] ); ?></td>
					<td><?php echo $c['exists'] ? '&#10004;' : '&#10006;'; ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $c['count'] ) ); ?></strong></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<p style="margin-top:20px">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="ashp_import">
				<?php wp_nonce_field( 'ashp_import' ); ?>
				<button class="button button-primary button-hero" type="submit"
					onclick="return confirm('<?php echo esc_js( __( 'داده‌ها از صفر داخل دیتابیس ریخته شود؟ (رکوردهای فعلی جای‌گزین می‌شوند)', 'ashpazbashi-core' ) ); ?>')">
					<?php echo $ready ? esc_html__( 'بازسازی داده‌ها در دیتابیس', 'ashpazbashi-core' ) : esc_html__( 'نصب داده‌ها در دیتابیس', 'ashpazbashi-core' ); ?>
				</button>
			</form>
		</p>
		<p class="description" style="max-width:820px">
			<?php esc_html_e( 'همان کاری را می‌کند که «آشپزباشی ← داده‌ها» انجام می‌دهد. اگر داده‌ها نصب شده‌اند و مشکلی نداری، لازم نیست دوباره اجرا کنی.', 'ashpazbashi-core' ); ?>
		</p>
	</div>
	<?php
}
