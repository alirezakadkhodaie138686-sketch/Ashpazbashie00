<?php
/**
 * صفحهٔ «تست سلامت» — اجرای واقعی کوئری‌ها و نمایش خطای دیتابیس.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Health' ) ) {

class ASHP_Health {

	/** اجرای همهٔ بررسی‌ها */
	public static function checks() {
		global $wpdb;

		$t_recipes = ASHP_DB::t( 'recipes' );
		$t_ings    = ASHP_DB::t( 'ingredients' );
		$t_rel     = ASHP_DB::t( 'recipe_ingredients' );

		$out = array();

		// ۱) وجود جدول‌ها
		foreach ( array( 'recipes' => $t_recipes, 'ingredients' => $t_ings, 'recipe_ingredients' => $t_rel ) as $label => $table ) {
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.PreparedSQL
			$out[] = array(
				'label'  => sprintf( /* translators: %s: table name */ __( 'جدول %s وجود دارد', 'ashpazbashi' ), $label ),
				'ok'     => ( $found === $table ),
				'detail' => $table,
			);
		}

		if ( $wpdb->last_error ) {
			$out[] = array(
				'label'  => __( 'ساخت/بررسی جدول‌ها', 'ashpazbashi' ),
				'ok'     => false,
				'detail' => $wpdb->last_error,
			);
		}

		// ۲) شمارش ردیف‌ها
		foreach ( array( 'recipes' => $t_recipes, 'ingredients' => $t_ings, 'recipe_ingredients' => $t_rel ) as $label => $table ) {
			$n     = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $table ); // phpcs:ignore WordPress.DB.PreparedSQL
			$out[] = array(
				'label'  => sprintf( /* translators: %s: table name */ __( 'ردیف‌های %s', 'ashpazbashi' ), $label ),
				'ok'     => ( $n > 0 ),
				'detail' => number_format_i18n( $n ) . ' ردیف' . ( $wpdb->last_error ? ' — خطا: ' . $wpdb->last_error : '' ),
			);
		}

		// ۳) خواندن خام یک ردیف
		$row = $wpdb->get_row( 'SELECT * FROM ' . $t_recipes . ' LIMIT 1', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out[] = array(
			'label'  => __( 'خواندن خام یک دستور', 'ashpazbashi' ),
			'ok'     => is_array( $row ),
			'detail' => is_array( $row )
				? ( isset( $row['name'] ) ? $row['name'] : '—' ) . ' | اسلاگ: ' . ( isset( $row['slug'] ) ? $row['slug'] : '—' )
				: ( $wpdb->last_error ? $wpdb->last_error : 'ردیفی برنگشت' ),
		);

		// ۴) کوئری فهرست
		$res   = ASHP_DB::query_recipes( array( 'per_page' => 3, 'page' => 1 ) );
		$rows  = isset( $res['rows'] ) ? count( $res['rows'] ) : 0;
		$total = isset( $res['total'] ) ? (int) $res['total'] : 0;
		$out[] = array(
			'label'  => __( 'کوئری فهرست دستورها', 'ashpazbashi' ),
			'ok'     => ( $rows > 0 ),
			'detail' => sprintf( 'تعداد کل: %s | ردیف بازگشتی: %s', number_format_i18n( $total ), number_format_i18n( $rows ) )
				. ( $wpdb->last_error ? ' — خطا: ' . $wpdb->last_error : '' ),
		);

		// ۵) یافتن با اسلاگ
		$slug    = is_array( $row ) && ! empty( $row['slug'] ) ? $row['slug'] : '';
		$by_slug = '' !== $slug ? ASHP_DB::get_by_slug( $slug ) : null;
		$out[]   = array(
			'label'  => __( 'یافتن دستور با اسلاگ', 'ashpazbashi' ),
			'ok'     => is_array( $by_slug ),
			'detail' => '' === $slug
				? 'اسلاگی برای آزمایش نبود'
				: 'اسلاگ: ' . $slug . ( is_array( $by_slug ) ? ' → پیدا شد' : ' → پیدا نشد' ),
		);

		// اسلاگ رمزگذاری‌شده (همان چیزی که در نشانی اینترنتی می‌آید)
		if ( '' !== $slug ) {
			$enc     = urlencode( $slug );
			$decoded = ASHP_DB::get_by_slug( $enc );
			$out[]   = array(
				'label'  => __( 'یافتن دستور با اسلاگ رمزگذاری‌شده', 'ashpazbashi' ),
				'ok'     => is_array( $decoded ),
				'detail' => $enc . ( is_array( $decoded ) ? ' → پیدا شد' : ' → پیدا نشد' ),
			);
		}

		// ۶) مواد اولیهٔ یک دستور
		if ( is_array( $row ) ) {
			$ings  = ASHP_DB::recipe_ingredients( (int) $row['id'] );
			$out[] = array(
				'label'  => __( 'مواد اولیهٔ یک دستور', 'ashpazbashi' ),
				'ok'     => count( $ings ) > 0,
				'detail' => number_format_i18n( count( $ings ) ) . ' ماده'
					. ( $wpdb->last_error ? ' — خطا: ' . $wpdb->last_error : '' ),
			);
		}

		// ۷) موتور پیشنهاد
		$slugs = $wpdb->get_col( 'SELECT slug FROM ' . $t_ings . ' ORDER BY recipes_count DESC LIMIT 3' ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $slugs ) {
			$picks = ASHP_DB::pick_recipes( $slugs, 5, 1 );
			$out[] = array(
				'label'  => __( 'موتور پیشنهاد غذا', 'ashpazbashi' ),
				'ok'     => count( $picks ) > 0,
				'detail' => implode( '، ', $slugs ) . ' → ' . number_format_i18n( count( $picks ) ) . ' پیشنهاد'
					. ( $wpdb->last_error ? ' — خطا: ' . $wpdb->last_error : '' ),
			);
		}

		// ۸) جست‌وجو
		if ( is_array( $row ) && ! empty( $row['name'] ) ) {
			$word = explode( ' ', $row['name'] );
			$word = $word[0];
			$hits = ASHP_DB::search_recipes( $word, 5 );
			$out[] = array(
				'label'  => __( 'جست‌وجو', 'ashpazbashi' ),
				'ok'     => count( $hits ) > 0,
				'detail' => $word . ' → ' . number_format_i18n( count( $hits ) ) . ' نتیجه'
					. ( $wpdb->last_error ? ' — خطا: ' . $wpdb->last_error : '' ),
			);
		}

		// ۹) قواعد مسیر
		$rules = get_option( 'rewrite_rules' );
		$has   = is_array( $rules ) && (bool) preg_grep( '/ashpq_/', array_keys( $rules ) );
		$out[] = array(
			'label'  => __( 'قواعد مسیر آشپزباشی ثبت شده‌اند', 'ashpazbashi' ),
			'ok'     => $has,
			'detail' => $has
				? __( 'درست است', 'ashpazbashi' )
				: __( 'ثبت نشده — از دکمهٔ «بازسازی قواعد مسیر» استفاده کنید', 'ashpazbashi' ),
		);

		// ۱۰) دادهٔ ورودی
		$n = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t_recipes . ' WHERE is_active = 1' ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out[] = array(
			'label'  => __( 'داده وارد شده است', 'ashpazbashi' ),
			'ok'     => ( $n > 0 ),
			'detail' => number_format_i18n( $n ) . ' دستور فعال',
		);

		// ۱۱) محیط
		$out[] = array(
			'label'  => __( 'محیط اجرا', 'ashpazbashi' ),
			'ok'     => true,
			'detail' => sprintf(
				'PHP %s · MySQL %s · وردپرس %s · پیشوند جدول: %s',
				PHP_VERSION,
				$wpdb->db_version(),
				get_bloginfo( 'version' ),
				$wpdb->prefix
			),
		);

		return $out;
	}

	/** نمایش صفحه */
	public static function page() {
		if ( ! current_user_can( ASHP_Admin::CAP ) ) {
			return;
		}

		$checks = self::checks();
		$failed = 0;
		foreach ( $checks as $c ) {
			if ( empty( $c['ok'] ) ) {
				$failed++;
			}
		}
		?>
		<div class="wrap ashp-admin">
			<?php ASHP_Admin::render_notice(); ?>
			<div class="ashp-hero-mini">
				<div>
					<h1><?php esc_html_e( 'تست سلامت آشپزباشی', 'ashpazbashi' ); ?></h1>
					<p><?php esc_html_e( 'این صفحه کوئری‌های اصلی سایت را واقعاً اجرا می‌کند و خطای دیتابیس را نشان می‌دهد.', 'ashpazbashi' ); ?></p>
				</div>
				<div class="ashp-hero-mini__stat <?php echo $failed ? 'is-bad' : 'is-good'; ?>">
					<strong><?php echo esc_html( number_format_i18n( count( $checks ) - $failed ) ); ?></strong>
					<span><?php echo $failed ? esc_html__( 'مورد ناموفق', 'ashpazbashi' ) : esc_html__( 'همه سالم', 'ashpazbashi' ); ?></span>
				</div>
			</div>

			<div class="ashp-panel">
				<table class="ashp-table">
					<thead>
						<tr>
							<th style="width:44px"></th>
							<th><?php esc_html_e( 'بررسی', 'ashpazbashi' ); ?></th>
							<th><?php esc_html_e( 'نتیجه', 'ashpazbashi' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $checks as $c ) : ?>
						<tr>
							<td class="ashp-mark <?php echo $c['ok'] ? 'is-good' : 'is-bad'; ?>">
								<?php echo $c['ok'] ? '✔' : '✖'; ?>
							</td>
							<td><?php echo esc_html( $c['label'] ); ?></td>
							<td><code><?php echo esc_html( $c['detail'] ); ?></code></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="ashp-grid-2">
				<div class="ashp-panel">
					<h2><i>🔄</i> <?php esc_html_e( 'بازسازی قواعد مسیر', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint"><?php esc_html_e( 'اگر صفحه‌های دستور پخت یا دسته‌ها ۴۰۴ می‌دهند، این کار را انجام دهید.', 'ashpazbashi' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'ashp_flush' ); ?>
						<input type="hidden" name="action" value="ashp_flush_rules">
						<button class="ashp-btn ashp-btn--ghost" type="submit"><?php esc_html_e( 'بازسازی قواعد مسیر', 'ashpazbashi' ); ?></button>
					</form>
				</div>

				<div class="ashp-panel">
					<h2><i>🛠</i> <?php esc_html_e( 'بازسازی جدول‌ها', 'ashpazbashi' ); ?></h2>
					<p class="ashp-panel__hint"><?php esc_html_e( 'اگر ستونی گم شده باشد، دوباره ساخته می‌شود. داده‌ها پاک نمی‌شوند.', 'ashpazbashi' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'ashp_rebuild' ); ?>
						<input type="hidden" name="action" value="ashp_rebuild_tables">
						<button class="ashp-btn ashp-btn--ghost" type="submit"><?php esc_html_e( 'بازسازی جدول‌ها', 'ashpazbashi' ); ?></button>
					</form>
				</div>
			</div>

			<div class="ashp-panel">
				<h2><i>📋</i> <?php esc_html_e( 'اطلاعاتی که برای پشتیبانی لازم است', 'ashpazbashi' ); ?></h2>
				<p class="ashp-panel__hint"><?php esc_html_e( 'این متن را کپی کنید و برای پشتیبانی بفرستید.', 'ashpazbashi' ); ?></p>
				<textarea class="ashp-report" rows="14" readonly onclick="this.select()"><?php
				echo esc_textarea( self::report_text( $checks ) );
				?></textarea>
			</div>
		</div>
		<?php
	}

	/** متن ساده برای کپی‌کردن */
	private static function report_text( $checks ) {
		global $wpdb;
		$lines   = array();
		$lines[] = 'آشپزباشی — گزارش سلامت';
		$lines[] = 'تاریخ: ' . gmdate( 'Y-m-d H:i' ) . ' UTC';
		$lines[] = 'سایت: ' . home_url();
		$lines[] = '';
		foreach ( $checks as $c ) {
			$lines[] = ( $c['ok'] ? '[OK]   ' : '[FAIL] ' ) . $c['label'] . ' → ' . $c['detail'];
		}
		$lines[] = '';
		$lines[] = 'آخرین خطای دیتابیس: ' . ( $wpdb->last_error ? $wpdb->last_error : 'ندارد' );
		return implode( "\n", $lines );
	}
}

}
