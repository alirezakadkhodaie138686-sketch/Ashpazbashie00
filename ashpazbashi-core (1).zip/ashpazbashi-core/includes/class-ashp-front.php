<?php
/**
 * توابع نمایشی آشپزباشی — همهٔ خروجی‌ها این‌جا escape می‌شوند.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_Front' ) ) {

class ASHP_Front {

	/** برچسب زمان: «۴۵ دقیقه» یا «۲ ساعت و ۱۵ دقیقه» */
	public static function time_label( $minutes ) {
		$minutes = (float) $minutes;
		if ( $minutes <= 0 ) {
			return '';
		}
		if ( $minutes < 60 ) {
			/* translators: %s: minutes */
			return sprintf( __( '%s دقیقه', 'ashpazbashi' ), number_format_i18n( round( $minutes ) ) );
		}
		$h = (int) floor( $minutes / 60 );
		$m = (int) round( $minutes - ( $h * 60 ) );
		if ( $m > 0 ) {
			/* translators: 1: hours, 2: minutes */
			return sprintf( __( '%1$s ساعت و %2$s دقیقه', 'ashpazbashi' ), number_format_i18n( $h ), number_format_i18n( $m ) );
		}
		/* translators: %s: hours */
		return sprintf( __( '%s ساعت', 'ashpazbashi' ), number_format_i18n( $h ) );
	}

	public static function total_time( $recipe ) {
		$p = isset( $recipe['prep_time_min'] ) ? (float) $recipe['prep_time_min'] : 0;
		$c = isset( $recipe['cook_time_min'] ) ? (float) $recipe['cook_time_min'] : 0;
		return $p + $c;
	}

	public static function servings_label( $servings ) {
		$servings = (int) $servings;
		if ( $servings < 1 ) {
			return '';
		}
		/* translators: %s: number of servings */
		return sprintf( __( 'برای %s نفر', 'ashpazbashi' ), number_format_i18n( $servings ) );
	}

	/** برچسب مقدار + واحد برای یک مادهٔ اولیه */
	public static function amount_label( $ing ) {
		if ( ! empty( $ing['amount_is_free'] ) ) {
			return __( 'به میزان لازم', 'ashpazbashi' );
		}

		$num  = isset( $ing['amount_value'] ) && null !== $ing['amount_value'] ? (float) $ing['amount_value'] : null;
		$unit = isset( $ing['unit'] ) ? trim( (string) $ing['unit'] ) : '';
		$text = isset( $ing['amount_text'] ) ? trim( (string) $ing['amount_text'] ) : '';

		if ( null === $num ) {
			return '' !== $text ? $text : '';
		}

		$num_label = self::format_number( $num );
		if ( '' === $unit ) {
			return $num_label;
		}
		return $num_label . ' ' . $unit;
	}

	/** عدد را بدون اعشار بی‌مورد نمایش می‌دهد؛ «۱٫۵» و «۲» */
	public static function format_number( $num ) {
		$num = (float) $num;
		if ( abs( $num - round( $num ) ) < 0.001 ) {
			return number_format_i18n( (int) round( $num ) );
		}
		$locale = get_locale();
		$str    = number_format( $num, 2, '.', '' );
		$str    = rtrim( rtrim( $str, '0' ), '.' );
		return ( 'fa_IR' === $locale ) ? str_replace( '.', '٫', $str ) : $str;
	}

	/** برچسب دستهٔ سختی */
	public static function difficulty_label( $difficulty ) {
		$map = array(
			'مبتدی'    => __( 'مبتدی', 'ashpazbashi' ),
			'متوسط'    => __( 'متوسط', 'ashpazbashi' ),
			'پیشرفته'  => __( 'پیشرفته', 'ashpazbashi' ),
			'حرفه ای'  => __( 'حرفه‌ای', 'ashpazbashi' ),
		);
		return isset( $map[ $difficulty ] ) ? $map[ $difficulty ] : '';
	}

	/** نشان‌های اطلاعاتی یک دستور */
	public static function recipe_badges( $recipe ) {
		$out = '';

		$total = self::total_time( $recipe );
		if ( $total > 0 ) {
			$out .= '<span class="ashp-badge ashp-badge--neon">⏱ ' . esc_html( self::time_label( $total ) ) . '</span>';
		}

		if ( ! empty( $recipe['servings'] ) ) {
			$out .= '<span class="ashp-badge">🍽 ' . esc_html( self::servings_label( $recipe['servings'] ) ) . '</span>';
		}

		$diff = self::difficulty_label( isset( $recipe['difficulty'] ) ? $recipe['difficulty'] : '' );
		if ( '' !== $diff ) {
			$out .= '<span class="ashp-badge">🧑‍🍳 ' . esc_html( $diff ) . '</span>';
		}

		if ( ! empty( $recipe['cooking_method'] ) ) {
			$out .= '<span class="ashp-badge">' . esc_html( $recipe['cooking_method'] ) . '</span>';
		}

		$out .= self::region_badge( $recipe );

		if ( ! empty( $recipe['calories_kcal'] ) ) {
			$out .= '<span class="ashp-badge">🔥 ' . esc_html( number_format_i18n( (int) $recipe['calories_kcal'] ) ) . ' ' . esc_html__( 'کالری', 'ashpazbashi' ) . '</span>';
		}

		/* نشان‌های وضعیت مراحل (دستور کامل / بازبینی‌نشده / بدون متن مراحل)
		   حذف شدند: همهٔ دستورها طرز تهیهٔ کامل و ویراستاری‌شده دارند. */

		if ( self::is_halal( $recipe ) ) {
			// برچسب حلال به درخواست کارفرما برداشته شد.
		}

		return $out;
	}

	/**
	 * نشان استان/کشور.
	 *
	 * غذای ایرانی، استانش را می‌گیرد و غذای خارجی، کشورش را. فقط جاهایی
	 * مقداردهی شده‌اند که با اطمینان قابل تشخیص بوده‌اند؛ بقیه بدون نشان می‌مانند.
	 */
	public static function region_badge( $recipe ) {
		if ( ! is_array( $recipe ) ) {
			return '';
		}
		$province = isset( $recipe['province'] ) ? trim( (string) $recipe['province'] ) : '';
		if ( '' !== $province ) {
			return '<span class="ashp-badge ashp-badge--region">📍 ' . esc_html( $province ) . '</span>';
		}
		$country = isset( $recipe['country'] ) ? trim( (string) $recipe['country'] ) : '';
		if ( '' !== $country ) {
			return '<span class="ashp-badge ashp-badge--region">🌍 ' . esc_html( $country ) . '</span>';
		}
		return '';
	}

	/** آیا این دستور حلال علامت خورده است؟ */
	public static function is_halal( $recipe ) {
		return ! is_array( $recipe ) || ! isset( $recipe['is_halal'] ) || (int) $recipe['is_halal'] === 1;
	}

	/** یادداشت حلال یک دستور (اگر دارد) */
	public static function halal_block( $recipe ) {
		if ( ! is_array( $recipe ) ) {
			return '';
		}
		return ''; // برچسب حلال برداشته شد.
		$note = isset( $recipe['halal_note'] ) ? trim( (string) $recipe['halal_note'] ) : '';
		if ( '' === $note ) {
			return '';
		}
		return '<p class="ashp-note ashp-note--halal"><strong>☪ ' . esc_html__( 'نکتهٔ حلال:', 'ashpazbashi' ) . '</strong> ' .
			esc_html( $note ) . '</p>';
	}

	/** کارت یک دستور */
	public static function recipe_card( $recipe ) {
		if ( ! is_array( $recipe ) ) {
			return '';
		}

		$url = ASHP_DB::recipe_url( $recipe );

		$img = '';
		// تصویر برداشته شد؛ جای آن استیکر وکتوری یکتا می‌آید.
		if ( false ) {
			$img = '';
		} else {
			$img = self::recipe_sticker( $recipe, 132 );
		}

		$meta = '';
		$total = self::total_time( $recipe );
		if ( $total > 0 ) {
			$meta .= '<span>⏱ ' . esc_html( self::time_label( $total ) ) . '</span>';
		}
		if ( ! empty( $recipe['servings'] ) ) {
			$meta .= '<span>🍽 ' . esc_html( number_format_i18n( (int) $recipe['servings'] ) ) . ' ' . esc_html__( 'نفر', 'ashpazbashi' ) . '</span>';
		}
		$diff = self::difficulty_label( isset( $recipe['difficulty'] ) ? $recipe['difficulty'] : '' );
		if ( '' !== $diff ) {
			$meta .= '<span>🧑‍🍳 ' . esc_html( $diff ) . '</span>';
		}

		$badges = '';
		if ( isset( $recipe['match_cnt'] ) && isset( $recipe['total_cnt'] ) && $recipe['total_cnt'] > 0 ) {
			$m = (int) $recipe['match_cnt'];
			$t = (int) $recipe['total_cnt'];
			if ( $m >= $t ) {
				$badges .= '<span class="ashp-badge ashp-badge--ok">' . esc_html__( 'همهٔ مواد را داری', 'ashpazbashi' ) . '</span>';
			} else {
				$pct = (int) round( 100 * $m / $t );
				$badges .= '<span class="ashp-badge ashp-badge--neon">' . esc_html( sprintf(
					/* translators: %s: match percentage */
					__( '%s٪ تطابق', 'ashpazbashi' ),
					number_format_i18n( $pct )
				) ) . '</span>';
				$badges .= '<span class="ashp-badge">' . esc_html( sprintf(
					/* translators: 1: matched count, 2: total count */
					__( '%1$s از %2$s ماده را داری', 'ashpazbashi' ),
					number_format_i18n( $m ),
					number_format_i18n( $t )
				) ) . '</span>';
			}
		}

		/* نشان وضعیت مراحل حذف شد — همهٔ دستورها کامل‌اند. */

		$sub = ASHP_DB::subcategory_label( $recipe['category'], $recipe['subcategory'] );
		if ( '' !== $sub ) {
			$badges .= '<span class="ashp-badge">' . esc_html( $sub ) . '</span>';
		}

		if ( self::is_halal( $recipe ) ) {
			// برچسب حلال برداشته شد.
		}

		ob_start();
		?>
		<a class="ashp-rcard" href="<?php echo esc_url( $url ); ?>">
			<span class="ashp-rcard__media"><span class="ashp-rcard__plate" aria-hidden="true"><?php
				if ( function_exists( 'ashpazbashi_dish_icon' ) ) {
					echo ashpazbashi_dish_icon( 62 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت
				} else {
					echo self::dish_icon( 62 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG ثابت
				}
			?></span></span>
			<span class="ashp-rcard__body">
				<span class="ashp-rcard__title"><?php echo esc_html( $recipe['name'] ); ?></span>
				<?php if ( '' !== $meta ) : ?>
					<span class="ashp-rcard__meta"><?php echo $meta; // phpcs:ignore WordPress.Security.EscapeOutput -- در بالا escape شد ?></span>
				<?php endif; ?>
				<?php if ( '' !== $badges ) : ?>
					<span class="ashp-rcard__badges"><?php echo $badges; // phpcs:ignore WordPress.Security.EscapeOutput -- در بالا escape شد ?></span>
				<?php endif; ?>
			</span>
		</a>
		<?php
		return (string) ob_get_clean();
	}

	/** آیکن متحرک «بشقاب، قاشق و چنگال» — نسخهٔ افزونه (مستقل از قالب) */
	public static function dish_icon( $size = 58 ) {
		$s = (int) $size;
		if ( $s < 24 ) {
			$s = 24;
		}
		static $n = 0;
		$n++;
		$g = 'ashpDish' . $n;
		return '<svg class="ashp-dish" viewBox="0 0 64 64" width="' . $s . '" height="' . $s . '" role="img" aria-label="' . esc_attr__( 'بشقاب، قاشق و چنگال', 'ashpazbashi' ) . '">
			<defs>
				<linearGradient id="' . $g . 'a" x1="0" y1="0" x2="1" y2="1">
					<stop offset="0%" stop-color="#33e08a"/><stop offset="55%" stop-color="#00f5d4"/><stop offset="100%" stop-color="#ff2e97"/>
				</linearGradient>
				<radialGradient id="' . $g . 'b" cx="50%" cy="36%" r="70%">
					<stop offset="0%" stop-color="#33e08a" stop-opacity=".30"/><stop offset="100%" stop-color="#33e08a" stop-opacity="0"/>
				</radialGradient>
			</defs>
			<circle class="ashp-dish__glow" cx="32" cy="38" r="22" fill="url(#' . $g . 'b)"/>
			<g class="ashp-dish__steam" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round">
				<path class="ashp-dish__s1" d="M26 11c-3 4 3 7 0 11"/>
				<path class="ashp-dish__s2" d="M33 7c-3 4 3 7 0 11"/>
				<path class="ashp-dish__s3" d="M40 11c-3 4 3 7 0 11"/>
			</g>
			<circle class="ashp-dish__ring" cx="32" cy="38" r="17" fill="none" stroke="url(#' . $g . 'a)" stroke-width="2.4" stroke-linecap="round" stroke-dasharray="7 6"/>
			<circle class="ashp-dish__rim" cx="32" cy="38" r="10.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-opacity=".6"/>
			<path class="ashp-dish__food" d="M24 38a8 8 0 0 1 16 0 8 8 0 0 1-16 0Z" fill="url(#' . $g . 'a)" fill-opacity=".22"/>
			<g class="ashp-dish__fork" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
				<path d="M9 17v9M13 17v9M9 26h4M11 26v26"/>
			</g>
			<g class="ashp-dish__spoon" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
				<path d="M50 17c4 0 6 3.6 6 9s-2 9-6 9v17"/>
			</g>
		</svg>';
	}

	/** مراحل پخت به‌صورت آرایهٔ جمله‌ها */
	public static function steps( $recipe ) {
		$text = isset( $recipe['instructions'] ) ? trim( (string) $recipe['instructions'] ) : '';
		if ( '' === $text ) {
			return array();
		}

		/* اگر خط‌به‌خط نوشته شده باشد، همان را استفاده کن */
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$lines = array_values( array_filter( array_map( 'trim', $lines ) ) );
		if ( count( $lines ) > 1 ) {
			return array_map( array( __CLASS__, 'clean_step' ), $lines );
		}

		/* وگرنه بر پایهٔ نقطه و شماره‌گذاری جمله‌ها را جدا کن */
		$parts = preg_split( '/(?<=[.!?؟])\s+(?=[\p{L}\p{N}«"\(])/u', $text );
		$parts = array_values( array_filter( array_map( 'trim', (array) $parts ) ) );
		if ( count( $parts ) < 2 ) {
			return array( self::clean_step( $text ) );
		}
		return array_map( array( __CLASS__, 'clean_step' ), $parts );
	}

	private static function clean_step( $step ) {
		$step = preg_replace( '/^\s*(?:[0-9\x{06F0}-\x{06F9}]+[\.\)\-–]\s*)/u', '', $step );
		return trim( (string) $step );
	}

	/** دادهٔ ساختاریافتهٔ Recipe برای گوگل */
	public static function schema_data( $recipe ) {
		if ( ! is_array( $recipe ) || empty( $recipe['name'] ) ) {
			return array();
		}

		$data = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'Recipe',
			'name'          => $recipe['name'],
			'url'           => ASHP_DB::recipe_url( $recipe ),
			'inLanguage'    => 'fa-IR',
			'recipeCategory'=> ASHP_DB::subcategory_label( $recipe['category'], $recipe['subcategory'] ),
			'recipeCuisine' => isset( $recipe['cuisine'] ) ? $recipe['cuisine'] : '',
			'author'        => array(
				'@type' => 'Organization',
				'name'  => defined( 'ASHP_SITE_NAME' ) ? ASHP_SITE_NAME : get_bloginfo( 'name' ),
			),
		);

		$prep  = isset( $recipe['prep_time_min'] ) ? (float) $recipe['prep_time_min'] : 0;
		$cook  = isset( $recipe['cook_time_min'] ) ? (float) $recipe['cook_time_min'] : 0;
		if ( $prep > 0 ) {
			$data['prepTime'] = 'PT' . (int) round( $prep ) . 'M';
		}
		if ( $cook > 0 ) {
			$data['cookTime'] = 'PT' . (int) round( $cook ) . 'M';
		}
		if ( $prep > 0 || $cook > 0 ) {
			$data['totalTime'] = 'PT' . (int) round( $prep + $cook ) . 'M';
		}
		if ( ! empty( $recipe['servings'] ) ) {
			$data['recipeYield'] = (string) (int) $recipe['servings'];
		}

		$ings = ASHP_DB::recipe_ingredients( $recipe['id'] );
		if ( $ings ) {
			$list = array();
			foreach ( $ings as $ing ) {
				$amount = self::amount_label( $ing );
				$list[] = '' !== $amount ? $ing['name'] . ' — ' . $amount : $ing['name'];
			}
			$data['recipeIngredient'] = $list;
		}

		$steps = self::steps( $recipe );
		if ( $steps ) {
			$data['recipeInstructions'] = array();
			foreach ( $steps as $step ) {
				$data['recipeInstructions'][] = array(
					'@type' => 'HowToStep',
					'text'  => $step,
				);
			}
		}

		if ( ! empty( $recipe['calories_kcal'] ) ) {
			$data['nutrition'] = array(
				'@type'    => 'NutritionInformation',
				'calories' => (int) round( (float) $recipe['calories_kcal'] ) . ' kcal',
			);
		}

		if ( false ) {
			$data['image'] = array();
		}

		if ( self::is_halal( $recipe ) ) {
			// suitableForDiet حلال برداشته شد.
		}

		return array_filter( $data );
	}

/* ---------------------------------------------------------------------
	 * استیکر وکتوری (SVG، بدون پس‌زمینه، یکتا برای هر مورد)
	 * ------------------------------------------------------------------ */

	/** نقشهٔ گروه مواد اولیه → شکل استیکر */
	private static function sticker_icon( $key ) {
		$icons = array(
			'protein'   => '<ellipse cx="50" cy="58" rx="21" ry="15" fill="currentColor"/><circle cx="68" cy="40" r="9" fill="currentColor"/><rect x="34" y="30" width="16" height="6" rx="3" fill="currentColor" transform="rotate(-20 42 33)"/>',
			'dairy'     => '<path d="M50 24c12 14 19 22 19 31a19 19 0 0 1-38 0c0-9 7-17 19-31z" fill="currentColor"/>',
			'grain'     => '<rect x="47" y="34" width="6" height="42" rx="3" fill="currentColor"/><ellipse cx="38" cy="42" rx="8" ry="5" fill="currentColor" transform="rotate(-35 38 42)"/><ellipse cx="62" cy="42" rx="8" ry="5" fill="currentColor" transform="rotate(35 62 42)"/><ellipse cx="38" cy="56" rx="8" ry="5" fill="currentColor" transform="rotate(-35 38 56)"/><ellipse cx="62" cy="56" rx="8" ry="5" fill="currentColor" transform="rotate(35 62 56)"/>',
			'legume'    => '<ellipse cx="38" cy="44" rx="11" ry="8" fill="currentColor" transform="rotate(-20 38 44)"/><ellipse cx="62" cy="52" rx="11" ry="8" fill="currentColor" transform="rotate(18 62 52)"/><ellipse cx="46" cy="66" rx="11" ry="8" fill="currentColor" transform="rotate(-8 46 66)"/>',
			'veg'       => '<path d="M50 76C30 62 30 36 50 24c20 12 20 38 0 52z" fill="currentColor"/><rect x="47" y="60" width="6" height="16" rx="3" fill="currentColor"/>',
			'fruit'     => '<circle cx="50" cy="56" r="21" fill="currentColor"/><rect x="48" y="26" width="5" height="12" rx="2.5" fill="currentColor"/><ellipse cx="62" cy="30" rx="9" ry="5" fill="currentColor" transform="rotate(-22 62 30)"/>',
			'spice'     => '<path d="M50 22l7 20 21 8-21 8-7 20-7-20-21-8 21-8z" fill="currentColor"/>',
			'fat'       => '<path d="M50 26c13 16 20 25 20 34a20 20 0 0 1-40 0c0-9 7-18 20-34z" fill="currentColor"/><circle cx="43" cy="58" r="5" fill="#07060f" opacity=".35"/>',
			'sweetener' => '<rect x="36" y="42" width="28" height="17" rx="8" fill="currentColor"/><path d="M36 50l-12-8v18z" fill="currentColor"/><path d="M64 50l12-8v18z" fill="currentColor"/>',
			'bakery'    => '<path d="M26 62c0-14 11-24 24-24s24 10 24 24z" fill="currentColor"/><rect x="24" y="62" width="52" height="7" rx="3.5" fill="currentColor"/>',
			'drink'     => '<path d="M32 34h36l-5 38a6 6 0 0 1-6 5H43a6 6 0 0 1-6-5z" fill="currentColor"/><rect x="60" y="20" width="5" height="18" rx="2.5" fill="currentColor" transform="rotate(16 62 29)"/>',
			'other'     => '<circle cx="50" cy="50" r="22" fill="none" stroke="currentColor" stroke-width="8"/><circle cx="50" cy="50" r="7" fill="currentColor"/>',
		);
		return isset( $icons[ $key ] ) ? $icons[ $key ] : $icons['other'];
	}

	/** گروه مواد اولیه → کلید استیکر */
	public static function sticker_group_key( $group ) {
		$map = array(
			'protein' => 'protein', 'dairy' => 'dairy', 'grain' => 'grain', 'flour' => 'grain',
			'legume' => 'legume', 'veg' => 'veg', 'fruit' => 'fruit', 'spice' => 'spice',
			'fat' => 'fat', 'sweetener' => 'sweetener', 'bakery' => 'bakery',
			'choco' => 'sweetener', 'beverage' => 'drink', 'drink' => 'drink',
		);
		return isset( $map[ $group ] ) ? $map[ $group ] : 'other';
	}

	/** زیردستهٔ دستور → کلید استیکر */
	public static function sticker_sub_key( $sub ) {
		$map = array(
			'polo' => 'grain', 'khoresh' => 'protein', 'khorak' => 'protein', 'kabab' => 'protein',
			'meat-chicken' => 'protein', 'seafood' => 'protein', 'vegetarian' => 'veg',
			'kuku' => 'protein', 'dolmeh' => 'veg', 'souffle' => 'veg', 'puree' => 'veg',
			'bread' => 'bakery', 'diet' => 'veg', 'kids' => 'sweetener', 'microwave' => 'other',
			'new' => 'spice', 'local' => 'grain', 'soup-ash' => 'drink', 'salad' => 'veg',
			'finger-food' => 'protein', 'snack' => 'bakery', 'fried' => 'fat',
			'pickle' => 'veg', 'sauce' => 'spice', 'pizza' => 'bakery', 'sandwich' => 'bakery',
			'pasta' => 'grain', 'cake' => 'sweetener', 'sweet' => 'sweetener', 'jelly' => 'sweetener',
			'icecream' => 'dairy', 'halva' => 'sweetener', 'jam' => 'fruit', 'chocolate' => 'sweetener',
			'cold' => 'drink', 'hot' => 'drink', 'italian' => 'grain',
			'american-fastfood' => 'protein', 'turkish-fastfood' => 'protein', 'international' => 'spice',
		);
		return isset( $map[ $sub ] ) ? $map[ $sub ] : 'other';
	}

	/**
	 * استیکر وکتوری.
	 *
	 * @param string $icon  کلید شکل
	 * @param string $seed  هر چیز یکتا برای هر مورد
	 * @param int    $size  اندازهٔ پیکسل
	 * @param string $title متن جایگزین
	 */
	public static function sticker( $icon, $seed, $size = 96, $title = '' ) {
		$h    = crc32( (string) $seed );
		$hue  = array( '#00f5d4', '#ff2e97', '#7b2ff7', '#33e08a', '#ffb02e' )[ $h % 5 ];
		$hue2 = array( '#7b2ff7', '#00f5d4', '#ff2e97', '#00a3ff', '#ff6b3d' )[ (int) ( $h / 7 ) % 5 ];
		$uid  = 's' . ( $h % 99991 );

		$a1 = 14 + ( $h % 12 );
		$a2 = 74 - ( (int) ( $h / 11 ) % 12 );
		$b1 = 22 + ( (int) ( $h / 13 ) % 40 );
		$b2 = 18 + ( (int) ( $h / 17 ) % 30 );
		$r  = 5 + ( (int) ( $h / 19 ) % 4 );

		$out  = '<svg class="ashp-sticker" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 100 100" role="img" aria-label="' . esc_attr( $title ) . '" xmlns="http://www.w3.org/2000/svg">';
		$out .= '<defs>';
		$out .= '<linearGradient id="' . $uid . 'g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' . $hue . '"/><stop offset="1" stop-color="' . $hue2 . '"/></linearGradient>';
		$out .= '<radialGradient id="' . $uid . 'r" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ffffff" stop-opacity=".28"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>';
		$out .= '</defs>';
		$out .= '<rect x="6" y="6" width="88" height="88" rx="30" fill="url(#' . $uid . 'g)" opacity=".16" stroke="' . $hue . '" stroke-width="2.5" stroke-opacity=".55"/>';
		$out .= '<rect x="6" y="6" width="88" height="88" rx="30" fill="url(#' . $uid . 'r)"/>';
		$out .= '<circle cx="' . $a1 . '" cy="' . $b1 . '" r="' . $r . '" fill="' . $hue . '" opacity=".85"/>';
		$out .= '<circle cx="' . $a2 . '" cy="' . $b2 . '" r="' . ( $r - 1 ) . '" fill="' . $hue2 . '" opacity=".7"/>';
		$out .= '<g style="color:' . $hue . '">' . self::sticker_icon( $icon ) . '</g>';
		$out .= '</svg>';
		return $out;
	}

	/** استیکر یک مادهٔ اولیه */
	public static function ingredient_sticker( $ing, $size = 32 ) {
		$group = isset( $ing['group_key'] ) ? $ing['group_key'] : 'other';
		return self::sticker( self::sticker_group_key( $group ), 'i' . ( $ing['name'] ?? '' ), $size, $ing['name'] ?? '' );
	}

	/** استیکر یک دستور پخت (برای جایگاه عکس) */
	public static function recipe_sticker( $recipe, $size = 180 ) {
		$sub = isset( $recipe['subcategory'] ) ? $recipe['subcategory'] : '';
		return self::sticker( self::sticker_sub_key( $sub ), 'r' . ( $recipe['slug'] ?? $recipe['name'] ?? '' ), $size, $recipe['name'] ?? '' );
	}
}


	
}
