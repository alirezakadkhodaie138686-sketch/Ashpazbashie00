<?php
/**
 * لایهٔ دادهٔ آشپزباشی — API رسمی برای قالب.
 *
 * @package Ashpazbashi_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASHP_DB' ) ) {

class ASHP_DB {

	/** کش داخلی درخواست — جلوگیری از کوئری تکراری در یک صفحه */
	private static $memo = array();

	/** نام جدول موتور */
	public static function t( $name ) {
		return ashp_core_table( $name );
	}

	/** ساختار دسته‌بندی رسمی */
	public static function taxonomy() {
		return ashp_core_taxonomy();
	}

	/** گروه‌بندی مواد اولیه */
	public static function ingredient_groups_def() {
		return ashp_core_ingredient_groups();
	}

	/* ---------------------------------------------------------------------
	 * دسته‌بندی‌ها
	 * ------------------------------------------------------------------ */

	/** دسته‌های اصلی: slug => نام فارسی */
	public static function categories() {
		$out = array();
		foreach ( self::taxonomy() as $slug => $info ) {
			$out[ $slug ] = $info['fa'];
		}
		return $out;
	}

	/** دسته‌ها با اطلاعات کامل: slug => [fa, en, emoji, desc] */
	public static function cats_full() {
		return self::taxonomy();
	}

	/** زیردسته‌های یک دسته: slug => نام */
	public static function subcategories( $cat ) {
		$tax = self::taxonomy();
		return isset( $tax[ $cat ]['subs'] ) ? $tax[ $cat ]['subs'] : array();
	}

	public static function category_label( $slug ) {
		$tax = self::taxonomy();
		return isset( $tax[ $slug ]['fa'] ) ? $tax[ $slug ]['fa'] : $slug;
	}

	public static function subcategory_label( $cat, $sub ) {
		$subs = self::subcategories( $cat );
		return isset( $subs[ $sub ] ) ? $subs[ $sub ] : $sub;
	}

	public static function category_url( $slug ) {
		return home_url( user_trailingslashit( $slug ) );
	}

	public static function subcategory_url( $cat, $sub ) {
		if ( '' === $sub || $sub === $cat ) {
			return self::category_url( $cat );
		}
		return home_url( user_trailingslashit( $cat . '/' . $sub ) );
	}

	public static function ingredient_url( $slug ) {
		return home_url( user_trailingslashit( 'ingredients/' . $slug ) );
	}

	public static function recipe_url( $row ) {
		if ( is_array( $row ) ) {
			$slug = isset( $row['slug'] ) ? (string) $row['slug'] : '';
		} else {
			$slug = (string) $row;
		}
		if ( '' === $slug ) {
			return home_url( '/recipes/' );
		}
		return home_url( user_trailingslashit( 'recipes/' . $slug ) );
	}

	/* ---------------------------------------------------------------------
	 * آمار
	 * ------------------------------------------------------------------ */

	public static function counts() {
		$cached = get_transient( 'ashp_counts' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;
		$recipes = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t( 'recipes' ) . ' WHERE is_active = 1' ); // phpcs:ignore WordPress.DB.PreparedSQL
		$ings    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t( 'ingredients' ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		$out = array(
			'recipes'     => $recipes,
			'ingredients' => $ings,
			'halal'       => $recipes,
		);
		set_transient( 'ashp_counts', $out, 10 * MINUTE_IN_SECONDS );
		return $out;
	}

	/**
	 * نقشهٔ شمارش دستورها برای همهٔ دسته‌ها — یک کوئری برای کل صفحه.
	 *
	 * @return array [ 'cat' => n, 'cat|sub' => n ]
	 */
	public static function category_count_map() {
		if ( isset( self::$memo['count_map'] ) ) {
			return self::$memo['count_map'];
		}

		$cached = get_transient( 'ashp_cat_map' );
		if ( is_array( $cached ) ) {
			self::$memo['count_map'] = $cached;
			return $cached;
		}

		global $wpdb;
		$recipes = self::t( 'recipes' );
		$rows    = $wpdb->get_results(
			"SELECT category, subcategory, COUNT(*) AS n FROM $recipes
			 WHERE is_active = 1 GROUP BY category, subcategory", // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);

		$map = array();
		foreach ( (array) $rows as $r ) {
			$key         = $r['category'] . '|' . $r['subcategory'];
			$map[ $key ] = (int) $r['n'];
			if ( ! isset( $map[ $r['category'] ] ) ) {
				$map[ $r['category'] ] = 0;
			}
			$map[ $r['category'] ] += (int) $r['n'];
		}

		set_transient( 'ashp_cat_map', $map, 10 * MINUTE_IN_SECONDS );
		self::$memo['count_map'] = $map;
		return $map;
	}

	/** شمارش دستورهای یک دسته (یا زیردسته) */
	public static function category_count( $cat, $sub = '' ) {
		$map = self::category_count_map();
		if ( '' !== $sub ) {
			$key = $cat . '|' . $sub;
			return isset( $map[ $key ] ) ? (int) $map[ $key ] : 0;
		}
		return isset( $map[ $cat ] ) ? (int) $map[ $cat ] : 0;
	}

	/** پاک کردن کش‌های مربوطه */
	public static function flush_cache() {
		delete_transient( 'ashp_counts' );
		delete_transient( 'ashp_groups' );
		delete_transient( 'ashp_ing_counts' );
		delete_transient( 'ashp_cat_map' );
		self::$memo = array();
	}

	/* ---------------------------------------------------------------------
	 * دستورها
	 * ------------------------------------------------------------------ */

	/** تبدیل ردیف دیتابیس به آرایهٔ استاندارد قالب */
	public static function format_row( $row ) {
		if ( ! $row ) {
			return null;
		}
		$row = (array) $row;
		return array(
			'id'                  => (int) $row['id'],
			'name'                => (string) $row['name'],
			'slug'                => (string) $row['slug'],
			'category'            => (string) $row['category'],
			'subcategory'         => (string) $row['subcategory'],
			'cuisine'             => isset( $row['cuisine'] ) ? (string) $row['cuisine'] : '',
			'meal'                => isset( $row['meal'] ) ? (string) $row['meal'] : '',
			'suitable_for'        => isset( $row['suitable_for'] ) ? (string) $row['suitable_for'] : '',
			'servings'            => isset( $row['servings'] ) && null !== $row['servings'] ? (int) $row['servings'] : 0,
			'prep_time_min'       => isset( $row['prep_time_min'] ) && null !== $row['prep_time_min'] ? (float) $row['prep_time_min'] : null,
			'cook_time_min'       => isset( $row['cook_time_min'] ) && null !== $row['cook_time_min'] ? (float) $row['cook_time_min'] : null,
			'difficulty'          => isset( $row['difficulty'] ) ? (string) $row['difficulty'] : '',
			'cooking_method'      => isset( $row['cooking_method'] ) ? (string) $row['cooking_method'] : '',
			'instructions'        => isset( $row['instructions'] ) ? (string) $row['instructions'] : '',
			'instructions_status' => isset( $row['instructions_status'] ) ? (string) $row['instructions_status'] : 'none',
			'calories_kcal'       => isset( $row['calories_kcal'] ) && null !== $row['calories_kcal'] ? (float) $row['calories_kcal'] : null,
			'image_url'           => isset( $row['image_url'] ) ? (string) $row['image_url'] : '',
			'source_dataset'      => isset( $row['source_dataset'] ) ? (string) $row['source_dataset'] : '',
			'completeness'        => isset( $row['completeness'] ) ? (string) $row['completeness'] : '',
			'is_halal'            => isset( $row['is_halal'] ) ? (int) $row['is_halal'] : 1,
			'halal_note'          => isset( $row['halal_note'] ) ? (string) $row['halal_note'] : '',
			'kid_ok'              => isset( $row['kid_ok'] ) ? (int) $row['kid_ok'] : 0,
			'party_ok'            => isset( $row['party_ok'] ) ? (int) $row['party_ok'] : 0,
			'province'            => isset( $row['province'] ) ? (string) $row['province'] : '',
			'country'             => isset( $row['country'] ) ? (string) $row['country'] : '',
		);
	}

	/** واکشی یک دستور با slug */
	public static function get_by_slug( $slug ) {
		$memo_key = 'slug:' . $slug;
		if ( array_key_exists( $memo_key, self::$memo ) ) {
			return self::$memo[ $memo_key ];
		}

		global $wpdb;
		$recipes = self::t( 'recipes' );
		$decoded = self::decode_slug( $slug );

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $recipes WHERE slug = %s AND is_active = 1 LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
				$decoded
			),
			ARRAY_A
		);

		/* اگر پیدا نشد، تطبیق نادیده‌گیرندهٔ بزرگی و کوچکی حروف */
		if ( ! $row ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $recipes WHERE LOWER(slug) = LOWER(%s) AND is_active = 1 LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
					$decoded
				),
				ARRAY_A
			);
		}

		/* آخرین تلاش: جست‌وجوی نسبی روی نام غذا */
		if ( ! $row && '' !== $decoded ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $recipes WHERE slug LIKE %s AND is_active = 1 LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
					'%' . $wpdb->esc_like( $decoded ) . '%'
				),
				ARRAY_A
			);
		}

		$out = self::format_row( $row );
		self::$memo[ $memo_key ] = $out;
		return $out;
	}

	/** واکشی یک دستور با شناسه */
	public static function get( $id ) {
		global $wpdb;
		$recipes = self::t( 'recipes' );
		$row     = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $recipes WHERE id = %d LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $id
			),
			ARRAY_A
		);
		return self::format_row( $row );
	}

	/** مواد اولیهٔ یک دستور با مقدار و واحد */
	public static function recipe_ingredients( $recipe_id ) {
		$memo_key = 'ings:' . (int) $recipe_id;
		if ( array_key_exists( $memo_key, self::$memo ) ) {
			return self::$memo[ $memo_key ];
		}

		global $wpdb;
		$rel = self::t( 'recipe_ingredients' );
		$ing = self::t( 'ingredients' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT i.id, i.name, i.slug, i.group_key,
				        ri.amount_value, ri.amount_text, ri.unit, ri.is_main, ri.amount_is_free, ri.sort_order
				 FROM $rel ri
				 INNER JOIN $ing i ON i.id = ri.ingredient_id
				 WHERE ri.recipe_id = %d
				 ORDER BY ri.is_main DESC, ri.sort_order ASC", // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $recipe_id
			),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'id'             => (int) $r['id'],
				'name'           => (string) $r['name'],
				'slug'           => (string) $r['slug'],
				'group_key'      => (string) $r['group_key'],
				'amount_value'   => null !== $r['amount_value'] ? (float) $r['amount_value'] : null,
				'amount_text'    => (string) $r['amount_text'],
				'unit'           => (string) $r['unit'],
				'is_main'        => (int) $r['is_main'],
				'amount_is_free' => (int) $r['amount_is_free'],
			);
		}
		self::$memo[ $memo_key ] = $out;
		return $out;
	}

	/**
	 * وضعیت متن مراحل پخت.
	 *
	 * none      = متنی وجود ندارد (و ساختگی هم ساخته نشده)
	 * source    = متن از منبع اصلی آمده
	 * generated = تولیدشده و بازبینی‌نشده
	 */
	public static function instructions_status( $recipe ) {
		if ( is_array( $recipe ) && isset( $recipe['instructions_status'] ) ) {
			return $recipe['instructions_status'];
		}
		return 'none';
	}

	/* ---------------------------------------------------------------------
	 * فهرست‌ها و جست‌وجو
	 * ------------------------------------------------------------------ */

	/**
	 * فهرست دستورها با فیلتر.
	 *
	 * @param array $args category, subcategory, q, ingredient_slugs, sort, page, per_page, meal.
	 * @return array [rows, total, page, per_page]
	 */
	public static function query_recipes( $args = array() ) {
		global $wpdb;
		$recipes = self::t( 'recipes' );
		$rel     = self::t( 'recipe_ingredients' );
		$ing     = self::t( 'ingredients' );

		$args = wp_parse_args( $args, array(
			'category'         => '',
			'subcategory'      => '',
			'q'                => '',
			'ingredient_slugs' => array(),
			'sort'             => '',
			'page'             => 1,
			'per_page'         => 24,
			'meal'             => '',
			'flag'             => '',
			'categories'       => array(),
			'subcategories'    => array(),
		) );

		$where  = array( 'r.is_active = 1' );
		$params = array();

		if ( '' !== $args['category'] ) {
			$where[]  = 'r.category = %s';
			$params[] = $args['category'];
		}

		if ( ! empty( $args['subcategories'] ) ) {
			$subs  = array_filter( array_map( 'strval', (array) $args['subcategories'] ) );
			if ( $subs ) {
				$where[] = 'r.subcategory IN (' . implode( ',', array_fill( 0, count( $subs ), '%s' ) ) . ')';
				$params  = array_merge( $params, $subs );
			}
		}

		if ( ! empty( $args['categories'] ) ) {
			$cats   = array_filter( array_map( 'strval', (array) $args['categories'] ) );
			if ( $cats ) {
				$where[] = 'r.category IN (' . implode( ',', array_fill( 0, count( $cats ), '%s' ) ) . ')';
				$params  = array_merge( $params, $cats );
			}
		}

		// پرچم‌های بخش‌ها: غذای کودکان و فود پارتی
		$flag_col = '';
		if ( 'kids' === $args['flag'] ) {
			$flag_col = 'r.kid_ok';
		} elseif ( 'party' === $args['flag'] ) {
			$flag_col = 'r.party_ok';
		}
		if ( '' !== $flag_col ) {
			$where[] = $flag_col . ' = 1';
		}
		if ( '' !== $args['subcategory'] ) {
			$where[]  = 'r.subcategory = %s';
			$params[] = $args['subcategory'];
		}
		if ( '' !== $args['meal'] ) {
			$where[]  = 'r.meal = %s';
			$params[] = $args['meal'];
		}
		if ( '' !== $args['q'] ) {
			$like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
			$where[]  = '( r.name LIKE %s OR r.slug LIKE %s OR EXISTS ( SELECT 1 FROM ' . $rel . ' ri2 INNER JOIN ' . $ing . ' i2 ON i2.id = ri2.ingredient_id WHERE ri2.recipe_id = r.id AND i2.name LIKE %s ) )';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$join        = '';
		$having      = '';
		$select_extra = '';
		$min_match   = 0;
		if ( ! empty( $args['ingredient_slugs'] ) ) {
			$slugs   = self::clean_slugs( $args['ingredient_slugs'], 40 );
			$holders = implode( ',', array_fill( 0, count( $slugs ), '%s' ) );

			$join    = "INNER JOIN $rel ri ON ri.recipe_id = r.id INNER JOIN $ing i ON i.id = ri.ingredient_id";
			$select_extra = ', ( SELECT COUNT(*) FROM ' . $rel . " ri3 WHERE ri3.recipe_id = r.id ) AS total_cnt";
			$where[] = "i.slug IN ( $holders )";
			$params  = array_merge( $params, $slugs );

			// سخت‌گیری: با انتخاب مواد بیشتر، تطبیق بیشتری لازم است
			$min_match = count( $slugs ) > 1 ? max( 2, (int) ceil( count( $slugs ) * 0.5 ) ) : 1;
			$having    = 'HAVING match_cnt >= ' . (int) $min_match;
		}

		switch ( $args['sort'] ) {
			case 'fast':
				$order = '( COALESCE(r.prep_time_min,0) + COALESCE(r.cook_time_min,0) ) ASC';
				break;
			case 'easy':
				$order = "FIELD( r.difficulty, 'مبتدی', 'متوسط', 'پیشرفته', 'حرفه ای' ) ASC, r.name ASC";
				break;
			case 'few':
				$order = $join ? 'total_cnt ASC' : 'r.id ASC';
				break;
			case 'rand':
				$order = 'RAND()';
				break;
			default:
				$order = $join ? 'match_cnt DESC, total_cnt ASC' : 'r.id ASC';
		}

		$per_page = max( 1, (int) $args['per_page'] );
		$page     = max( 1, (int) $args['page'] );
		$offset   = ( $page - 1 ) * $per_page;

		/* اگر فیلتر مواد اولیه فعال نباشد، جدول ri در join نیست و اشاره به آن
		   خطای MySQL می‌دهد و فهرست خالی می‌شود. پس شمارش تطبیق هم فقط در
		   همان حالت محاسبه می‌شود. */
		$match_expr = $join
			? 'COUNT( DISTINCT ri.ingredient_id ) AS match_cnt'
			: '0 AS match_cnt';

		$select = "SELECT r.id, r.name, r.slug, r.category, r.subcategory, r.cuisine, r.meal, r.suitable_for,
		                  r.servings, r.prep_time_min, r.cook_time_min, r.difficulty, r.cooking_method,
		                  r.instructions, r.instructions_status, r.calories_kcal, r.image_url,
		                  r.source_dataset, r.completeness, r.kid_ok, r.party_ok, r.province, r.country,
		                  " . $match_expr . $select_extra;

		$sql = $select . " FROM $recipes r " . $join . ' WHERE ' . implode( ' AND ', $where ) .
			' GROUP BY r.id ' . $having . ' ORDER BY ' . $order . ' LIMIT %d OFFSET %d';

		$rows = $wpdb->get_results(
			$wpdb->prepare( $sql, array_merge( $params, array( $per_page, $offset ) ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);

		$count_sql = 'SELECT COUNT(*) FROM ( SELECT r.id FROM ' . $recipes . ' r ' . $join . ' WHERE ' .
			implode( ' AND ', $where ) . ' GROUP BY r.id ' . $having . ' ) t';
		$total     = (int) $wpdb->get_var(
			$params ? $wpdb->prepare( $count_sql, $params ) : $count_sql // phpcs:ignore WordPress.DB.PreparedSQL
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$row['match_cnt'] = isset( $row['match_cnt'] ) ? (int) $row['match_cnt'] : 0;
			$out[]            = self::format_row( $row );
		}

		return array(
			'rows'     => $out,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/** جست‌وجوی ساده در نام غذا و مواد اولیه */
	public static function search_recipes( $q, $limit = 60 ) {
		$res = self::query_recipes( array(
			'q'        => $q,
			'per_page' => (int) $limit,
			'page'     => 1,
		) );
		return $res['rows'];
	}

	/** دستوری برای پیشنهاد روز — پایدار در طول یک روز */
	public static function recipe_of_the_day() {
		global $wpdb;
		$recipes = self::t( 'recipes' );
		$total   = self::counts();
		$total   = isset( $total['recipes'] ) ? (int) $total['recipes'] : 0;
		if ( $total < 1 ) {
			return null;
		}
		$seed  = (int) gmdate( 'Ymd' );
		$offset = $seed % $total;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $recipes WHERE is_active = 1 AND completeness = 'complete' ORDER BY id ASC LIMIT 1 OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL
				$offset
			),
			ARRAY_A
		);
		if ( ! $row ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $recipes WHERE is_active = 1 ORDER BY id ASC LIMIT 1 OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL
					$offset
				),
				ARRAY_A
			);
		}
		return self::format_row( $row );
	}

	/** غذاهای مشابه (همان زیردسته، سپس همان دسته) */
	public static function related_recipes( $recipe, $limit = 4 ) {
		global $wpdb;
		$recipes = self::t( 'recipes' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $recipes
				 WHERE is_active = 1 AND id <> %d AND subcategory = %s AND category = %s
				 ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $recipe['id'],
				(string) $recipe['subcategory'],
				(string) $recipe['category'],
				(int) $limit
			),
			ARRAY_A
		);

		if ( count( (array) $rows ) < $limit ) {
			$more = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM $recipes
					 WHERE is_active = 1 AND id <> %d AND category = %s
					 ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL
					(int) $recipe['id'],
					(string) $recipe['category'],
					(int) $limit
				),
				ARRAY_A
			);
			$seen = array();
			foreach ( (array) $rows as $r ) {
				$seen[ (int) $r['id'] ] = true;
			}
			foreach ( (array) $more as $r ) {
				if ( isset( $seen[ (int) $r['id'] ] ) ) {
					continue;
				}
				$rows[] = $r;
				if ( count( $rows ) >= $limit ) {
					break;
				}
			}
		}

		$out = array();
		foreach ( array_slice( (array) $rows, 0, $limit ) as $row ) {
			$out[] = self::format_row( $row );
		}
		return $out;
	}

	/* ---------------------------------------------------------------------
	 * مواد اولیه
	 * ------------------------------------------------------------------ */

	/** مواد اولیه گروه‌بندی‌شده برای صفحهٔ انتخاب */
	public static function ingredient_groups( $min_count = 3, $per_group = 90 ) {
		$cached = get_transient( 'ashp_groups' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;
		$ing = self::t( 'ingredients' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT slug, name, group_key, recipes_count FROM $ing
				 WHERE recipes_count >= %d ORDER BY recipes_count DESC LIMIT 3000", // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $min_count
			),
			ARRAY_A
		);

		$defs = self::ingredient_groups_def();
		$out  = array();
		foreach ( $defs as $key => $def ) {
			$out[ $key ] = array(
				'key'   => $key,
				'label' => $def['label'],
				'emoji' => $def['emoji'],
				'items' => array(),
			);
		}

		$overflow = array();
		foreach ( (array) $rows as $r ) {
			$key = isset( $out[ $r['group_key'] ] ) ? $r['group_key'] : 'other';
			$item = array(
				'slug' => (string) $r['slug'],
				'name' => (string) $r['name'],
				'n'    => (int) $r['recipes_count'],
			);
			if ( count( $out[ $key ]['items'] ) < $per_group ) {
				$out[ $key ]['items'][] = $item;
			} else {
				$overflow[] = $item;
			}
		}

		/* گروه‌های خالی را حذف کن */
		$out = array_values( array_filter( $out, function ( $g ) {
			return ! empty( $g['items'] );
		} ) );

		set_transient( 'ashp_groups', $out, 30 * MINUTE_IN_SECONDS );
		return $out;
	}

	/**
	 * بازگشایی یک اسلاگ از نشانی اینترنتی.
	 *
	 * اسلاگ‌های فارسی در URL رمزگذاری می‌شوند (%D8%A2%D8%B4). اگر مقدار
	 * همچنان درصدی باشد، بازگشایی می‌شود تا با اسلاگ دیتابیس بخواند.
	 */
	public static function decode_slug( $slug ) {
		$slug  = is_string( $slug ) ? trim( $slug ) : '';
		if ( '' === $slug ) {
			return '';
		}
		$guard = 0;
		while ( false !== strpos( $slug, '%' ) && $guard < 5 ) {
			$next = urldecode( $slug );
			if ( $next === $slug ) {
				break;
			}
			$slug = $next;
			$guard++;
		}
		return $slug;
	}

	/**
	 * پاک‌سازی فهرست اسلاگ‌ها (بدون sanitize_title).
	 *
	 * sanitize_title روی متن فارسی آن را به رشتهٔ درصدی تبدیل می‌کند و
	 * مقایسه با دیتابیس همیشه شکست می‌خورد؛ پس فقط کاراکترهای خطرناک حذف
	 * می‌شوند.
	 */
	public static function clean_slugs( $raw, $max = 40 ) {
		$out = array();
		foreach ( (array) $raw as $slug ) {
			$slug = self::decode_slug( $slug );
			$slug = preg_replace( '#[/\\\\\x00-\x1F\x7F]#', '', $slug );
			$slug = trim( (string) $slug );
			if ( '' !== $slug ) {
				$out[] = $slug;
			}
		}
		return array_values( array_unique( array_slice( $out, 0, $max ) ) );
	}

	/** مواد انتخاب‌شده از پارامترهای درخواست */
	public static function picked_from_request() {
		$raw = array();
		if ( isset( $_GET['ing'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$raw = (array) wp_unslash( $_GET['ing'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		return self::clean_slugs( $raw );
	}

	/** یک مادهٔ اولیه با slug */
	public static function ingredient_by_slug( $slug ) {
		global $wpdb;
		$ing     = self::t( 'ingredients' );
		$decoded = self::decode_slug( $slug );
		$row     = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $ing WHERE slug = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
				$decoded
			),
			ARRAY_A
		);

		if ( ! $row ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $ing WHERE LOWER(slug) = LOWER(%s) LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
					$decoded
				),
				ARRAY_A
			);
		}
		if ( ! $row ) {
			return null;
		}
		return array(
			'id'            => (int) $row['id'],
			'name'          => (string) $row['name'],
			'slug'          => (string) $row['slug'],
			'group_key'     => (string) $row['group_key'],
			'recipes_count' => (int) $row['recipes_count'],
		);
	}

	/**
	 * پیشنهاد غذا بر پایهٔ مواد انتخابی.
	 *
	 * @param string[] $slugs     اسلاگ مواد انتخاب‌شده.
	 * @param int      $limit     تعداد نتیجه.
	 * @param int      $min_match کمترین تعداد مادهٔ مشترک.
	 * @return array
	 */
	public static function pick_recipes( $slugs, $limit = 30, $min_match = 3 ) {
		global $wpdb;

		$slugs = self::clean_slugs( $slugs, 40 );
		if ( count( $slugs ) < 1 ) {
			return array();
		}

		$recipes = self::t( 'recipes' );
		$rel     = self::t( 'recipe_ingredients' );
		$ing     = self::t( 'ingredients' );

		$holders  = implode( ',', array_fill( 0, count( $slugs ), '%s' ) );
		$min_match = max( 1, min( (int) $min_match, count( $slugs ) ) );

		$sql = "SELECT r.id, r.name, r.slug, r.category, r.subcategory, r.cuisine, r.meal, r.suitable_for,
		               r.servings, r.prep_time_min, r.cook_time_min, r.difficulty, r.cooking_method,
		               r.instructions, r.instructions_status, r.calories_kcal, r.image_url,
		               r.source_dataset, r.completeness, r.kid_ok, r.party_ok,
		               COUNT( DISTINCT ri.ingredient_id ) AS match_cnt,
		               ( SELECT COUNT(*) FROM $rel x WHERE x.recipe_id = r.id ) AS total_cnt
		        FROM $recipes r
		        INNER JOIN $rel ri ON ri.recipe_id = r.id
		        INNER JOIN $ing i ON i.id = ri.ingredient_id
		        WHERE r.is_active = 1 AND i.slug IN ( $holders )
		        GROUP BY r.id
		        HAVING match_cnt >= %d
		        ORDER BY ( match_cnt / GREATEST( total_cnt, 1 ) ) DESC, match_cnt DESC, r.name ASC
		        LIMIT %d";

		$params = array_merge( $slugs, array( $min_match, (int) $limit ) );

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL

		$out = array();
		foreach ( (array) $rows as $row ) {
			$row['match_cnt'] = (int) $row['match_cnt'];
			$row['total_cnt'] = (int) $row['total_cnt'];
			$out[]            = self::format_row( $row ) + array(
				'match_cnt' => $row['match_cnt'],
				'total_cnt' => $row['total_cnt'],
			);
		}
		return $out;
	}

	/**
	 * زیردسته‌های چند دستهٔ مشخص، با شمارش — برای بخش‌های تازه.
	 *
	 * @param string[] $cats فهرست اسلاگ دسته‌های اصلی.
	 * @return array
	 */
	public static function subcategory_cards( $cats ) {
		$tax  = self::taxonomy();
		$out  = array();
		foreach ( (array) $cats as $cat ) {
			if ( ! isset( $tax[ $cat ] ) ) {
				continue;
			}
			$subs = array();
			foreach ( $tax[ $cat ]['subs'] as $slug => $label ) {
				$n = self::category_count( $cat, $slug );
				if ( $n < 1 ) {
					continue;
				}
				$subs[] = array(
					'label' => $label,
					'count' => $n,
					'url'   => self::subcategory_url( $cat, $slug ),
				);
			}
			$out[] = array(
				'cat'   => $cat,
				'fa'    => $tax[ $cat ]['fa'],
				'en'    => $tax[ $cat ]['en'],
				'emoji' => $tax[ $cat ]['emoji'],
				'desc'  => $tax[ $cat ]['desc'],
				'count' => self::category_count( $cat ),
				'url'   => self::category_url( $cat ),
				'subs'  => $subs,
			);
		}
		return $out;
	}

	/** پرکاربردترین مواد اولیه یک یا چند گروه */
	public static function top_ingredients( $group_keys = array(), $limit = 36 ) {
		global $wpdb;
		$ing = self::t( 'ingredients' );

		if ( $group_keys ) {
			$holders = implode( ',', array_fill( 0, count( $group_keys ), '%s' ) );
			$sql     = "SELECT name, slug, group_key, recipes_count FROM $ing
				WHERE group_key IN ( $holders ) AND recipes_count > 1
				ORDER BY recipes_count DESC LIMIT %d";
			$params  = array_merge( array_values( $group_keys ), array( (int) $limit ) );
			$rows    = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT name, slug, group_key, recipes_count FROM $ing
					 WHERE recipes_count > 1 ORDER BY recipes_count DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL
					(int) $limit
				),
				ARRAY_A
			);
		}

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'name'  => (string) $r['name'],
				'slug'  => (string) $r['slug'],
				'group' => (string) $r['group_key'],
				'count' => (int) $r['recipes_count'],
				'url'   => self::ingredient_url( (string) $r['slug'] ),
			);
		}
		return $out;
	}


	/* ---------------------------------------------------------------------
	 * ابزارهای ساخت/ویرایش از پنل مدیریت
	 * ------------------------------------------------------------------ */

	const ZWNJ = "\xE2\x80\x8C";

	/** نرمال‌سازی پایهٔ فارسی (ی/ک عربی، ارقام، نیم‌فاصله) */
	public static function normalize_fa( $text ) {
		$text = (string) $text;
		$text = str_replace(
			array( 'ي', 'ك', 'ۀ', 'أ', 'إ', 'ٱ', 'ؤ', "\xE2\x80\x8F", "\xE2\x80\x8E", 'ـ' ),
			array( 'ی', 'ک', 'ه', 'ا', 'ا', 'ا', 'و', '', '', '' ),
			$text
		);
		$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$ar = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$text = str_replace( array_merge( $fa, $ar ), array_merge( $en, $en ), $text );
		$text = preg_replace( '/[\x{064B}-\x{0652}\x{0670}]/u', '', $text );
		$text = preg_replace( '/[ \t]+/u', ' ', $text );
		return trim( $text );
	}

	/** کلید مقایسهٔ مواد اولیه (هم‌خوان با خط لولهٔ ساخت داده) */
	public static function normalize_key( $text ) {
		$text = self::normalize_fa( $text );
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$text = str_replace( self::ZWNJ, ' ', $text );
		$text = preg_replace( '/[«»"\'\(\)\[\]\{\}:;!?؟،,\.\-–—_\/\\\\|]+/u', ' ', $text );
		$text = preg_replace( '/\s+/u', ' ', $text );
		return trim( (string) $text );
	}

	/** ساخت اسلاگ از متن فارسی (حروف فارسی حفظ می‌شوند) */
	public static function slugify( $text, $max = 190 ) {
		$text = self::normalize_fa( $text );
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		$text = str_replace( self::ZWNJ, '-', $text );
		$text = preg_replace( '/[^\p{L}\p{N}]+/u', '-', $text );
		$text = preg_replace( '/-{2,}/', '-', $text );
		$text = trim( (string) $text, '-' );
		if ( '' === $text ) {
			$text = 'item';
		}
		return mb_substr( $text, 0, $max );
	}

	/** اسلاگ یکتای غذا */
	public static function make_slug( $text, $exclude_id = 0 ) {
		global $wpdb;
		$table = self::t( 'recipes' );
		$base  = self::slugify( $text );
		$slug  = $base;
		$n     = 2;
		while ( true ) {
			$found = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM $table WHERE slug = %s AND id <> %d LIMIT 1", $slug, (int) $exclude_id ) // phpcs:ignore WordPress.DB.PreparedSQL
			);
			if ( ! $found ) {
				break;
			}
			$slug = $base . '-' . $n;
			$n++;
		}
		return $slug;
	}

	/** اسلاگ یکتای مادهٔ اولیه */
	public static function make_ingredient_slug( $text, $exclude_id = 0 ) {
		global $wpdb;
		$table = self::t( 'ingredients' );
		$base  = self::slugify( $text );
		$slug  = $base;
		$n     = 2;
		while ( true ) {
			$found = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM $table WHERE slug = %s AND id <> %d LIMIT 1", $slug, (int) $exclude_id ) // phpcs:ignore WordPress.DB.PreparedSQL
			);
			if ( ! $found ) {
				break;
			}
			$slug = $base . '-' . $n;
			$n++;
		}
		return $slug;
	}

	/** گروه‌بندی خودکار یک مادهٔ اولیه بر پایهٔ نامش */
	public static function detect_group( $name ) {
		$key = self::normalize_key( $name );
		if ( '' === $key ) {
			return 'other';
		}

		$rules = array(
			'fat'       => array( 'روغن', 'کره', 'مارگارین', 'دنبه', 'پیه', 'لیست' ),
			'sweetener' => array( 'شکر', 'پودر قند', 'قند', 'عسل', 'شیره', 'شکلات', 'کاکائو', 'وانیل', 'نبات', 'مربا', 'پودر ژله', 'اسانس', 'کارامل', 'خامه قنادی' ),
			'protein'   => array( 'گوشت', 'مرغ', 'ماهی', 'میگو', 'تخم مرغ', 'سوسیس', 'کالباس', 'بوقلمون', 'جوجه', 'زرده', 'سفیده', 'سینه', 'ران', 'جگر', 'قلوه', 'زبان', 'تن ماهی', 'سالمون', 'قزل' ),
			'legume'    => array( 'لوبیا', 'نخود', 'عدس', 'لپه', 'باقلا', 'ماش', 'سویا' ),
			'grain'     => array( 'برنج', 'ماکارونی', 'اسپاگتی', 'رشته', 'بلغور', 'جو', 'گندم', 'پاستا', 'لازانیا', 'نودل', 'کینوا', 'کوسکوس' ),
			'dairy'     => array( 'شیر', 'ماست', 'پنیر', 'خامه', 'دوغ', 'کشک', 'سرشیر', 'قره قروت' ),
			'bakery'    => array( 'نان', 'خمیر', 'یوفکا', 'باگت', 'لواش', 'تافتون', 'بربری', 'سنگک' ),
			'spice'     => array( 'نمک', 'فلفل', 'زردچوبه', 'دارچین', 'زعفران', 'زیره', 'رازیانه', 'هل', 'زنجبیل', 'میخک', 'جوز', 'سماق', 'آویشن', 'ادویه', 'سرکه', 'سس', 'رب', 'آبلیمو', 'لیمو عمانی', 'کچاپ', 'مایونز', 'خردل', 'بکینگ پودر', 'جوش شیرین', 'خمیر مایه', 'گلپر', 'کاری', 'ماسالا', 'پاپریکا', 'خلال', 'نعنا', 'پونه', 'ریحان', 'جعفری', 'گشنیز', 'شوید', 'ترخون', 'مرزه', 'شنبلیله', 'سبزی', 'برگ بو', 'رزماری', 'مریم گلی' ),
			'fruit'     => array( 'سیب', 'لیمو', 'پرتقال', 'نارنج', 'انار', 'خرما', 'انجیر', 'هلو', 'زردآلو', 'آلو', 'گیلاس', 'آلبالو', 'توت', 'موز', 'هندوانه', 'طالبی', 'خربزه', 'انگور', 'کیوی', 'نارگیل', 'به', 'گلابی', 'آلوچه', 'غوره', 'زرشک', 'سنجد', 'گردو', 'بادام', 'پسته', 'فندق', 'کشمش', 'کنجد', 'تمر هندی' ),
			'veg'       => array( 'پیاز', 'سیر', 'گوجه', 'خیار', 'هویج', 'کلم', 'کدو', 'بادمجان', 'کرفس', 'قارچ', 'اسفناج', 'کاهو', 'تره', 'پیازچه', 'شلغم', 'چغندر', 'فلفل دلمه', 'سیب زمینی', 'بروکلی', 'زیتون', 'ذرت', 'بامیه', 'کنگر', 'جوانه', 'لوبیا سبز' ),
			'liquid'    => array( 'آب' ),
		);

		$best = 'other';
		$len  = 0;
		foreach ( $rules as $group => $words ) {
			foreach ( $words as $w ) {
				$wk = self::normalize_key( $w );
				if ( '' === $wk ) {
					continue;
				}
				if ( $key === $wk || 0 === strpos( $key, $wk . ' ' ) || false !== strpos( $key, ' ' . $wk . ' ' ) ) {
					if ( mb_strlen( $wk ) > $len ) {
						$len  = mb_strlen( $wk );
						$best = $group;
					}
				}
			}
		}
		return $best;
	}

	/** یافتن یا ساختن یک مادهٔ اولیه با نام داده‌شده */
	public static function ensure_ingredient( $name ) {
		global $wpdb;
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return 0;
		}
		$norm = self::normalize_key( $name );
		if ( '' === $norm ) {
			return 0;
		}

		$table = self::t( 'ingredients' );
		$id    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE normalized_name = %s LIMIT 1", $norm ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $id ) {
			return $id;
		}

		$wpdb->insert( $table, array(
			'name'            => $name,
			'slug'            => self::make_ingredient_slug( $name ),
			'normalized_name' => $norm,
			'group_key'       => self::detect_group( $name ),
			'recipes_count'   => 0,
		) );

		return (int) $wpdb->insert_id;
	}

	/** شمار غذاهای علامت‌خورده به حلال */
	public static function count_halal() {
		global $wpdb;
		$table = self::t( 'recipes' );
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE is_halal = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** تعداد مواد اولیهٔ یک غذا */
	public static function recipe_ingredient_count( $recipe_id ) {
		global $wpdb;
		$rel = self::t( 'recipe_ingredients' );
		return (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM $rel WHERE recipe_id = %d", (int) $recipe_id ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
	}

	/** نام همهٔ مواد اولیه (برای پیشنهاد خودکار در فرم) */
	public static function all_ingredient_names( $limit = 3000 ) {
		$cached = self::$memo['ing_names'] ?? null;
		if ( is_array( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		$table = self::t( 'ingredients' );
		$rows  = $wpdb->get_col(
			$wpdb->prepare( "SELECT name FROM $table ORDER BY recipes_count DESC, name ASC LIMIT %d", (int) $limit ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
		self::$memo['ing_names'] = (array) $rows;
		return self::$memo['ing_names'];
	}

	/** واحدهای رایج برای پیشنهاد در فرم */
	public static function common_units() {
		return array(
			'پیمانه', 'لیوان', 'قاشق غذاخوری', 'قاشق چایخوری', 'قاشق مرباخوری',
			'عدد', 'گرم', 'کیلوگرم', 'بوته', 'حبه', 'شاخه', 'برگ', 'ورقه', 'تکه',
			'دسته', 'فنجان', 'استکان', 'سیخ', 'بسته', 'قوطی', 'کاسه', 'نخ', 'پاکت',
			'سانتیمتر', 'قاچ', 'حلقه', 'مشت', 'لایه',
		);
	}

	/* ---------------------------------------------------------------------
	 * زمینهٔ صفحه (برای قالب‌ها)
	 * ------------------------------------------------------------------ */

	/** دستور جاری در صفحهٔ تک‌دستور */
	public static function current_recipe() {
		$slug = ASHP_Router::current_var( ASHP_Router::VAR_RECIPE );
		if ( '' === $slug ) {
			return null;
		}
		return self::get_by_slug( $slug );
	}

	/** مادهٔ اولیهٔ جاری */
	public static function current_ingredient() {
		$slug = ASHP_Router::current_var( ASHP_Router::VAR_ING );
		if ( '' === $slug ) {
			return null;
		}
		return self::ingredient_by_slug( $slug );
	}

	/** زمینهٔ فهرست برای قالب ashp-recipes.php */
	public static function current_list_context() {
		if ( isset( self::$memo['ctx'] ) ) {
			return self::$memo['ctx'];
		}

		$kind = ASHP_Router::current_var( ASHP_Router::VAR_LIST );

		// phpcs:disable WordPress.Security.NonceVerification
		$q     = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$sort  = isset( $_GET['sort'] ) ? sanitize_key( wp_unslash( $_GET['sort'] ) ) : '';
		$cat   = isset( $_GET['cat'] ) ? sanitize_title( wp_unslash( $_GET['cat'] ) ) : '';
		$page  = isset( $_GET['ashp_page'] ) ? max( 1, (int) $_GET['ashp_page'] ) : 1;
		$ings  = self::picked_from_request();
		// phpcs:enable WordPress.Security.NonceVerification

		$args = array(
			'q'                => $q,
			'sort'             => $sort,
			'category'         => $cat,
			'ingredient_slugs' => $ings,
			'page'             => $page,
			'per_page'         => 24,
		);

		$ctx = array(
			'title'   => __( 'همهٔ دستورها', 'ashpazbashi' ),
			'desc'    => '',
			'total'   => 0,
			'page'    => $page,
			'per_page'=> 24,
			'rows'    => array(),
			'args'    => array( 'q' => $q, 'sort' => $sort, 'cat' => $cat ),
			'base_url'=> home_url( '/recipes/' ),
		);

		$cat_slug = ASHP_Router::current_var( ASHP_Router::VAR_CAT );
		$sub_slug = ASHP_Router::current_var( ASHP_Router::VAR_SUB );

		// هم با ashpq_list=ingredient و هم تنها با وجود ashpq_ing کار می‌کند
		if ( 'ingredient' === $kind || '' !== ASHP_Router::current_var( ASHP_Router::VAR_ING ) ) {
			$ing          = self::current_ingredient();
			$args['ingredient_slugs'] = $ing ? array( $ing['slug'] ) : array();
			$ctx['title'] = $ing ? sprintf( __( 'غذاهایی با %s', 'ashpazbashi' ), $ing['name'] ) : $ctx['title'];
			$ctx['desc']  = '';
			$ctx['base_url'] = $ing ? self::ingredient_url( $ing['slug'] ) : $ctx['base_url'];
		} elseif ( '' !== $cat_slug ) {
			$taxes = self::taxonomy();
			if ( isset( $taxes[ $cat_slug ] ) ) {
				$args['category']    = $cat_slug;
				$ctx['locked_cat']   = $cat_slug;
				$ctx['title']        = $taxes[ $cat_slug ]['fa'];
				$ctx['desc']         = $taxes[ $cat_slug ]['desc'];
				$ctx['base_url']     = self::category_url( $cat_slug );

				if ( '' !== $sub_slug && isset( $taxes[ $cat_slug ]['subs'][ $sub_slug ] ) ) {
					$args['subcategory']   = $sub_slug;
					$ctx['title']          = $taxes[ $cat_slug ]['subs'][ $sub_slug ];
					$ctx['desc']           = $taxes[ $cat_slug ]['desc'];
					$ctx['parent_label']   = $taxes[ $cat_slug ]['fa'];
					$ctx['parent_url']     = self::category_url( $cat_slug );
					$ctx['base_url']       = self::subcategory_url( $cat_slug, $sub_slug );
				}
			}
		}

		if ( '' !== $q ) {
			$ctx['title'] = sprintf( __( 'جست‌وجو برای «%s»', 'ashpazbashi' ), $q );
		}
		if ( ! empty( $ings ) ) {
			$ctx['title'] = __( 'غذاهای قابل پخت با مواد انتخابی', 'ashpazbashi' );
			$ctx['desc']  = __( 'این غذاها با موادی که انتخاب کردی، قابل پخت هستند.', 'ashpazbashi' );
		}

		$res = self::query_recipes( $args );

		$ctx['rows']     = $res['rows'];
		$ctx['total']    = $res['total'];
		$ctx['page']     = $res['page'];
		$ctx['per_page'] = $res['per_page'];
		$ctx['args']     = array_merge( $ctx['args'], array( 'ing' => $ings ) );

		self::$memo['ctx'] = $ctx;
		return $ctx;
	}

/* ---------------------------------------------------------------------
	 * بخش‌های تازه: فود پارتی، غذای کودکان، صفحه‌ها
	 * ------------------------------------------------------------------ */

	/** صفحه‌هایی که از پنل مدیریت ویرایش می‌شوند */
	public static function pages() {
		return array(
			'about'   => __( 'درباره ما', 'ashpazbashi' ),
			'contact' => __( 'تماس با ما', 'ashpazbashi' ),
			'terms'   => __( 'قوانین و مقررات', 'ashpazbashi' ),
			'privacy' => __( 'حریم خصوصی', 'ashpazbashi' ),
		);
	}

	/** متن ذخیره‌شدهٔ یک صفحه */
	public static function page_content( $key ) {
		$all = get_option( 'ashp_pages', array() );
		return isset( $all[ $key ] ) ? (string) $all[ $key ] : '';
	}

	/** ذخیرهٔ متن یک صفحه */
	public static function save_page_content( $key, $html ) {
		$all         = get_option( 'ashp_pages', array() );
		$all[ $key ] = (string) $html;
		update_option( 'ashp_pages', $all );
	}

	/** شمارش دستورهایی که یک پرچم را دارند */
	public static function flag_count( $flag ) {
		$col = ( 'kids' === $flag ) ? 'kid_ok' : ( ( 'party' === $flag ) ? 'party_ok' : '' );
		if ( '' === $col ) {
			return 0;
		}
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t( 'recipes' ) . ' WHERE is_active = 1 AND ' . $col . ' = 1' );
	}

	/** شناسهٔ دستورهای یک دسته (برای چرخهٔ پیشنهاد روزانه) */
	private static function category_ids( $cat ) {
		global $wpdb;
		return array_map( 'intval', (array) $wpdb->get_col(
			$wpdb->prepare( 'SELECT id FROM ' . self::t( 'recipes' ) . ' WHERE is_active = 1 AND category = %s ORDER BY id ASC', $cat )
		) );
	}

	/** واکشی چند دستور با شناسه */
	private static function rows_by_ids( $ids ) {
		$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		if ( ! $ids ) {
			return array();
		}
		global $wpdb;
		$in   = implode( ',', $ids );
		$rows = $wpdb->get_results( 'SELECT * FROM ' . self::t( 'recipes' ) . ' WHERE id IN (' . $in . ')', ARRAY_A );
		$map  = array();
		foreach ( (array) $rows as $r ) {
			$map[ (int) $r['id'] ] = self::format_row( $r );
		}
		$out = array();
		foreach ( $ids as $id ) {
			if ( isset( $map[ $id ] ) ) {
				$out[] = $map[ $id ];
			}
		}
		return $out;
	}

	/**
	 * پیشنهاد امروز آشپزباشی.
	 *
	 * از هر دسته ۲ دستور، هر ۲۴ ساعت یک‌بار جلو می‌رود و تا پایان چرخه
	 * هیچ دستوری تکرار نمی‌شود؛ پس از پایان، دسته از نو و با ترتیب تازه
	 * بازآرایی می‌شود.
	 */
	public static function today_suggestions() {
		$key   = 'ashp_suggest';
		$tax   = self::taxonomy();
		$set   = class_exists( 'ASHP_FoodSettings' ) ? ASHP_FoodSettings::get() : array();

		/* طبق درخواست کارفرما: هر بخش دقیقاً ۴ دستور نشان می‌دهد. */
		$per   = 4;
		$hours = isset( $set['day_hours'] ) ? max( 1, (int) $set['day_hours'] ) : 24;
		$cats  = ( ! empty( $set['day_cats'] ) && is_array( $set['day_cats'] ) )
			? array_values( array_intersect( array_keys( $tax ), $set['day_cats'] ) )
			: array_keys( $tax );
		if ( ! $cats ) {
			$cats = array_keys( $tax );
		}

		$state = get_option( $key );
		if ( ! is_array( $state ) ) {
			$state = array();
		}
		$state += array( 'day' => '', 'slot' => '', 'order' => array(), 'cursor' => array() );

		$day   = function_exists( 'wp_date' ) ? wp_date( 'Y-m-d' ) : gmdate( 'Y-m-d' );
		$slot  = (string) floor( time() / ( $hours * 3600 ) );
		$fresh = ( (string) $state['slot'] !== $slot );
		$out   = array();

		foreach ( $cats as $cat ) {
			if ( empty( $state['order'][ $cat ] ) ) {
				$ids = self::category_ids( $cat );
				shuffle( $ids );
				$state['order'][ $cat ]  = $ids;
				$state['cursor'][ $cat ] = 0;
			}

			$ids = (array) $state['order'][ $cat ];
			$n   = count( $ids );
			if ( 0 === $n ) {
				continue;
			}

			$cur = isset( $state['cursor'][ $cat ] ) ? (int) $state['cursor'][ $cat ] : 0;

			if ( $fresh ) {
				$cur += $per;
				if ( $cur + $per > $n ) {
					/* چرخه تمام شد: بازآرایی تازه و شروع از نو — بدون تکرار */
					$ids = self::category_ids( $cat );
					shuffle( $ids );
					$state['order'][ $cat ] = $ids;
					$cur                    = 0;
				}
				$state['cursor'][ $cat ] = $cur;
			}

			$slice = array_slice( $ids, $cur, $per );
			if ( ! $slice ) {
				$slice = array_slice( $ids, 0, $per );
			}
			$rows = self::rows_by_ids( $slice );

			/*
			 * اگر شناسه‌های ذخیره‌شده کهنه باشند (مثلاً دستهٔ دستور بعداً عوض شده
			 * باشد) ممکن است دستورِ دستهٔ دیگری برگردد. اینجا فیلتر می‌کنیم و از
			 * باقیِ همان دسته جای خالی را پر می‌کنیم تا هر بخش دقیقاً ۴تاییِ
			 * دستهٔ خودش باشد.
			 */
			$rows = array_values( array_filter( $rows, function ( $r ) use ( $cat ) {
				return isset( $r['category'] ) && $r['category'] === $cat;
			} ) );
			if ( count( $rows ) < $per ) {
				/* جای خالی را با یک کوئری دسته‌ای از همان دسته پر می‌کنیم */
				$have = array();
				foreach ( $rows as $r ) {
					$have[ (int) $r['id'] ] = true;
				}
				$pool = array();
				foreach ( $ids as $rid ) {
					$rid = (int) $rid;
					if ( ! isset( $have[ $rid ] ) ) {
						$pool[] = $rid;
					}
				}
				foreach ( self::rows_by_ids( $pool ) as $r ) {
					if ( count( $rows ) >= $per ) {
						break;
					}
					if ( isset( $r['category'] ) && $r['category'] === $cat ) {
						$rows[] = $r;
					}
				}
			}
			if ( $rows ) {
				$out[] = array(
					'cat'   => $cat,
					'label' => $tax[ $cat ]['fa'],
					'emoji' => $tax[ $cat ]['emoji'],
					'url'   => self::category_url( $cat ),
					'rows'  => $rows,
				);
			}
		}

		$state['day']  = $day;
		$state['slot'] = $slot;
		update_option( $key, $state );

		return $out;
	}

	/**
	 * دستورهای کوچکِ صفحهٔ اصلی (به‌جای انیمیشن سه‌بعدی در موبایل).
	 *
	 * یک نمونهٔ متنوع از همهٔ دسته‌ها برمی‌گرداند و ۱۲ ساعت کش می‌شود تا
	 * روی هر بازدید، کوئری سنگین اجرا نشود.
	 */
	public static function mini_cards( $limit = 25 ) {
		$limit = max( 1, min( 40, (int) $limit ) );
		$key   = 'ashp_mini_cards_' . $limit;
		$cache = get_transient( $key );
		if ( is_array( $cache ) && $cache ) {
			return $cache;
		}

		global $wpdb;
		$tax  = self::taxonomy();
		$cats = array_keys( $tax );
		if ( ! $cats ) {
			return array();
		}

		/*
		 * از هر دسته به‌تناسب سهم می‌گیریم تا نمونه متنوع باشد (نه فقط یک دسته).
		 */
		$per_cat = max( 1, (int) ceil( $limit / count( $cats ) ) );
		$out     = array();
		foreach ( $cats as $cat ) {
			$ids = self::category_ids( $cat );
			if ( ! $ids ) {
				continue;
			}
			shuffle( $ids );
			$rows = self::rows_by_ids( array_slice( $ids, 0, $per_cat ) );
			foreach ( $rows as $r ) {
				$out[] = $r;
			}
		}

		/* اگر کم آمد، از کل جدول پر می‌کنیم */
		if ( count( $out ) < $limit ) {
			$extra = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT * FROM ' . self::t( 'recipes' ) . ' WHERE is_active = 1 ORDER BY RAND() LIMIT %d',
					$limit
				),
				ARRAY_A
			);
			$seen = array();
			foreach ( $out as $r ) {
				$seen[ (int) $r['id'] ] = true;
			}
			foreach ( (array) $extra as $r ) {
				if ( isset( $seen[ (int) $r['id'] ] ) ) {
					continue;
				}
				$out[] = self::format_row( $r );
			}
		}

		shuffle( $out );
		$out = array_slice( $out, 0, $limit );
		set_transient( $key, $out, 12 * HOUR_IN_SECONDS );
		return $out;
	}

	/** گروه‌های فود پارتی برای نمایش دسته‌بندی‌شده */
	public static function party_groups() {
		return array(
			'appetizer' => array(
				'label' => __( 'پیش‌غذا و سالاد', 'ashpazbashi' ),
				'emoji' => '🥗',
				'cats'  => array( 'appetizer' ),
			),
			'main'      => array(
				'label' => __( 'غذای اصلی', 'ashpazbashi' ),
				'emoji' => '🍚',
				'cats'  => array( 'iranian-formal', 'iranian-local', 'world', 'fastfood' ),
			),
			'dessert'   => array(
				'label' => __( 'دسر و شیرینی', 'ashpazbashi' ),
				'emoji' => '🍰',
				'cats'  => array( 'dessert' ),
			),
			'drink'     => array(
				'label' => __( 'نوشیدنی', 'ashpazbashi' ),
				'emoji' => '🥤',
				'cats'  => array( 'drink' ),
			),
		);
	}

	/** دستورهای یک گروه از فود پارتی */
	public static function party_group_rows( $group, $limit = 6 ) {
		$groups = self::party_groups();
		if ( ! isset( $groups[ $group ] ) ) {
			return array();
		}
		$res = self::query_recipes( array(
			'flag'       => 'party',
			'categories' => $groups[ $group ]['cats'],
			'per_page'   => $limit,
			'sort'       => 'rand',
		) );
		return isset( $res['rows'] ) ? $res['rows'] : array();
	}

	/** تعداد دستورهای یک گروه از فود پارتی */
	public static function party_group_count( $group ) {
		$groups = self::party_groups();
		if ( ! isset( $groups[ $group ] ) ) {
			return 0;
		}
		$res = self::query_recipes( array(
			'flag'       => 'party',
			'categories' => $groups[ $group ]['cats'],
			'per_page'   => 1,
		) );
		return isset( $res['total'] ) ? (int) $res['total'] : 0;
	}

	/** آیا صفحهٔ جاری بخش فود پارتی است؟ */

	/** گروه‌های غذای کودکان (فقط غذا — بدون دسر) */
	public static function kid_groups() {
		return array(
			'main'  => array(
				'label' => __( 'غذای اصلی', 'ashpazbashi' ),
				'emoji' => '🍚',
				'subs'  => array( 'polo', 'khoresh', 'khorak', 'kabab', 'meat-chicken', 'seafood', 'dolmeh', 'kuku', 'new', 'local', 'vegetarian', 'kids' ),
				'cats'  => array(),
			),
			'snack' => array(
				'label' => __( 'میان‌وعده', 'ashpazbashi' ),
				'emoji' => '🥪',
				'subs'  => array( 'sandwich', 'pizza', 'pasta', 'fried', 'finger-food', 'snack', 'american-fastfood', 'italian', 'international' ),
				'cats'  => array(),
			),
			'light' => array(
				'label' => __( 'سوپ، آش و سالاد', 'ashpazbashi' ),
				'emoji' => '🥗',
				'subs'  => array( 'soup-ash', 'salad', 'puree', 'bread' ),
				'cats'  => array(),
			),
			'drink' => array(
				'label' => __( 'نوشیدنی', 'ashpazbashi' ),
				'emoji' => '🥤',
				'subs'  => array(),
				'cats'  => array( 'drink' ),
			),
		);
	}

	/** دستورهای یک گروه از غذای کودکان */
	public static function kid_group_rows( $group, $limit = 8 ) {
		$g = self::kid_groups();
		if ( ! isset( $g[ $group ] ) ) {
			return array();
		}
		$args = array( 'flag' => 'kids', 'per_page' => $limit, 'sort' => 'rand' );
		if ( $g[ $group ]['subs'] ) {
			$args['subcategories'] = $g[ $group ]['subs'];
		}
		if ( $g[ $group ]['cats'] ) {
			$args['categories'] = $g[ $group ]['cats'];
		}
		$res = self::query_recipes( $args );
		return isset( $res['rows'] ) ? $res['rows'] : array();
	}

	/** تعداد دستورهای یک گروه از غذای کودکان */
	public static function kid_group_count( $group ) {
		$g = self::kid_groups();
		if ( ! isset( $g[ $group ] ) ) {
			return 0;
		}
		$args = array( 'flag' => 'kids', 'per_page' => 1 );
		if ( $g[ $group ]['subs'] ) {
			$args['subcategories'] = $g[ $group ]['subs'];
		}
		if ( $g[ $group ]['cats'] ) {
			$args['categories'] = $g[ $group ]['cats'];
		}
		$res = self::query_recipes( $args );
		return isset( $res['total'] ) ? (int) $res['total'] : 0;
	}

	/** توضیح خط زیر عنوان صفحهٔ «آشپزی با مواد موجود» */
	public static function picker_min() {
		return 3;
	}
}


	

}
